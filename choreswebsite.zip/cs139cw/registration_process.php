<?php
include 'database.php';
$data = new Database();
$stmt = $data->prepare("SELECT 'email' FROM Users WHERE email = :email ;");
$stmt->bindValue(':email', $_POST['email'],SQLITE3_TEXT);
$nameFound = $stmt->execute();
if($nameFound->fetchArray() != NULL)
{
   header("location:registration.php");
}
else
{
  $salt = sha1(date("h:i:sa"));
  $pswd = sha1($_POST['user_password'] . $salt);
  $stmt = $data->prepare("INSERT INTO 'Users' VALUES (NULL,:user,:email,:salt,:pswd,0,NULL);");//creates the new user if they exist
  $stmt->bindValue(':user', $_POST['username'],SQLITE3_TEXT);
  $stmt->bindValue(':email', $_POST['email'],SQLITE3_TEXT);
  $stmt->bindValue(':salt', $salt ,SQLITE3_TEXT);
  $stmt->bindValue(':pswd', $pswd,SQLITE3_TEXT);
  $result = $stmt->execute();
  $stmt = $data->prepare("SELECT * FROM Users WHERE email=:email;");
  $stmt->bindValue(':email', $_POST['email'],SQLITE3_TEXT);
  $users = $stmt->execute();
  $user = $users->fetchArray();
  session_start();
  $_SESSION['UserNo'] = $user['userId'];//Sets session value
  $_SESSION['HouseNo'] = $user['houseNo'];
  header("location:main.php");
}

?>
