DROP TABLE Users;
CREATE TABLE Users (
  userId INTEGER PRIMARY KEY,
  username text,
  email text,
  salt text,
  password text,
  weight integer,
  houseNo integer
);
DROP TABLE Houses;
CREATE TABLE Houses(
  houseNo INTEGER PRIMARY KEY,
  houseName text,
  salt text,
  password text
);
DROP TABLE Chores;
CREATE TABLE Chores(
  houseNo integer,
  userNo integer,
  username text,
  choreNo INTEGER PRIMARY KEY,
  choreName text,
  frequency integer,
  frequencyString text,
  difficulty integer,
  completed text,
  deadline DATE
);
