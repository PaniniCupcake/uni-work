<?php
  header("location:front.html");
  session_start();
  $_SESSION = array();
  session_destroy();//Unsets the session and returns the user to homepage
 ?>
