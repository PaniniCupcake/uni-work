<?php
  session_start();
  include 'access.php';
  if(!loggedIn())
  {
    header("location:front.html");
  }
?>
<!DOCTYPE html>

<html>
<head>
  <title>All chores</title>
  <link rel="stylesheet" href="css/main.css" type="text/css" charset="utf-8">
  <script src='js/jquery-3.6.0.min.js'></script>
  <script src='js/add_chore.js'>ready();</script>
</head>
<body>
  <h1>
    <p>All chores</p>
  </h1>
  <div id = "Main">
    <?php
      include 'database.php';
      include 'security.php';
      $data = new Database();
      $stmt = $data->prepare("SELECT * from Chores WHERE houseNo = :house ;");
      $stmt->bindValue(':house', $_SESSION['HouseNo'],SQLITE3_INTEGER);
      $chores = $stmt->execute();
      echo "<p class='underline'>This household has these chores: </p><ul>";
      while($chore = $chores->fetchArray())
      {
        if($chore['frequencyString'] == "once")//Echos a generic output for most dates and a modified one for others.
        {
          echo "<li>". h($chore['choreName']) ." once is " . h($chore['completed']) . " for " . h($chore['username']) . " (deadline " . h($chore['deadline']) . ")</li>";
        }
        else
        {
          echo "<li>". h($chore['choreName']) ." every " . h($chore['frequencyString']) . " is " . h($chore['completed']) . " for " . h($chore['username']) . " (deadline " . h($chore['deadline']) . ")</li>";
        }
      }
      echo "</ul>";
   ?>
   <br>
   <p class='underline'>Add a chore:</p>
   <form id='form' onSubmit='submit()'>
     <label for = "chore">Enter the name of the chore you want to add.</label><br>
     <input id='chore' name='chore'><br>
     <p>How often should this chore be completed?</p>
     <input type="radio" id="daily" name="frequency" value="daily">
     <label for="daily">Every day</label>
     <input type="radio" id="weekly" name="frequency" value="weekly">
      <label for="weekly">Every week</label>
     <input type="radio" id="fortnightly" name="frequency" value="fortnightly">
      <label for="fortnightly">Every fortnight</label>
     <input type="radio" id="monthly" name="frequency" value="monthly">
     <label for="monthly">Every month</label>
     <input type="radio" id="once" name="frequency" value="once">
     <label for="once">Once</label><br><br>
     <label for="frequency">How many minutes does it take to complete this chore?</label><br>
     <input type="number" id="frequency" min="1" name="frequency"><br><br>
    <input type='submit' value='Add chore'>
   </form>
  </div>
  <div id = "Menu">
  <p><a href="main.php">Back</a></p>
  </div>
  </body>
</html>
