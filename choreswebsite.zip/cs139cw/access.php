<?php
  function loggedIn()
  {//Redirects user if they aren't logged in
    return isset($_SESSION['UserNo']);
  }
 ?>
