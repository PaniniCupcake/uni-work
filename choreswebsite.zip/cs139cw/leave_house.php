<?php
session_start();
$_SESSION['HouseNo'] = NULL;
include 'database.php';
$data = new Database();
$stmt = $data->prepare("UPDATE Users SET houseNo = NULL WHERE userId=:user;");
$stmt->bindValue(':user', $_SESSION['UserNo'],SQLITE3_TEXT);
$stmt->execute();
$stmt = $data->prepare("DELETE FROM Chores WHERE userNo=:user;");//Removes all chores belonging to the user
$stmt->bindValue(':user', $_SESSION['UserNo'],SQLITE3_TEXT);
$stmt->execute();
header("location:main.php");
?>
