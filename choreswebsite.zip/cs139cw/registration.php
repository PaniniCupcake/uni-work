<!DOCTYPE html>
<html>
<head>
  <title>Registration</title>
  <link rel="stylesheet" href="css/main.css" type="text/css" charset="utf-8">
  <script src='js/jquery-3.6.0.min.js'></script>
  <script src='js/verify_user.js'>ready();</script>
</head>
<body>
  <h1>
    <p>Registration</p>
  </h1>
  <div id = "Main">
    <p>(Please note that there can only be one account per email adress)</p>
  <form id='form' method=post action="registration_process.php">
  <label for = "username">Enter your name</label><br>
  <input id='username' name="username"><br>
  <label for = "email">Enter your email</label><br>
  <input id='email' name="email"><br>
  <label for = "user_password">Enter your password</label><br>
  <input id='password' type='password' name='user_password'><br>
  <label for = "user_password_confirm">Confirm your password</label><br>
  <input id='password_confirm' type='password' name='user_password_confirm'><br><br>
  <input type='submit' value='Register'>
  </form>
</div>
<div id = "Menu">
<p><a href="front.html">Back</a></p>
</div>
</body>
</html>
