<?php
  session_start();
  include 'database.php';
  $data = new Database();
  $stmt = $data->prepare("SELECT * FROM Chores WHERE houseNo=:house;");
  $stmt->bindValue(':house',$_SESSION['HouseNo'],SQLITE3_INTEGER);
  echo $_SESSION['HouseNo'];
  $chores = $stmt->execute();
  $datestr = date("Y-m-d");
  $date = date_create($datestr);
  while($chore = $chores->fetchArray())
  {
    $deadline = date_create($chore['deadline']);
      if($chore['completed'] == "completed" && $deadline < $date)
      {
            if($chore['frequencyString'] == "once")//IF a chore is to be completed once, it is removed after the deadline
            {
              $stmt = $data->prepare("SELECT * FROM Users WHERE userId=:user;");
              $stmt->bindValue(':user', $chore['userNo'],SQLITE3_INTEGER);
              $users = $stmt->execute();
              $user = $users->fetchArray();
              $stmt = $data->prepare("UPDATE Users SET weight=:weight WHERE userId=:user;");
              $stmt->bindValue(':weight',$user['weight'] - $chore['difficulty'],SQLITE3_INTEGER);
              $stmt->bindValue(':user', $chore['userNo'],SQLITE3_INTEGER);
              $stmt->execute();
              $stmt = $data->prepare("DELETE FROM Chores WHERE choreNo=:chore;");
              $stmt->bindValue(':chore', $chore['choreNo'],SQLITE3_INTEGER);
              $stmt->execute();
            }
            else {//Otherwise, after the deadline it is updated to be done again after the interval
              $stmt = $data->prepare("UPDATE Chores SET completed='upcoming', deadline=:deadline WHERE choreNo=:chore;");
              $text = $chore['frequencyString'];
              $interval = "1 days";
              if($text == "week")
              {
                $interval = "7 days";
              }
              else if($text == "fortnight")
              {
                  $interval = "14 days";
              }
              else if($text == "month")
              {
                  $interval = "28 days";
              }
              date_add($deadline,date_interval_create_from_date_string($interval));
              $stmt->bindValue(':deadline',$deadline->format('Y-m-d'),SQLITE3_TEXT);
              $stmt->bindValue(':chore',$chore['choreNo'],SQLITE3_INTEGER);
              $stmt->execute();
              $chore['completed'] = "upcoming";
            }
      }
      if($chore['completed'] == "upcoming" && $deadline < $date)//If the most recent deadline is not met, it is set as overdue
      {
            $stmt = $data->prepare("UPDATE Chores SET completed='overdue' WHERE choreNo=:chore;");
            $stmt->bindValue(':chore',$chore['choreNo'],SQLITE3_TEXT);
            $res = $stmt->execute();
      }
    }
 ?>
