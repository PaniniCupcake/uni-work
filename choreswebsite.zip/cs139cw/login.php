<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" href="css/main.css" type="text/css" charset="utf-8">
  <script src='js/jquery-3.6.0.min.js'></script>
  <script src='js/verify_login.js'>ready();</script>
</head>
<body>
  <h1>
      <p>Login</p>
    </h1>
    <div id = "Main">
  <form method = post action='login_process.php'>
  <label for = "name">Enter your email</label><br>
  <input id='name' name="name"><br>
  <label for = "password">Enter your password</label><br>
  <input id='password' type='password' name='password'><br>
  <input type='submit' value='Login'>
  </form>
  </div>
  <div id = "Menu">
  <p><a href="front.html">Back</a></p>
  </div>
</body>
</html>
