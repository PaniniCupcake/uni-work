<?php
include 'database.php';
$data = new Database();
$stmt = $data->prepare("SELECT * FROM Houses WHERE houseName=:name;");
$stmt->bindValue(':name', $_POST['name'],SQLITE3_TEXT);
$houses = $stmt->execute();
$house = $houses->fetchArray();
if($house != NULL && sha1($_POST['password'] . $house['salt']) == $house['password'])//verifies the password
{
    session_start();
    $_SESSION['HouseNo'] = $house['houseNo'];
    $stmt = $data->prepare("UPDATE Users SET houseNo=:house WHERE userId=:user;");
    $stmt->bindValue(':house', $house['houseNo'],SQLITE3_TEXT);
    $stmt->bindValue(':user', $_SESSION['UserNo'],SQLITE3_TEXT);
    $result= $stmt->execute();//Sets user's house to this one
    header("location:main.php");
}
else
{
  header("location:house_login.php");
}
?>
