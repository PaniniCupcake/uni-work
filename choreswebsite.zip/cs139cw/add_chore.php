<?php
session_start();
  include 'database.php';
  $data = new Database();
  $datestr = date("Y-m-d");
  $date = date_create($datestr);
  if(!isset($_POST['frequency']))
  {
    $_POST['frequency'] = 28;
    $_POST['frequencyString'] = "day";
    $_POST['name'] = "test";
    $_POST['time'] = 15;
  }
  $text = $_POST['frequencyString'];
  $interval = "1 days";
  if($text == "week")
  {
    $interval = "7 days";
  }
  else if($text == "fortnight")
  {
      $interval = "14 days";
  }
  else if($text == "month")
  {
      $interval = "28 days";
  }
  date_add($date,date_interval_create_from_date_string($interval));//Adds the interval to the current date to get the first deadline
  $stmt = $data->prepare("SELECT * FROM Users WHERE houseNo=:house;");
  $stmt->bindValue(':house',$_SESSION['HouseNo'],SQLITE3_INTEGER);
  $users = $stmt->execute();
  $names = array();
  $numbers = array();
  $emails = array();
  $lowest_weight = 9999999;
  while($user = $users->fetchArray())//Finds the users with the least things to do and records their relevant information
  {
    if($user['weight'] < $lowest_weight)//New lowest weight, remove previous users
    {
      $names = array($user['username']);
      $numbers = array($user['userId']);
      $emails = array($user['email']);
      $lowest_weight = $user['weight'];
    }
    else if($user['weight'] == $lowest_weight)//Add to current possible users
    {
      array_push($names,$user['username']);
      array_push($numbers,$user['userId']);
      array_push($emails,$user['email']);
    }
  }
  $index = rand(0,sizeof($names)-1);//Gets a random index to increment the user lists
  $stmt = $data->prepare("UPDATE Users SET weight=:weight WHERE userId=:user;");
  $stmt->bindValue(':weight',$lowest_weight + ($_POST['frequency'] * $_POST['time']),SQLITE3_INTEGER);
  $stmt->bindValue(':user',$numbers[$index],SQLITE3_INTEGER);
  $users = $stmt->execute();
  $user = $users->fetchArray();
  //Insert the new chore
  $stmt = $data->prepare("INSERT INTO Chores VALUES (:house,:user,:username,NULL,:name,:frequency,:frequencystr,:difficulty,'upcoming',:deadline);");
  $stmt->bindValue(':house',$_SESSION['HouseNo'],SQLITE3_INTEGER);
  $stmt->bindValue(':user',$numbers[$index],SQLITE3_INTEGER);
  $stmt->bindValue(':username',$names[$index],SQLITE3_TEXT);
  $stmt->bindValue(':name',$_POST['name'],SQLITE3_TEXT);
  $stmt->bindValue(':frequency',$_POST['frequency'],SQLITE3_INTEGER);
  $stmt->bindValue(':frequencystr',$_POST['frequencyString'],SQLITE3_TEXT);
  $stmt->bindValue(':difficulty',$_POST['time'],SQLITE3_INTEGER);
  $stmt->bindValue(':deadline',$date->format('Y-m-d'),SQLITE3_TEXT);//Puts the date back into string format
  $list_data = $stmt->execute();
  mail($emails[$index],"New chore","You have been allocated a new chore");//Notifies the user of their new chore
 ?>
