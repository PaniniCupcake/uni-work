$(document).ready( function() {
 $('#form').submit(function(event) {
    console.log("Registration check verifying");
   user = $('#name').val();
   pswd = $('#password').val();
   if(user == ''||user == null || pswd == ''|| pswd == null)
   {
     alert("Please ensure sure all fields are filled in.");
     event.preventDefault();
   }
 }
 );
}
);
