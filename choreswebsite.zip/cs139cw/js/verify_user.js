$(document).ready( function() {
 $('#form').submit(function(event) {
    console.log("Registration check verifying");
   user = $('#username').val();
   email = $('#email').val();
   pswd = $('#password').val();
   pswd2 = $('#password_confirm').val();
   if(user == ''||user == null || email == '' || email == null || pswd == ''|| pswd == null || pswd2 == '' || pswd2 == null )
   {
     alert("Please ensure sure all fields are filled in.");
     event.preventDefault();
   }
   else if (!(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(email)))//Makes sure the email has the correct combination of characters
   {
     alert("Please enter a valid email.");
     event.preventDefault();
   }
   else if(pswd != pswd2)
   {
     alert("Password and password confirm must match.");
     event.preventDefault();
   }
 }
 );
}
);
