$(document).ready( function() {
  $.post("update_chores.php",
    {},
    function(){
    console.log("Chores updated");
  }//Chores are updated every time
);
  $('#form').submit(function() {
    var1 = $('#chore').val();
    var2 = 0;
    if($('#daily').is(':checked'))
    {
      var2 = 28;
      var3 = "day";
    }
    else if($('#once').is(':checked'))
    {
      var2 = 1;
      var3 = "once";
    }
    else if($('#weekly').is(':checked'))
    {
      var2 = 4;
      var3 = "week";
    }
    else if($('#fortnightly').is(':checked'))
    {
      var2 = 2;
      var3 = "fortnight";
    }
    else if($('#monthly').is(':checked'))
    {
      var2 = 1;
      var3 = "month";
    }//Checks which box is ticked
    var4 = $('#frequency').val();
    if(var1 == null || var1 == "" || var2 == 0 || var4 == null)
    {//Makes sure no field isn't filled
      alert("Please fill in all fields");
      return;
    }
    $.post("add_chore.php",
      {name: var1,
      frequency: var2,
      frequencyString: var3,
      time: var4,},
      function(data, status){
      console.log("Chore added");
      location.reload();
    }
    );
  }
  );
}
);
