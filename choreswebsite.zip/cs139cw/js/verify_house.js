$(document).ready( function() {
 $('#form').submit(function(event) {
    console.log("Registration check verifying");
   user = $('#housename').val();
   pswd = $('#house_password').val();
   pswd2 = $('#house_password_confirm').val();
   if(user == ''||user == null || pswd == ''|| pswd == null || pswd2 == '' || pswd2 == null )
   {
     alert("Please ensure sure all fields are filled in.");
     event.preventDefault();
   }
   else if(pswd != pswd2)
   {
     alert("Password and password confirm must match.");
     event.preventDefault();
   }
 }
 );
}
);
