$(document).ready( function() {
  $.post("update_chores.php",
    {},
    function(){
    console.log("Chores updated");
  }//Chores are updated every time this page is loaded
);
  $('.button').click(function()
  {
    console.log("Completed");
    $.post("complete_chore.php",
      {chore: this.id},
      function(){
      location.reload();
    }
    );
  }
  );
}
);
