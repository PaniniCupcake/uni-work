<?php
    function h($text)
    {
        return htmlspecialchars($text,ENT_QUOTES, 'utf-8');//Converts a string to special chars
    }
 ?>
