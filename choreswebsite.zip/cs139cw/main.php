<?php
  session_start();
  include 'access.php';
  if(!loggedIn())
  {
    header("location:front.html");
  }
?>
<!DOCTYPE html>

<html>
<head>
  <title>Home</title>
  <link rel="stylesheet" href="css/main.css" type="text/css" charset="utf-8">
</head>
<body>
  <h1>
    <p>Home</p>
  </h1>
  <div id = "Main">

    <?php
    if($_SESSION['HouseNo'] == NULL)//Checks if the user is in a house, and gives the option to join one if they are not
    {
      echo "<p>You don't seem to be in a house right now.</p> <p> <a href='newhouse.php'>Set up a house</a><p> <p> <a href='house_login.php'>Access existing house</a> <p>";
    }
    else {
      include 'database.php';
      include 'security.php';
      $data = new Database();
      $stmt = $data->prepare("SELECT * from Houses WHERE houseNo = :house ;");
      $stmt->bindValue(':house', $_SESSION['HouseNo'],SQLITE3_INTEGER);
      $houses = $stmt->execute();
      $house = $houses->fetchArray();
      echo "<p class='underline'>The household " . h($house['houseName']) . " contains these users: </p><ul>";
      $stmt = $data->prepare("SELECT * from Users WHERE houseNo = :house ;");
      $stmt->bindValue(':house', $_SESSION['HouseNo'],SQLITE3_INTEGER);
      $users = $stmt->execute();
      while($user = $users->fetchArray())
      {//Lists the house's users
        echo "<li>". h($user['username']) ."</li>";
      }
      echo "</ul>";
      echo "<p> <a href='chores.php'>View / edit home's chores</a><p>";
      echo "<p> <a href='my_chores.php'>My chores</a><p>";
      echo "<p> <a href='leave_house.php'>Leave house</a><p>";
    }
   ?>
  </div>
  <div id = "Menu">
  <p><a href="logout.php">Logout</a></p>
  </div>
  </body>
</html>
