<?php
  session_start();
  include 'access.php';
  if(!loggedIn())
  {
    header("location:front.html");
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Setup house</title>
  <link rel="stylesheet" href="css/main.css" type="text/css" charset="utf-8">
  <script src='js/jquery-3.6.0.min.js'></script>
  <script src='js/verify_house.js'>ready();</script>
</head>
<body>
  <h1>
    <p>House setup</p>
  </h1>
  <div id = "Main">
    <p>(Please note creating multiple houses with the same name is not allowed)</p>
  <form id='form' method=post action="newhouse_process.php">
  <label for = "housename">Enter house name</label><br>
  <input id='housename' name="housename"><br>
  <label for = "house_password">Enter house password</label><br>
  <input id='house_password' type='password' name='house_password'><br>
  <label for = "user_password_confirm">Confirm house password</label><br>
  <input id='house_password_confirm' type='password' name='house_password_confirm'><br><br>
  <input type='submit' value='Create house'>
  </form>
</div>
<div id = "Menu">
<p><a href="main.php">Back</a></p>
</div>
</body>
</html>
