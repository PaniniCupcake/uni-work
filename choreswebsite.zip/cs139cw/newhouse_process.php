<?php
include 'database.php';
$data = new Database();
$stmt = $data->prepare("SELECT houseName FROM Houses WHERE houseName = :name ;");
$stmt->bindValue(':name', $_POST['housename'],SQLITE3_TEXT);
$nameFound = $stmt->execute();
if($nameFound->fetchArray() != NULL)
{
   header("location:newhouse.php");
}
else
{
  $salt = sha1(date("h:i:sa"));
  $pswd = sha1($_POST['house_password'] . $salt);
  $stmt = $data->prepare("INSERT INTO Houses VALUES (NULL,:name,:salt,:pswd);");
  $stmt->bindValue(':name', $_POST['housename'],SQLITE3_TEXT);
  $stmt->bindValue(':salt', $salt ,SQLITE3_TEXT);
  $stmt->bindValue(':pswd', $pswd,SQLITE3_TEXT);
  $result = $stmt->execute();
  $stmt = $data->prepare("SELECT * FROM Houses WHERE houseName=:name;");
  $stmt->bindValue(':name', $_POST['housename'],SQLITE3_TEXT);
  $houses = $stmt->execute();
  $house = $houses->fetchArray();
  session_start();
  $_SESSION['HouseNo'] = $house['houseNo'];
  $stmt = $data->prepare("UPDATE Users SET houseNo=:house WHERE userId=:user;");
  $stmt->bindValue(':house', $house['houseNo'],SQLITE3_TEXT);
  $stmt->bindValue(':user', $_SESSION['UserNo'],SQLITE3_TEXT);
  $result= $stmt->execute();
  header("location:main.php");
}

?>
