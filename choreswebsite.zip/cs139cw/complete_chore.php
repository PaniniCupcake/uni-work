<?php
session_start();
include 'access.php';
if(!loggedIn())
{
  header("location:front.html");
}
include 'database.php';
$data = new Database();
$stmt = $data->prepare("SELECT * FROM Chores WHERE choreNo=:chore;");
$stmt->bindValue(':chore', $_POST['chore'],SQLITE3_INTEGER);
$chores = $stmt->execute();
$chore = $chores->fetchArray();
$stmt = $data->prepare("UPDATE Chores SET completed='completed' WHERE choreNo=:chore;");
$stmt->bindValue(':chore', $chore['choreNo'],SQLITE3_INTEGER);//Sets the status of the chore to complete
$stmt->execute();
?>
