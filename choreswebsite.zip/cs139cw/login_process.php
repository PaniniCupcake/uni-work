<?php
include 'database.php';
$data = new Database();
$stmt = $data->prepare("SELECT * FROM Users WHERE email=:email;");
$stmt->bindValue(':email', $_POST['name'],SQLITE3_TEXT);
$users = $stmt->execute();
$user = $users->fetchArray();
if($user != NULL && sha1($_POST['password'] . $user['salt']) == $user['password'])//Adds the user if they are existing
{
    session_start();
    $_SESSION['UserNo'] = $user['userId'];
    $_SESSION['HouseNo'] = $user['houseNo'];
    header("location:main.php");
}
else
{
  header("location:login.php");
}
?>
