<?php
  session_start();
  include 'access.php';
  if(!loggedIn())
  {
    header("location:front.html");
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Your chores</title>
  <link rel="stylesheet" href="css/main.css" type="text/css" charset="utf-8">
  <script src='js/jquery-3.6.0.min.js'></script>
  <script src='js/complete_chore.js'>ready();</script>
</head>
<body>
  <h1>
    <p>All chores</p>
  </h1>
  <div id = "Main">
    <?php

      include 'database.php';
      include 'security.php';
      $data = new Database();
      $stmt = $data->prepare("SELECT * from Chores WHERE userNo = :user;");
      $stmt->bindValue(':user', $_SESSION['UserNo'],SQLITE3_INTEGER);
      $chores = $stmt->execute();
      echo "<p class='underline'>These are your chores: </p>";
      while($chore = $chores->fetchArray())
      {
        if($chore['frequencyString'] == "once")
        {
          echo "". h($chore['choreName']) ." once is " . h($chore['completed']) . " (deadline " . h($chore['deadline']) . ")     ";
        }
        else
        {
          echo "". h($chore['choreName']) ." every " . h($chore['frequencyString']) . " is " . h($chore['completed']) . " (deadline " . h($chore['deadline']) . ")     ";
        }
        if($chore['completed'] == "upcoming" || $chore['completed'] == "overdue")//Gives the option to complete a chore if it isn't completed
        {
          echo "<button id = '". h($chore['choreNo']) ."' class='button' type='button'> Completed </button>";
        }
        echo "<br>";
      }
   ?>
  </div>
  <div id = "Menu">
  <p><a href="main.php">Back</a></p>
  </div>
  </body>
</html>
