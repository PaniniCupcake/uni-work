The site has been tested on google chrome.
It allows users to set up and join houses. Users must not be in a house to join a new one.
A user can complete their chores on their chores page and add them on the all chores page.
Users are given a weight depending on the length and frequency of the chore. Chore weight is determined by frequency and length.
New chores are allocated to the lowest weighted users.
When a chore is added, the person it is designated to receives an email.
Chores are checked whether their complete status should be modified when relevant pages are accessed.


Chores with a frequency of once are deleted after a month if completed, and are weighted like monthly chores.

Necessary strings are converted to html special chars. Users can not access pages while not logged in. Queries are prepared to take care of security.

Dates are formatted in YYYY-MM-DD time as it is the default storage method for sql, and other formats mess up with date_add
