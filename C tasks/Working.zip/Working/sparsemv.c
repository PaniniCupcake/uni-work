#include <stdlib.h>
#include <ctype.h>
#include <assert.h>
#include <math.h>

#include "sparsemv.h"

/**
 * @brief Compute matrix vector product (y = A*x)
 *
 * @param A Known matrix
 * @param x Known vector
 * @param y Return vector
 * @return int 0 if no error
 */
int sparsemv(struct mesh *A, const double * const x, double * const y)
{
    const int nrow = (const int) A->local_nrow;
  #pragma omp parallel for
    for (int i=0; i< nrow; i++) {
        double sum = 0.0;
        const double * const cur_vals = (const double * const) A->ptr_to_vals_in_row[i];
        const int * const cur_inds = (const int * const) A->ptr_to_inds_in_row[i];
        const int cur_nnz = (const int) A->nnz_in_row[i];
        int loop_nnz = (cur_nnz/4)*4;
        int j = 0;
        for (; j< loop_nnz; j+=4) {
          sum += cur_vals[j]*x[cur_inds[j]];
          sum += cur_vals[j+1]*x[cur_inds[j+1]];
          sum += cur_vals[j+2]*x[cur_inds[j+2]];
          sum += cur_vals[j+3]*x[cur_inds[j+3]];
        }
        for (; j< cur_nnz; j++) {
          sum += cur_vals[j]*x[cur_inds[j]];
        }
        y[i] = sum;
      }
    return 0;
}
/*for (i = 0; i< loopnrow; i+=4)
{
  double sum = 0.0;
  double sum2 = 0.0;
  double sum3 = 0.0;
  double sum4 = 0.0;
  const double * const cur_vals = (const double * const) A->ptr_to_vals_in_row[i];
  const int * const cur_inds = (const int * const) A->ptr_to_inds_in_row[i];
  const int cur_nnz = (const int) A->nnz_in_row[i];
  const int loop_nnz = (cur_nnz /4) * 4;
  const double * const cur_vals2 = (const double * const) A->ptr_to_vals_in_row[i+1];
  const int * const cur_inds2 = (const int * const) A->ptr_to_inds_in_row[i+1];
  const int cur_nnz2 = (const int) A->nnz_in_row[i+1];
  const int loop_nnz2 = (cur_nnz2 /4) * 4;
  const double * const cur_vals3 = (const double * const) A->ptr_to_vals_in_row[i+2];
  const int * const cur_inds3 = (const int * const) A->ptr_to_inds_in_row[i+2];
  const int cur_nnz3 = (const int) A->nnz_in_row[i+2];
  const int loop_nnz3 = (cur_nnz3 /4) * 4;
  const double * const cur_vals4 = (const double * const) A->ptr_to_vals_in_row[i+3];
  const int * const cur_inds4 = (const int * const) A->ptr_to_inds_in_row[i+3];
  const int cur_nnz4 = (const int) A->nnz_in_row[i+3];
  const int loop_nnz4 = (cur_nnz4 /4) * 4;
  int k = 0;
  for(;k<loop_nnz && k < loop_nnz2 && k < loop_nnz3 && k < loop_nnz4;k += 4)
  {
    sum += cur_vals[k]*x[cur_inds[k]];
    sum += cur_vals[k+1]*x[cur_inds[k+1]];
    sum += cur_vals[k+2]*x[cur_inds[k+2]];
    sum += cur_vals[k+3]*x[cur_inds[k+3]];
    sum2 += cur_vals2[k]*x[cur_inds2[k]];
    sum2 += cur_vals2[k+1]*x[cur_inds2[k+1]];
    sum2 += cur_vals2[k+2]*x[cur_inds2[k+2]];
    sum2 += cur_vals2[k+3]*x[cur_inds2[k+3]];
    sum3 += cur_vals3[k]*x[cur_inds3[k]];
    sum3 += cur_vals3[k+1]*x[cur_inds3[k+1]];
    sum3 += cur_vals3[k+2]*x[cur_inds3[k+2]];
    sum3 += cur_vals3[k+3]*x[cur_inds3[k+3]];
    sum4 += cur_vals4[k]*x[cur_inds4[k]];
    sum4 += cur_vals4[k+1]*x[cur_inds4[k+1]];
    sum4 += cur_vals4[k+2]*x[cur_inds4[k+2]];
    sum4 += cur_vals4[k+3]*x[cur_inds4[k+3]];
  }
  for (int j=k; j< cur_nnz; j++) {
    sum += cur_vals[j]*x[cur_inds[j]];
  }
  for (int j=k; j< cur_nnz2; j++) {
    sum2 += cur_vals2[j]*x[cur_inds2[j]];
  }
  for (int j=k; j< cur_nnz3; j++) {
    sum3 += cur_vals3[j]*x[cur_inds3[j]];
  }
  for (int j=k; j< cur_nnz4; j++) {
    sum4 += cur_vals4[j]*x[cur_inds4[j]];
  }
  y[i] = sum;
  y[i+1] = sum2;
  y[i+2] = sum3;
  y[i+3] = sum4;
}
for (; i< nrow; i++) {
  double sum = 0.0;
  const double * const cur_vals = (const double * const) A->ptr_to_vals_in_row[i];
  const int * const cur_inds = (const int * const) A->ptr_to_inds_in_row[i];
  const int cur_nnz = (const int) A->nnz_in_row[i];

  for (int j=0; j< cur_nnz; j++) {
    sum += cur_vals[j]*x[cur_inds[j]];
  }
  y[i] = sum;
}*/
