#ifndef COMPUTE_RESIDUAL_H
#define COMPUTE_RESIDUAL_H
int compute_residual(const int n, const double * const v1, const double * const v2, double * const residual);
#endif
