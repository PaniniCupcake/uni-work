#include "analysis.h"
#include "avltree.h"

#include <pcap.h>
#include <netinet/if_ether.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

int total_syn = 0;
int unique_syn = 0;
struct avl_tree *tree;
int arp_count = 0;
int blacklist_violations = 0;

pthread_mutex_t s_lock;//Locks for syn, arp and blacklist
pthread_mutex_t a_lock;
pthread_mutex_t b_lock;

void makeTree()
{
  tree = malloc(sizeof(struct avl_tree));
  tree->root = NULL;
}
void destroyTree()
{
  if(tree->root != NULL)
  {
    destroy_tree(tree->root);
  }
  free(tree);
}

void getResults()//Returns values required
{
  puts("\nIntrusion detection report:\n");
  printf("%d SYN packets detected from %d IP (syn attack)\n",total_syn,unique_syn);
  printf("%d ARP responses (cache poisoning)\n",arp_count);
  printf("%d URL Blacklist violations\n",blacklist_violations);
}

void analyse(struct pcap_pkthdr * header, const unsigned char * packet) {
  
  //Ethernet
  struct ether_header *eth_header = (struct ether_header *) packet;
  unsigned short protocol = ntohs(eth_header->ether_type);

  //Internet
  struct ip *ip_header = (struct ip *) (packet+14);
  
  //Transport
  struct tcphdr *tcp_header = (struct tcphdr *) (packet+14+ip_header->ip_hl*4);
  
  if(protocol == 2048)//Checking if IPv4
  {
    if(ip_header->ip_p == 6)
    {
      if(tcp_header->syn)
      {
        pthread_mutex_lock(&s_lock);
        total_syn ++;
        char * str = inet_ntoa(ip_header->ip_src);//Converts IP to string for ease of storage
        insert_root(str,tree,&unique_syn);//Adds IP to tree so we know it has been seen before
        pthread_mutex_unlock(&s_lock);
      }
      if(ntohs(tcp_header->th_dport) == 80 && (header->len-(14+ip_header->ip_hl*4 + tcp_header->th_off*4) != 0))//Checking port and if it contains necessary information
      {
        char * data = (char *) (packet + 14 + ip_header->ip_hl*4 +tcp_header->th_off*4);
        
        if(strstr(data,"www.bbc.com")|| strstr(data,"www.google.co.uk"))
        {
          pthread_mutex_lock(&b_lock);
          blacklist_violations ++;  
          pthread_mutex_unlock(&b_lock);
          printf("\n==============================\n");
          printf("Blacklisted URL violation detected\n");
          printf("Source IP address: %s\n",inet_ntoa(ip_header->ip_src));
          printf("Destination IP address: %s\n",inet_ntoa(ip_header->ip_dst));
          printf("==============================\n\n");
        }
      }
    }
  }
  else if(protocol == 2054) //Arp
  {
      
      struct ether_arp * response = (struct ether_arp *) (packet + 14);
      if(ntohs((response->ea_hdr).ar_op) == 2)//Adds to counter if it is an arp response
      {
        pthread_mutex_lock(&a_lock);
        arp_count ++;
        pthread_mutex_unlock(&a_lock);
      }
  }
}
