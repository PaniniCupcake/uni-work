#include "dispatch.h"
#include "analysis.h"
#include "queue.h"

#include <pcap.h>
#include <pthread.h>
#include <stdlib.h>

pthread_mutex_t lock;
pthread_cond_t cond;
struct queue * thread_queue;

void makeQueue()
{
  thread_queue = create_queue();  
}

void destroyQueue()
{
  destroy_queue(thread_queue);
}

void *parse_queue(void *arg)
{
  while(1)
  {
    pthread_mutex_lock(&lock);
    while(isempty(thread_queue))
    {
      pthread_cond_wait(&cond, &lock);
    }
  struct pcap_pkthdr *header = thread_queue->head->header;
  const unsigned char *packet = thread_queue->head->packet;
  dequeue(thread_queue);
  pthread_mutex_unlock(&lock);
  analyse(header,packet);
  }
}

void dispatch(u_char * unused, struct pcap_pkthdr *header, const u_char *packet) {
  pthread_mutex_lock(&lock);
  struct pcap_pkthdr * header_copy = malloc(sizeof(struct pcap_pkthdr));
  *header_copy = *header;
  enqueue(thread_queue,header_copy,packet);
  pthread_cond_broadcast(&cond);
  pthread_mutex_unlock(&lock);
}


