#ifndef Queue
#define Queue

struct node{ // data structure for each node
  struct pcap_pkthdr *header;
  const unsigned char *packet;
  struct node *next;
};

struct queue{ // data structure for queue
  struct node *head;
  struct node *tail;
};

struct queue *create_queue(void);

int isempty(struct queue *q);

void enqueue(struct queue *q, struct pcap_pkthdr * header, const unsigned char * packet);

void dequeue(struct queue *q);

void printqueue(struct queue *q);

void destroy_queue(struct queue *q);

#endif
