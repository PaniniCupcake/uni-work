#ifndef CS241_DISPATCH_H
#define CS241_DISPATCH_H

#include <pcap.h>

void dispatch(u_char * unused, struct pcap_pkthdr *header, const u_char *packet);

void makeQueue();
void destroyQueue();
void *parse_queue(void *arg);

#endif


