#ifndef AvlTree
#define AvlTree

struct avl_tree{
  struct avl_node *root;  
};

struct avl_node{ 
  char * value;
  int height;
  struct avl_node *left_child;
  struct avl_node *right_child;
};

void insert_root(char * val,struct avl_tree *tree, int *size);

void traverse(struct avl_node *root);

void destroy_tree(struct avl_node *root);

#endif
