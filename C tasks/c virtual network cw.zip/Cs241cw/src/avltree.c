#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avltree.h"



void traverse(struct avl_node *root)
{
   if(root->left_child != NULL)
   {
      traverse(root->left_child);
   }
   puts(root->value);
   if(root->right_child != NULL)
   {
      traverse(root->right_child);
   }
}

int max(int a,int b)
{
   return (a > b) ? a : b;
}

int height(struct avl_node * node)
{
   if(node == NULL)
   {
      return 0;
   }
   return node->height;
}

struct avl_node * rightRotate(struct avl_node *y)
{
   struct avl_node *x = y->left_child;
   struct avl_node *z = x->right_child;
   x->right_child = y;
   y->left_child = z;
   y->height = max(height(y->left_child), height(y->right_child)) + 1;
   x->height = max(height(x->left_child), height(x->right_child)) + 1;
   return x;
}

struct avl_node * leftRotate(struct avl_node *x)
{
   struct avl_node *y = x->right_child;
   struct avl_node *z = y->left_child;
   y->left_child = x;
   x->right_child = z;
   x->height = max(height(x->left_child), height(x->right_child)) + 1;
   y->height = max(height(y->left_child), height(y->right_child)) + 1;
   return y;
}

struct avl_node * insert_node(char * val,struct avl_node *root, int * size)
{
   if(strcmp(root->value,val) == 0)
   {
      return root;
   }
   int balance_factor;
   if(strcmp(root->value,val) < 0)
   {
      if(root->right_child == NULL)//If there are no nodes left to check, add a new node
      {
         struct avl_node * child = malloc(sizeof(struct avl_node));
         child->value = malloc((15)*sizeof(char));
         strcpy(child->value,val);
         child->height = 1;
         child->left_child = NULL;
         child->right_child = NULL;
         root->right_child = child;
         *size = *size + 1;
         return root;
      }	
      root->right_child = insert_node(val,(root->right_child),size);
   }
   else
   {
      if(root->left_child == NULL)
      {
         struct avl_node * child = malloc(sizeof(struct avl_node));
         child->value = malloc((15)*sizeof(char));
         strcpy(child->value,val);
         child->height = 1;
         child->left_child = NULL;
         child->right_child = NULL;
         root->left_child = child;
         *size = *size + 1;
         return root;
      }	
      root->left_child = insert_node(val,(root->left_child),size);
   }
   int left_height = height(root->left_child);
   int right_height = height(root->right_child);
   root->height = max(left_height,right_height) + 1;
   balance_factor = left_height - right_height;
   if (balance_factor > 1) //Rebalance tree if balance is off
   {
      if (strcmp(val,(root->left_child)->value) < 0)
      {
         return rightRotate(root);
      }
      else if (strcmp(val,(root->left_child)->value) > 0)
      {
         root->left_child = (leftRotate(root->left_child));
         return rightRotate(root);
      }
   }
   else if (balance_factor < -1)
   {
      if (strcmp(val,(root->right_child)->value) > 0)
      {
         return leftRotate(root);
      }
      else if (strcmp(val,(root->right_child)->value) < 0)
      {
         root->right_child = rightRotate(root->right_child);	
         return leftRotate(root);
      }
   }
   return root;
}

void insert_root(char * val,struct avl_tree *tree, int * size)
{
   if(tree->root == NULL)//Create a new root if none exists
   {
      struct avl_node * child = malloc(sizeof(struct avl_node));
      child->value = malloc((15)*sizeof(char));
      strcpy(child->value,val);
      child->left_child = NULL;
      child->right_child = NULL;
      tree->root = child;
      *size = *size + 1;
   }
   else
   {
      tree->root = insert_node(val,tree->root,size);
   }
}

void destroy_tree(struct avl_node *root){  //destroys the queue and frees the memory
   if(root->left_child != NULL)
   {
      destroy_tree(root->left_child);
   }
   if(root->right_child != NULL)
   {
      destroy_tree(root->right_child);
   }
   free(root);
}
