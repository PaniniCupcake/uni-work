# CS126 WAFFLES Coursework Report [1234567]
<!-- This document gives a brief overview about your solution.  -->
<!-- You should change number in the title to your university ID number.  -->
<!-- You should delete these comments  -->
<!-- And for the latter sections should delete and write your explanations in them. -->
<!-- # <-- Indicates heading, ## <-- Indicates subheading, and so on -->

## CustomerStore
### Overview
<!-- A short description about what structures/algorithms you have implemented and why you used them. For example: -->
<!-- The template is only a guide, you are free to make any changes, add any bullets points, re-word it entirely, etc. -->
<!-- * <- is a bullet point, you can also use - minuses or + pluses instead -->
<!-- And this is *italic* and this is **bold** -->
<!-- Words in the grave accents, or in programming terms backticks, formats it as code: `put code here` -->
* I have used an two AVL Tree structures to store and process customers because they maintain a log(n) search time complexity by conserving the balance of the tree. I used two so I can easily access elements sorted by ID and alphabetically. I also used an AVL tree for the blacklist.
* I used Trees to sort customers by name and ID since they are easier to implement generically, but still have O(nlog(n)) complexity.

<!--I know this has a complexity of m*n, but I have removed irrelevant values assuming n scales to infinity. -->
### Space Complexity
<!-- Write here what you think the overall store space complexity is and gives a brief reason why. -->
<!-- <br> gives a line break -->
<!-- In tables, you don't really need the spaces, it only makes it look nice in text form -->
<!-- You can just do "CustomerStore|O(n)|I have used a single `ArrayList` to store customers." -->
Store         | Worst Case | Description
------------- | ---------- | -----------
CustomerStore | O(2n)       | I have used a two AVL trees, <br>Where `n` is total customers added. <br> It is not possible for values to appear in the main trees and the blacklist

### Time Complexity
<!-- Tell us the time complexity of each method and give a very short description. -->
<!-- These examples may or may not be correct, these examples have not taken account for other requirements like duplicate IDs and such.  -->
<!-- Again, the template is only a guide, you are free to make any changes. -->
<!-- If you did not do a method, enter a dash "-" -->
<!-- Technically, for the getCustomersContaining(s) average case, you are suppose to do it relative to s -->
<!-- Note, that this is using the original convertToAccents() method -->
<!-- So O(a*s + n*(a*t + t)) -->
<!-- Where a is the amount of accents -->
<!-- Where s is the length of the search term String  -->
<!-- Where t is the average length of a name -->
<!-- Where n is the total number of customers -->
<!-- But you can keep it simple -->

Method                           | Average Case     | Description
-------------------------------- | ---------------- | -----------
addCustomer(Customer c)          | O(log(n))        | Adding to an AVL Tree has a complexity of log(n), where `n` is the current size of the tree
addCustomer(Customer[] c)        | O(mlog(n + m))       | Performing addCustomer `m` times
getCustomer(Long id)             | O(log(n))        | Tree search <br>`n` is total customers in the store
getCustomers()                   | O(n))             | Tree traversal converted into array of length `n`, where <br>`n` is total customers in the store
getCustomers(Customer[] c)       | O(nlog(n)))      | Sort customers using a tree sort, where `n` is the length of the array
getCustomersByName()             | O(n)           | Tree traversal converted into array of length `n`, where <br>`n` is total customers in the store
getCustomersByName(Customer[] c) |  O(nlog(n)))      | Sort customers using a tree sort, where `n` is the total customers in the store
getCustomersContaining(String s) | O(n*b) | Searches all customers <br>`n` is total customers <br>`b` is average string search time

<!-- Don't delete these <div>s! -->
<!-- And note the spacing, do not change -->
<!-- This is used to get a page break when we convert your report to PDF to read when marking -->
<!-- It is not the end of the world if you do remove, it just makes it harder to read if you do -->
<!-- On things you can remove though, you should remember to remove these comments -->
<div style="page-break-after: always;"></div>

## FavouriteStore
### Overview
* I have used three AVL trees to store favourites in order of ID, and grouped by customer ID and restaurant ID as they have log(n) add and search complexity. The latter two trees contain further trees containing elements with the same relevant ID. I also used AVL trees for the blacklist and outdated values.
* I used Trees to sort customers since they are easier to implement generically, but still have O(nlog(n)) complexity.
* To get favourites by customer or restaurant ID, I simply found the relevant position in the respective tree and returned all values stored in that id's node
* To get customer reviewed restaurants relative to other's customer reviewed restaurants, I got the relevant values in the customer Tree and compared them with the values in the other.
* To get top customers / restaurants, I got the size of the tree of customers for each respective ID in the parent trees, then sorted accordingly

### Space Complexity
Store          | Worst Case | Description
-------------- | ---------- | -----------
FavouriteStore | O(3n)     | d

### Time Complexity
Method                                                          | Average Case     | Description
--------------------------------------------------------------- | ---------------- | -----------
addFavourite(Favourite f)                                       | O(log(n))           | Adds three values to AVL trees, where `n` is the number of values in the tree
addFavourite(Favourite[] f)                                     | O(mlog(n + m))       | Performing addFavourite `m` times
getFavourite(Long id)                                           | O(log(n))           | Getting values from a tree of length `n`
getFavourites()                                                 | O(n)           | Traversing tree of length `n`, then converting it into an array
getFavourites(Favourite[] f)                                    | O(nlog(n))           |Tree sorting the input array, where `n` is the length of the array
getFavouritesByCustomerID(Long id)                              | O(nlog(n)           | Finding the subtree with the correct customerID, then tree sorting them, where `n` is the values with the right customerID in the store
getFavouritesByRestaurantID(Long id)                            | O((n))log((n))           | Finding the subtree with the correct restaurantID, then tree sorting them, where `n` is the values with the right restaurantID in the store
getCommonFavouriteRestaurants(<br>&emsp; Long id1, Long id2)    | O((n+m)log((n+m))))           | Finding the subtrees with the correct customerID, then tree sorting the values in them that compare correctly, where `n` is the values with the right first customerID and `m` is the values with the right second customerID in the store
getMissingFavouriteRestaurants(<br>&emsp; Long id1, Long id2)   | O((n+m)log((n+m)))           | Finding the subtrees with the correct customerID, then tree sorting the values in them that compare correctly, where `n` is the values with the right first customerID and `m` is the values with the right second customerID in the store
getNotCommonFavouriteRestaurants(<br>&emsp; Long id1, Long id2) |O((n+m)log((n+m)))           | Finding the subtrees with the correct customerID, then tree sorting the values in them that compare correctly, where `n` is the values with the right first customerID and `m` is the values with the right second customerID in the store
getTopCustomersByFavouriteCount()                               | O(nlog(n)            | Finding the size of subtrees with a correct customerID, then tree sorting them, where `n` is the number of unique customers in the store
getTopRestaurantsByFavouriteCount()                             | O(nlog(n)           | Finding the size of subtrees with a correct restaurantID, then tree sorting them, where `n` is the number of unique customers in the store

<div style="page-break-after: always;"></div>

## RestaurantStore
### Overview

* I have used an two AVL Tree structures to store and process customers because they maintain a log(n) search time complexity by conserving the balance of the tree. I used two so I can easily access elements sorted by ID and alphabetically. I also used an AVL tree for the blacklist.
* I used Trees to sort customers since they are easier to implement generically, but still have O(nlog(n)) complexity.

### Space Complexity
Store           | Worst Case | Description
--------------- | ---------- | -----------
RestaurantStore | O(2n)     | I have used a two AVL trees, <br>Where `n` is total customers added.

### Time Complexity
Method                                                                        | Average Case     | Description
----------------------------------------------------------------------------- | ---------------- | -----------
addRestaurant(Restaurant r)                                                   | O(log(n))         | Adding to an AVL Tree has a complexity of log(n), where `n` is the current size of the tree
addRestaurant(Restaurant[] r)                                                 | O(mlog(n + m))           | Calling addRestaurant `m` times
getRestaurant(Long id)                                                        | O(log(n))           | Getting from the ID tree, where `n` is the number of items in the store
getRestaurants()                                                              | O(n)           | Converting the ID tree to an array, where `n` is the number of items in the store
getRestaurants(Restaurant[] r)                                                | O(nlog(n))           | Tree sorting the input values, where `n` is the length of the input array
getRestaurantsByName()                                                        | O(nlog(n))           | Tree sorting the alphabetical tree, where `n` is the number of items in the store
getRestaurantsByDateEstablished()                                             | O(nlog(n))           | Tree sorting the ID Tree, where `n` is the number of items in the store
getRestaurantsByDateEstablished(<br>&emsp; Restaurant[] r)                    | O(nlog(n))           | Tree sorting the ID Tree, where `n` is the number of items in the input array
getRestaurantsByWarwickStars()                                                | O(nlog(n))          | Tree sorting the ID Tree, where `n` is the number of items in the store
getRestaurantsByRating(Restaurant[] r)                                        | O(nlog(n))           | Tree sorting the ID Tree, where `n` is the number of items in the input array
getRestaurantsByDistanceFrom(<br>&emsp; float lat, float lon)                 | O(nlog(n))          | Tree sorting the ID Tree, where `n` is the number of items in the store
getRestaurantsByDistanceFrom(<br>&emsp; Restaurant[] r, float lat, float lon) | O(nlog(n))           | Tree sorting the ID Tree, where `n` is the number of items in the input array
getRestaurantsContaining(String s)                                            | O(n)       | Finding values in the alphabetical tree containing the input string somewhere, where `n` is the total values in the store

<div style="page-break-after: always;"></div>

## ReviewStore
### Overview
* I have used three AVL trees to store reviews in order of ID, and grouped by customer ID and restaurant ID as they have log(n) add and search complexity. The latter two trees contain further trees containing elements with the same relevant ID. I also used AVL trees for the blacklist and outdated values.
* I used Trees to sort customers since they are easier to implement generically, but still have O(nlog(n)) complexity.
* To get favourites by customer or restaurant ID, I simply found the relevant position in the respective tree and returned all values stored in that id's node
* To get customer reviewed restaurants relative to other's customer reviewed restaurants, I got the relevant values in the customer Tree and compared them with the values in the other.
* To get top customers / restaurants, I got the size of the tree of customers for each respective ID in the parent trees, then sorted accordingly

### Space Complexity
Store           | Worst Case | Description
--------------- | ---------- | -----------
ReviewStore     | O(3n)     | I have used a three AVL trees, <br>Where `n` is total customers added.

### Time Complexity
Method                                     | Average Case     | Description
------------------------------------------ | ---------------- | -----------
addReview(Review r)                        | O(log(n))           | Adds three values to AVL trees, where `n` is the number of values in the tree
addReview(Review[] r)                      | O(mlog(n + m))       | Performing addFavourite `m` times
getReview(Long id)                         | O(log(n))           | Getting values from a tree of length `n`
getReviews()                               | O(n)           | Traversing tree of length `n`, then converting it into an array
getReviews(Review[] r)                     | O(nlog(n))           |Tree sorting the input array, where `n` is the length of the array
getReviewsByDate()                         | O(nlog(n))          | Tree sorting the stored values, where `n` is the total values in the store.
getReviewsByRating()                       | O(nlog(n))          | Tree sorting the stored values, where `n` is the total values in the store.
getReviewsByRestaurantID(Long id)          | O(nlog(n))         | Finding the subtree with the correct customerID, then tree sorting them, where `n` is the values with the right customerID in the store
getReviewsByCustomerID(Long id)            | O(nlog(n))         | Finding the subtree with the correct restaurantID, then tree sorting them, where `n` is the values with the right restaurantID in the store
getAverageCustomerReviewRating(Long id)    | O(n)          | Converting the subtree with the correct customerID to an arrayList, then tallying up its values and dividing them by its size, where n is the number of customers with that id in the store
getAverageRestaurantReviewRating(Long id)  | O(n)            | Converting the subtree with the correct restaurantID to an arrayList, then tallying up its values and dividing them by its size, where n is the number of restaurants with that id in the store
getCustomerReviewHistogramCount(Long id)   | O(n)           | Converting the subtree with the correct customerID to an arrayList, then tallying up how many reviews there are for each rating, where n is the number of customers with that id in the store
getRestaurantReviewHistogramCount(Long id) | 0(n))           | Converting the subtree with the correct customerID to an arrayList, then tallying up how many reviews there are for each rating, where n is the number of restaurants with that id in the store
getTopCustomersByReviewCount()             | O(nlog(n))           | Finding the size of subtrees with a correct customerID, then tree sorting them, where `n` is the number of unique customers in the store
getTopRestaurantsByReviewCount()           | O(nlog(n))           | Finding the size of subtrees with a correct restaurantID, then tree sorting them, where `n` is the number of unique restaurants in the store
getTopRatedRestaurants()                   | O(nlog(n))           | Finding the average rating of the traversed subtrees with a correct restaurantID using `getAverageRestaurantReviewRating()`, then tree sorting them, where `n` is the number of unique restaurants in the store
getTopKeywordsForRestaurant(Long id)       | O(anlog(n))           | Tallying up the appearances of a keyword in the subtree for that restaurantID, then tree sorting them, where `n` is the number of reviews for that restaurant, and `a` is the average length of the review strings
getReviewsContaining(String s)             | O(nlog(n))       | Finding values in the ID tree containing the input string somewhere, then tree sorting them, where `n` is the total values in the store

<div style="page-break-after: always;"></div>

## Util
### Overview
* **ConvertToPlace**
    * Generates a hashmap of all the keywords, and then uses that hashmap to easily find whether a
* **DataChecker**
    * Verifies that all fields are null and within the correct range. Makes sure Ids fulfil the criteria
* **HaversineDistanceCalculator (HaversineDC)**
    * Just applies a formulae to the input values
* **KeywordChecker**
    * Uses a hashmap to check whether a word is a keyword
* **StringFormatter**
    * Uses a hashmap to check whether a character is special and needs to be replaced by the value stored in the map.

### Space Complexity
Util               | Worst Case | Description
-------------------| ---------- | -----------
ConvertToPlace     | O(n)     | A hashmap storing `n` values
DataChecker        | O(1)     | Stores no data
HaversineDC        | O(1)     | Stores no data
KeywordChecker     | O(n)     | A hashmap storing `n` values
StringFormatter    | O(n)     | A hashmap storing `n` values

### Time Complexity
Util              | Method                                                                             | Average Case     | Description
----------------- | ---------------------------------------------------------------------------------- | ---------------- | -----------
ConvertToPlace    | convert(float lat, float lon)                                                      | O(a/b)           | Accesses a value in a hash map, where `a` is the size of the array added to the hashmap and `b` is the capacticty of the hashmap
DataChecker       | extractTrueID(String[] repeatedID)                                                 | O(1)           | Performs an operation that is unaffected in length by the input data
DataChecker       | isValid(Long id)                                                                   | O(1)           | Performs an operation that is unaffected in length by the input data
DataChecker       | isValid(Customer customer)                                                         | O(1)           | Performs an operation that is unaffected in length by the input data
DataChecker       | isValid(Favourite favourite)                                                       | O(1)           | Performs an operation that is unaffected in length by the input data
DataChecker       | isValid(Restaurant restaurant)                                                     | O1)           | Performs an operation that is unaffected in length by the input data
DataChecker       | isValid(Review review)                                                             | O(1)           | Performs an operation that is unaffected in length by the input data
HaversineDC       | inKilometres(<br>&emsp; float lat1, float lon1, <br>&emsp; float lat2, float lon2) | O(1)           | Performs an operation that is unaffected in length by the input data
HaversineDC       | inMiles(<br>&emsp; float lat1, float lon1, <br>&emsp; float lat2, float lon2)      | O(1)           | Performs an operation that is unaffected in length by the input data
KeywordChecker    | isAKeyword(String s)                                                               | O(a/b)           | Accesses a value in a hash map, where `a` is the size of the array added to the hashmap and `b` is the capacticty of the hashmap
StringFormatter   | convertAccentsFaster(String s)                                                     | O(a/b)           | Accesses a value in a hash map, where `a` is the size of the array added to the hashmap and `b` is the capacticty of the hashmap
