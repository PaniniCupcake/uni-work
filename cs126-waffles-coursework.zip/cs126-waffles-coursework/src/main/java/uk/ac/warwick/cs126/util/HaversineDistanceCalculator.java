package uk.ac.warwick.cs126.util;
import java.lang.Math;
public class HaversineDistanceCalculator {


    public static float inKilometres(float lat1, float lon1, float lat2, float lon2) {
        lat1 = (float) Math.toRadians(lat1);
        lat2 = (float) Math.toRadians(lat2);
        lon1 = (float) Math.toRadians(lon1);
        lon2 = (float) Math.toRadians(lon2);
        double distance = Math.pow(Math.sin((lat2 - lat1)/2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin((lon2 - lon1)/2), 2);
        distance = 2 * (Math.asin(Math.sqrt(distance)));
        distance = 6372.8f * distance;
        distance -= distance % 0.1f;
        return (float) distance;
    }

    public static float inMiles(float lat1, float lon1, float lat2, float lon2) {
        lat1 = (float) Math.toRadians(lat1);
        lat2 = (float) Math.toRadians(lat2);
        lon1 = (float) Math.toRadians(lon1);
        lon2 = (float) Math.toRadians(lon2);
        double  distance = Math.pow(Math.sin((lat2 - lat1)/2),2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin((lon2 - lon1)/2),2);
        distance = 2 * ( Math.asin(Math.sqrt(distance)));
        distance = 6372.8f * distance / 1.609344f;
        distance -= distance % 0.1f;
        return (float) distance;
    }

}
