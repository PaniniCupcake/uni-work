package uk.ac.warwick.cs126.stores;

import uk.ac.warwick.cs126.interfaces.IReviewStore;
import uk.ac.warwick.cs126.models.Review;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.commons.io.IOUtils;

import uk.ac.warwick.cs126.structures.MyArrayList;
import uk.ac.warwick.cs126.structures.KVLTree;
import uk.ac.warwick.cs126.structures.KVPTree;
import uk.ac.warwick.cs126.structures.OrderedPair;
import uk.ac.warwick.cs126.structures.OrderedTrio;

import uk.ac.warwick.cs126.util.DataChecker;
import uk.ac.warwick.cs126.util.KeywordChecker;
import uk.ac.warwick.cs126.util.StringFormatter;

import java.util.Date;

public class ReviewStore implements IReviewStore {

  private KVLTree<Long, Review> reviewTree;
  private KVLTree<Long, KVLTree<Date,Review>> customerIdTree;
  private KVLTree<Long, KVLTree<Date,Review>> restaurantIdTree;
  private DataChecker dataChecker;
  private KVLTree<Long,Integer> blacklist;
  private KVLTree<OrderedPair<Long,Long>,KVLTree<Date,Review>> outdated;
  private KVLTree<Long,Review> outdatedIds;
  private KeywordChecker checker;
  private int insertions;
  private boolean existed;
    public ReviewStore() {
        // Initialise variables here
        reviewTree = new KVLTree<Long,Review>();//An arraylist is more appropriate as there are multiple ways the values can be referenced
        dataChecker = new DataChecker();
        blacklist = new KVLTree<Long,Integer>();
        customerIdTree = new KVLTree<Long, KVLTree<Date,Review>>();
        restaurantIdTree = new KVLTree<Long, KVLTree<Date,Review>>();
        outdated = new KVLTree<OrderedPair<Long,Long>,KVLTree<Date,Review>>();
        outdatedIds = new KVLTree<Long,Review>();
        checker = new KeywordChecker();
        insertions = 0;
        existed = false;
    }

    public Review[] loadReviewDataToArray(InputStream resource) {
        Review[] reviewArray = new Review[0];

        try {
            byte[] inputStreamBytes = IOUtils.toByteArray(resource);
            BufferedReader lineReader = new BufferedReader(new InputStreamReader(
                    new ByteArrayInputStream(inputStreamBytes), StandardCharsets.UTF_8));

            int lineCount = 0;
            String line;
            while ((line = lineReader.readLine()) != null) {
                if (!("".equals(line))) {
                    lineCount++;
                }
            }
            lineReader.close();

            Review[] loadedReviews = new Review[lineCount - 1];

            BufferedReader tsvReader = new BufferedReader(new InputStreamReader(
                    new ByteArrayInputStream(inputStreamBytes), StandardCharsets.UTF_8));

            int reviewCount = 0;
            String row;
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

            tsvReader.readLine();
            while ((row = tsvReader.readLine()) != null) {
                if (!("".equals(row))) {
                    String[] data = row.split("\t");
                    Review review = new Review(
                            Long.parseLong(data[0]),
                            Long.parseLong(data[1]),
                            Long.parseLong(data[2]),
                            formatter.parse(data[3]),
                            data[4],
                            Integer.parseInt(data[5]));
                    loadedReviews[reviewCount++] = review;
                }
            }
            tsvReader.close();

            reviewArray = loadedReviews;

        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

        return reviewArray;
    }

    public boolean addReview(Review review) {//Same as favouriteStore
      if(dataChecker.isValid(review) && allowAdd(review))
      {
        insertions ++;
        reviewTree.add(review.getID(),review);
        KVLTree<Date,Review> customerTemp = customerIdTree.get(review.getCustomerID());
        KVLTree<Date,Review> restaurantTemp = restaurantIdTree.get(review.getRestaurantID());
        if(customerTemp != null)
        {
            customerIdTree.get(review.getCustomerID()).add(review.getDateReviewed(),review);
        }
        else
        {

            customerTemp = new KVLTree<Date,Review>(-1);
            customerTemp.add(review.getDateReviewed(),review);
            customerIdTree.add(review.getCustomerID(),customerTemp);
        }
        if(restaurantTemp != null)
        {
            restaurantIdTree.get(review.getRestaurantID()).add(review.getDateReviewed(),review);
        }
        else
        {
            restaurantTemp = new KVLTree<Date,Review>(-1);
            restaurantTemp.add(review.getDateReviewed(),review);
            restaurantIdTree.add(review.getRestaurantID(),restaurantTemp);
        }
        return true;
      }
      return false;
    }

      private boolean allowAdd(Review review)//Checks if an object is inputted more than once or is on the blacklist
      {
        OrderedPair<Long,Long> temp = new OrderedPair<Long,Long>(review.getCustomerID(),review.getRestaurantID());
        if(getReview(review.getID()) != null)
        {

            blacklist.add(review.getID(),0);
            customerIdTree.get(reviewTree.get(review.getID()).getCustomerID()).remove(review.getDateReviewed());
            restaurantIdTree.get(reviewTree.get(review.getID()).getRestaurantID()).remove(review.getDateReviewed());
            reviewTree.remove(review.getID());
            if(outdated.get(temp) != null)
            {
                addReview(outdated.get(temp).getLowest());
            }
            return false;
        }
        else if(outdatedIds.get(review.getID()) != null)//Blacklists data permenantly if it was only outdated
        {

            blacklist.add(review.getID(),0);
            outdated.get(temp).remove(outdatedIds.get(review.getID()).getDateReviewed());
            outdatedIds.remove(review.getID());
            if(outdated.get(temp) != null)
            {
                addReview(outdated.get(temp).getLowest());
            }
            return false;
        }

        if(blacklist.get(review.getID()) != null)
        {
            return false;
        }
        if(customerIdTree.get(review.getCustomerID()) != null)
        {
            MyArrayList<Review> customerReviews = customerIdTree.get(review.getCustomerID()).getList();
            for(int i = 0; i < customerReviews.size();i++)
            {
                Review oldReview = customerReviews.get(i);
                if(oldReview.getRestaurantID() == review.getRestaurantID())
                {
                    if(oldReview.getDateReviewed().after(review.getDateReviewed()))
                    {
                        outdatedIds.add(oldReview.getID(),review);
                        reviewTree.remove(oldReview.getID());
                        KVLTree<Date,Review> temp2 = outdated.get(temp);
                        if(temp2 != null)
                        {
                            temp2.add(oldReview.getDateReviewed(),oldReview);
                            outdated.add(temp,temp2);
                        }
                        else
                        {
                            temp2 = new KVLTree<Date,Review>();
                            temp2.add(oldReview.getDateReviewed(),oldReview);
                            outdated.add(temp,temp2);
                        }
                        return true;
                    }
                    else
                    {
                        outdatedIds.add(review.getID(),review);
                        KVLTree<Date,Review> temp2 = outdated.get(temp);
                        if(temp2 != null)
                        {
                            temp2.add(review.getDateReviewed(),review);
                            outdated.add(temp,temp2);
                        }
                        else
                        {
                            temp2 = new KVLTree<Date,Review>();
                            temp2.add(review.getDateReviewed(),review);
                            outdated.add(temp,temp2);
                        }
                        return false;
                    }
                }
            }
        }
        return true;
      }

      public boolean addReview(Review[] reviews) {
      int i = 0;//Adds each element in the customers array to customerArray, and returns false if any of the additions return false
      boolean success = true;
      for(i = 0; i < reviews.length; i++)
      {
          if(!addReview(reviews[i]))
          {
             success = false;
          }
      }
      return success;
    }

    public Review getReview(Long id) {
      if(dataChecker.isValid(id))
      {
        return reviewTree.get(id);
      }
      return null;
    }

    public Review[] getReviews() {
        return getListArray(reviewTree.getList());
    }

    public Review[] getReviewsByDate() {
        int i = 0;
        KVPTree<Date,Review> tree = new KVPTree<Date,Review>(-1);
        MyArrayList<Review> arr = reviewTree.getList();
        for(i = 0;i < arr.size();i++) //Makes sure each customer is valid and in the map
        {
            tree.add(arr.get(i).getDateReviewed(),arr.get(i));
        }
        return (getListArray(tree.getList()));
    }

    public Review[] getReviewsByRating() {
        int i = 0;
        KVPTree<OrderedPair<Integer,Date>,Review> tree = new KVPTree<OrderedPair<Integer,Date>,Review>(-1);
        MyArrayList<Review> arr = reviewTree.getList();
        for(i = 0;i < arr.size();i++) //Makes sure each customer is valid and in the map
        {
            tree.add(new OrderedPair<Integer,Date>(arr.get(i).getRating(),arr.get(i).getDateReviewed()),arr.get(i));
        }
        return (getListArray(tree.getList()));
    }

    public Review[] getReviewsByCustomerID(Long id) {//Gets reviews and sorts them
      if(dataChecker.isValid(id) && customerIdTree.get(id) != null)
      {
          int i = 0;
          KVPTree<OrderedPair<Date,Long>,Review> tree = new KVPTree<OrderedPair<Date,Long>,Review>(-1);
          MyArrayList<Review> arr = customerIdTree.get(id).getList();
          for(i = 0;i < arr.size();i++) //Makes sure each customer is valid and in the map
          {
              tree.add(new OrderedPair<Date,Long>(arr.get(i).getDateReviewed(), - arr.get(i).getID()),arr.get(i));
          }
          return (getListArray(tree.getList()));
      }
      return new Review[0];
    }

    public Review[] getReviewsByRestaurantID(Long id) {//Gets reviews and sorts them
      if(dataChecker.isValid(id) && restaurantIdTree.get(id) != null)
      {
          int i = 0;
          KVPTree<OrderedPair<Date,Long>,Review> tree = new KVPTree<OrderedPair<Date,Long>,Review>(-1);
          MyArrayList<Review> arr = restaurantIdTree.get(id).getList();
          for(i = 0;i < arr.size();i++) //Makes sure each customer is valid and in the map
          {
              tree.add(new OrderedPair<Date,Long>(arr.get(i).getDateReviewed(), - arr.get(i).getID()),arr.get(i));
          }
          return (getListArray(tree.getList()));
      }
      return new Review[0];
    }

    public float getAverageCustomerReviewRating(Long id) {//Averages the reviews within the subtree
        if(customerIdTree.get(id) != null)
        {
              float totalRating = 0;
              MyArrayList<Review> arr = customerIdTree.get(id).getList();
              for(int i = 0; i < arr.size();i++)
              {
                  totalRating += arr.get(i).getRating();
              }
              if(arr.size() != 0)
              {
                  return totalRating / arr.size() - (float) ((totalRating / arr.size()) % 0.1);
              }
        }
        return 0.0f;
    }

    public float getAverageRestaurantReviewRating(Long id) {//Averages the reviews within the subtree
      if(restaurantIdTree.get(id) != null)
      {
            float totalRating = 0;
            MyArrayList<Review> arr = restaurantIdTree.get(id).getList();
            for(int i = 0; i < arr.size();i++)
            {
                totalRating += arr.get(i).getRating();
            }
            if(arr.size() != 0)
            {
                return(totalRating / arr.size()) - (float) ((totalRating / arr.size()) % 0.1);
            }
      }
      return 0.0f;
    }

    public int[] getCustomerReviewHistogramCount(Long id) {//Tallies up the number of ratings for each customer
        if(customerIdTree.get(id) != null)
        {
              int[] ratings = {0,0,0,0,0};
              MyArrayList<Review> arr = customerIdTree.get(id).getList();
              for(int i = 0; i < arr.size();i++)
              {
                  ratings[arr.get(i).getRating() - 1] ++;
              }
              return ratings;
        }
        return new int[5];
    }

    public int[] getRestaurantReviewHistogramCount(Long id) {//Tallies up the number of ratings for each restaurant
        if(restaurantIdTree.get(id) != null)
        {
              int[] ratings = {0,0,0,0,0};
              MyArrayList<Review> arr = restaurantIdTree.get(id).getList();
              for(int i = 0; i < arr.size();i++)
              {
                  ratings[arr.get(i).getRating() - 1] ++;
              }
              return ratings;
        }
        return new int[5];
    }

    public Long[] getTopCustomersByReviewCount() {//Finds the size of the subtrees for each customer, and sorts them
      MyArrayList<KVLTree<Date,Review>> li1 = customerIdTree.getList();
      if(li1 != null)
      {
          KVPTree<OrderedTrio<Integer,Date,Long>, Long> tree = new KVPTree<OrderedTrio<Integer,Date,Long>, Long>(-1);
          for(int i = 0; i < li1.size(); i++)
          {//Sorts them in order of size
            Review temp = li1.get(i).getRoot().getValue().getValue();
            tree.add(new OrderedTrio<Integer,Date,Long>(li1.get(i).size(),temp.getDateReviewed(), - temp.getID()),temp.getCustomerID());
          }
          MyArrayList<Long> li2 = tree.getList();
          Long[] arr = new Long[20];
          for(int i=0;i<20 && i < li2.size();i++)
          {
              arr[i] = li2.get(i);
          }
          return arr;
        }
        return new Long[20];
    }

    public Long[] getTopRestaurantsByReviewCount() {//Finds the size of the subtrees for each restaurant, and sorts them
      MyArrayList<KVLTree<Date,Review>> li1 = restaurantIdTree.getList();
      if(li1 != null)
      {
          KVPTree<OrderedTrio<Integer,Date,Long>, Long> tree = new KVPTree<OrderedTrio<Integer,Date,Long>, Long>(-1);
          for(int i = 0; i < li1.size(); i++)
          {
              Review temp = li1.get(i).getRoot().getValue().getValue();
              tree.add(new OrderedTrio<Integer,Date,Long>(li1.get(i).size(),temp.getDateReviewed(), - temp.getID()),temp.getRestaurantID());
          }
          MyArrayList<Long> li2 = tree.getList();
          Long[] arr = new Long[20];
          for(int i=0;i<20 && i < li2.size();i++)
          {
              arr[i] = li2.get(i);
          }
          return arr;
      }
      return new Long[20];
    }

    public Long[] getTopRatedRestaurants() {
      MyArrayList<KVLTree<Date,Review>> li1 = restaurantIdTree.getList();
      if(li1 != null)
      {
          KVPTree<OrderedTrio<Float,Date,Long>, Long> tree = new KVPTree<OrderedTrio<Float,Date,Long>, Long>();
          for(int i = 0; i < li1.size(); i++)
          {//Adds the average rating to a list for sorting
              Review temp = li1.get(i).getRoot().getValue().getValue();
              tree.add(new OrderedTrio<Float,Date,Long>(-getAverageRestaurantReviewRating(temp.getRestaurantID()),temp.getDateReviewed(), - temp.getID()),temp.getRestaurantID());
          }
          MyArrayList<Long> li2 = tree.getList();
          Long[] arr = new Long[20];
          for(int i=0;i<20 && i < li2.size();i++)
          {
              arr[i] = li2.get(i);
          }
          return arr;
      }
      return new Long[20];
    }

    public String[] getTopKeywordsForRestaurant(Long id) {
        MyArrayList<Review> li1 = restaurantIdTree.get(id).getList();
        if(li1 != null)
        {
            KVLTree<String,OrderedPair<Integer,String>> tree = new KVLTree<String,OrderedPair<Integer,String>>();
            for(int i = 0; i < li1.size(); i++)
            {
                String word = "";
                String review = li1.get(i).getReview();
                for(int j=0; j < review.length();j++)
                {
                    if(review.charAt(j) == ' ')
                    {
                        if(checker.isAKeyword(word))
                        {
                            if(tree.get(word) != null)//Adds to the counter of a word if it is there, otherwise starts a new counter
                            {
                                tree.add(word,new OrderedPair<Integer,String>(tree.get(word).getVal1() + 1,word));
                            }
                            else
                            {
                                tree.add(word,new OrderedPair<Integer,String>(1,word));
                            }
                        }
                        word = "";
                    }
                    else
                    {
                        word += review.charAt(j);
                    }
                }
            }
            MyArrayList<OrderedPair<Integer,String>> li2 = tree.getList();
            KVPTree<OrderedPair<Integer,String>,String> tree2 = new KVPTree<OrderedPair<Integer,String>,String>();
            for(int i=0;i < li2.size();i++)//Tree sorts with their counter values
            {
                tree2.add(new OrderedPair<Integer,String>(li2.get(i).getVal1(),li2.get(i).getVal2()),li2.get(i).getVal2());
            }
            MyArrayList<String> li3 = tree2.getList();
            String[] arr = new String[5];
            for(int i=0;i<5 && i < li3.size();i++)
            {
                arr[i] = li3.get(i);
            }
        }
        return new String[5];
    }

    public Review[] getReviewsContaining(String searchTerm) {
        searchTerm = StringFormatter.convertAccentsFaster(searchTerm).toLowerCase();
        MyArrayList<Review> list = reviewTree.getList();
        KVPTree<OrderedPair<Date,Long>, Review> tree = new KVPTree<OrderedPair<Date,Long>,Review>(-1);
        for(int i = 0; i < list.size(); i++)
        {
            Review item = list.get(i);
            if(StringFormatter.convertAccentsFaster(item.getReview()).contains(searchTerm))
            {
                tree.add(new OrderedPair<Date,Long>(item.getDateReviewed(),-item.getID()),item);
            }
        }
		    return getListArray(tree.getList());
    }

    private Review[] getListArray(MyArrayList<Review> revList){//Converts the arraylist to an array by checking through its linked list array
        Review[] arr = new Review[revList.size()];
        int i = 0;
        for(i = 0;i < arr.length;i++)
        {
            arr[i] = revList.get(i);
        }
        return arr;
    }
}
