package uk.ac.warwick.cs126.stores;

import uk.ac.warwick.cs126.interfaces.IRestaurantStore;
import uk.ac.warwick.cs126.models.Cuisine;
import uk.ac.warwick.cs126.models.EstablishmentType;
import uk.ac.warwick.cs126.models.Place;
import uk.ac.warwick.cs126.models.PriceRange;
import uk.ac.warwick.cs126.models.Restaurant;
import uk.ac.warwick.cs126.models.RestaurantDistance;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.commons.io.IOUtils;

import uk.ac.warwick.cs126.structures.KVLTree;
import uk.ac.warwick.cs126.structures.KVPTree;
import uk.ac.warwick.cs126.structures.MyArrayList;
import uk.ac.warwick.cs126.structures.OrderedPair;
import uk.ac.warwick.cs126.structures.OrderedTrio;

import uk.ac.warwick.cs126.util.ConvertToPlace;
import uk.ac.warwick.cs126.util.HaversineDistanceCalculator;
import uk.ac.warwick.cs126.util.DataChecker;
import uk.ac.warwick.cs126.util.StringFormatter;

import java.util.Date;
public class RestaurantStore implements IRestaurantStore {

    private KVLTree<Long,Restaurant> restaurantTree;
    private KVLTree<String,Restaurant> alphabeticalRestaurantTree;
    private DataChecker dataChecker;
    private KVLTree<Long,Integer> blacklist;
    private ConvertToPlace converter;


    public RestaurantStore() {
        // Initialise variables here
        restaurantTree = new KVLTree<Long,Restaurant>();
        alphabeticalRestaurantTree = new KVLTree<String,Restaurant>();
        dataChecker = new DataChecker();
        blacklist = new KVLTree<Long,Integer>();
        converter = new ConvertToPlace();
    }

    public Restaurant[] loadRestaurantDataToArray(InputStream resource) {
        Restaurant[] restaurantArray = new Restaurant[0];

        try {
            byte[] inputStreamBytes = IOUtils.toByteArray(resource);
            BufferedReader lineReader = new BufferedReader(new InputStreamReader(
                    new ByteArrayInputStream(inputStreamBytes), StandardCharsets.UTF_8));

            int lineCount = 0;
            String line;
            while ((line = lineReader.readLine()) != null) {
                if (!("".equals(line))) {
                    lineCount++;
                }
            }
            lineReader.close();

            Restaurant[] loadedRestaurants = new Restaurant[lineCount - 1];

            BufferedReader csvReader = new BufferedReader(new InputStreamReader(
                    new ByteArrayInputStream(inputStreamBytes), StandardCharsets.UTF_8));

            String row;
            int restaurantCount = 0;
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

            csvReader.readLine();
            while ((row = csvReader.readLine()) != null) {
                if (!("".equals(row))) {
                    String[] data = row.split(",");

                    Restaurant restaurant = new Restaurant(
                            data[0],
                            data[1],
                            data[2],
                            data[3],
                            Cuisine.valueOf(data[4]),
                            EstablishmentType.valueOf(data[5]),
                            PriceRange.valueOf(data[6]),
                            formatter.parse(data[7]),
                            Float.parseFloat(data[8]),
                            Float.parseFloat(data[9]),
                            Boolean.parseBoolean(data[10]),
                            Boolean.parseBoolean(data[11]),
                            Boolean.parseBoolean(data[12]),
                            Boolean.parseBoolean(data[13]),
                            Boolean.parseBoolean(data[14]),
                            Boolean.parseBoolean(data[15]),
                            formatter.parse(data[16]),
                            Integer.parseInt(data[17]),
                            Integer.parseInt(data[18]));

                    loadedRestaurants[restaurantCount++] = restaurant;
                }
            }
            csvReader.close();

            restaurantArray = loadedRestaurants;

        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

        return restaurantArray;
    }

    public boolean addRestaurant(Restaurant restaurant) {
      restaurant.setID(dataChecker.extractTrueID(restaurant.getRepeatedID()));
      if(dataChecker.isValid(restaurant) && allowAdd(restaurant))
      {
          restaurantTree.add(restaurant.getID(),restaurant);//Adds the customer input to the customers array
          alphabeticalRestaurantTree.add(restaurant.getName(),restaurant);
          return true;
      }
      return false;
  }

  private boolean allowAdd(Restaurant restaurant)//Checks if an object is inputted more than once or is on the blacklist
  {
      Long id = restaurant.getID();
      if(getRestaurant(id) != null)
      {
          blacklist.add(id,0);
          alphabeticalRestaurantTree.remove(restaurantTree.get(id).getName());
          restaurantTree.remove(id);
          return false;
      }
      return blacklist.get(id) == null;
    }

    public boolean addRestaurant(Restaurant[] restaurants) {
        int i = 0;//same as in customerStore
        boolean success = true;
        for(i = 0; i < restaurants.length; i++)
        {
            if(!addRestaurant(restaurants[i]))
            {
               success = false;
            }
        }
        return success;
    }

    public Restaurant getRestaurant(Long id) {
      if(dataChecker.isValid(id))
      {
          return restaurantTree.get(id);
      }
      return null;
    }

    public Restaurant[] getRestaurants() {
        return (getListArray(restaurantTree.getList()));
    }

    public Restaurant[] getRestaurants(Restaurant[] restaurants) {
        int i = 0;
        restaurants = getRestaurantIDs(restaurants);
        KVPTree<Long,Restaurant> tree = new KVPTree<Long,Restaurant>();
        for(i = 0;i < restaurants.length;i++) //Makes sure each customer is valid and in the map
        {
            restaurants[i].setID(dataChecker.extractTrueID(restaurants[i].getRepeatedID()));
            if(!dataChecker.isValid(restaurants[i]))
            {
                return new Restaurant[0];
            }
            else
            {
                tree.add(restaurants[i].getID(),restaurants[i]);
            }
        }
        return (getListArray(tree.getList()));
    }

    public Restaurant[] getRestaurantsByName() {
        return (getListArray(alphabeticalRestaurantTree.getList()));
    }

    public Restaurant[] getRestaurantsByDateEstablished() {//Sorts appropriately
        int i = 0;
        KVPTree<OrderedTrio<Date,String,Long>,Restaurant> tree = new KVPTree<OrderedTrio<Date,String,Long>,Restaurant>();
        MyArrayList<Restaurant> arr = restaurantTree.getList();
        for(i = 0;i < arr.size();i++) //Makes sure each customer is valid and in the map
        {
            tree.add(new OrderedTrio<Date,String,Long>(arr.get(i).getDateEstablished(),arr.get(i).getName(),arr.get(i).getID()),arr.get(i));
        }
        return (getListArray(tree.getList()));
    }

    public Restaurant[] getRestaurantsByDateEstablished(Restaurant[] restaurants) {
        int i = 0;
        restaurants = getRestaurantIDs(restaurants);
        KVPTree<OrderedTrio<Date,String,Long>,Restaurant> tree = new KVPTree<OrderedTrio<Date,String,Long>,Restaurant>();
        for(i = 0;i < restaurants.length;i++) //Makes sure each customer is valid and in the map
        {
            restaurants[i].setID(dataChecker.extractTrueID(restaurants[i].getRepeatedID()));
            if(!dataChecker.isValid(restaurants[i]))
            {
                return new Restaurant[0];
            }
            else
            {
                tree.add(new OrderedTrio<Date,String,Long>(restaurants[i].getDateEstablished(),restaurants[i].getName(),restaurants[i].getID()),restaurants[i]);
            }
        }
        return (getListArray(tree.getList()));
    }

    public Restaurant[] getRestaurantsByWarwickStars() {
        int i = 0;
        KVPTree<OrderedTrio<Integer,String,Long>,Restaurant> tree = new KVPTree<OrderedTrio<Integer,String,Long>,Restaurant>();
        MyArrayList<Restaurant> arr = restaurantTree.getList();
        for(i = 0;i < arr.size();i++) //Makes sure each customer is valid and in the map
        {
            tree.add(new OrderedTrio<Integer,String,Long>(arr.get(i).getWarwickStars(),arr.get(i).getName(),arr.get(i).getID()),arr.get(i));
        }
        return (getListArray(tree.getList()));
    }

    public Restaurant[] getRestaurantsByRating(Restaurant[] restaurants) {//Sorts appropriately
        int i = 0;
        restaurants = getRestaurantIDs(restaurants);
        KVPTree<OrderedTrio<Float,String,Long>,Restaurant> tree = new KVPTree<OrderedTrio<Float,String,Long>,Restaurant>();
        for(i = 0;i < restaurants.length;i++) //Makes sure each customer is valid and in the map
        {
            restaurants[i].setID(dataChecker.extractTrueID(restaurants[i].getRepeatedID()));
            if(!dataChecker.isValid(restaurants[i]))
            {
                return new Restaurant[0];
            }
            else
            {
                tree.add(new OrderedTrio<Float,String,Long>(restaurants[i].getCustomerRating(),restaurants[i].getName(),restaurants[i].getID()),restaurants[i]);
            }
        }
        return (getListArray(tree.getList()));
    }

    public RestaurantDistance[] getRestaurantsByDistanceFrom(float latitude, float longitude) {//Sorts appropriately
        int i = 0;
        KVPTree<OrderedPair<Float,Long>,RestaurantDistance> tree = new KVPTree<OrderedPair<Float,Long>,RestaurantDistance>();
        MyArrayList<Restaurant> arr = restaurantTree.getList();
        for(i = 0;i < arr.size();i++) //Makes sure each customer is valid and in the map
        {
            float dist = HaversineDistanceCalculator.inKilometres(latitude,longitude,arr.get(i).getLatitude(),arr.get(i).getLatitude());
            tree.add(new OrderedPair<Float,Long>(dist, arr.get(i).getID()),new RestaurantDistance(arr.get(i),dist));
        }
        return (getDistanceListArray(tree.getList()));
    }

    public RestaurantDistance[] getRestaurantsByDistanceFrom(Restaurant[] restaurants, float latitude, float longitude) {//Sorts appropriately
        int i = 0;
        restaurants = getRestaurantIDs(restaurants);
        KVPTree<OrderedPair<Float,Long>,RestaurantDistance> tree = new KVPTree<OrderedPair<Float,Long>,RestaurantDistance>();
        for(i = 0;i < restaurants.length;i++) //Makes sure each customer is valid and in the map
        {
            restaurants[i].setID(dataChecker.extractTrueID(restaurants[i].getRepeatedID()));
            if(!dataChecker.isValid(restaurants[i]))
            {
                return new RestaurantDistance[0];
            }
            else
            {
              float dist = HaversineDistanceCalculator.inKilometres(latitude,longitude,restaurants[i].getLatitude(),restaurants[i].getLatitude());
              tree.add(new OrderedPair<Float,Long>(dist, restaurants[i].getID()),new RestaurantDistance(restaurants[i],dist));
            }
        }
        return (getDistanceListArray(tree.getList()));
    }

    public Restaurant[] getRestaurantsContaining(String searchTerm) {//checks whether any of the relevant Restaurant values contain the desired string
        MyArrayList<Restaurant> list = alphabeticalRestaurantTree.getList();
        searchTerm = StringFormatter.convertAccentsFaster(searchTerm).toLowerCase();
        MyArrayList<Restaurant> list2 = new MyArrayList<Restaurant>();
        for(int i = 0; i < list.size(); i++)
        {
            if(StringFormatter.convertAccentsFaster(list.get(i).getName()).toLowerCase().contains(searchTerm) || list.get(i).getCuisine().toString().toLowerCase().contains(searchTerm) || converter.convert(list.get(i).getLatitude(),list.get(i).getLongitude()).getName().toLowerCase().contains(searchTerm))
            {
                list2.add(list.get(i));
            }
        }

        return getListArray(list2);
    }

    private Restaurant[] getRestaurantIDs(Restaurant[] list)
    {
        for(int i = 0; i < list.length;i++)
        {
            list[i].setID(dataChecker.extractTrueID(list[i].getRepeatedID()));
        }
        return list;
    }

    private Restaurant[] getListArray(MyArrayList<Restaurant> list){//Converts the arraylist to an array by checking through its linked list array
        Restaurant[] arr = new Restaurant[list.size()];
        int i = 0;
        for(i = 0;i < arr.length;i++)
        {
            arr[i] = list.get(i);
        }
        return arr;
    }
    private RestaurantDistance[] getDistanceListArray(MyArrayList<RestaurantDistance> list){//Converts the arraylist to an array by checking through its linked list array
        RestaurantDistance[] arr = new RestaurantDistance[list.size()];
        int i = 0;
        for(i = 0;i < arr.length;i++)
        {
            arr[i] = list.get(i);
        }
        return arr;
    }
}
