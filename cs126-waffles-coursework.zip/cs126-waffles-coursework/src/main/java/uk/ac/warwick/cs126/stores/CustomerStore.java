package uk.ac.warwick.cs126.stores;

import uk.ac.warwick.cs126.interfaces.ICustomerStore;
import uk.ac.warwick.cs126.models.Customer;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.commons.io.IOUtils;

import uk.ac.warwick.cs126.structures.KVLTree;
import uk.ac.warwick.cs126.structures.KVPTree;
import uk.ac.warwick.cs126.structures.MyArrayList;
import uk.ac.warwick.cs126.structures.OrderedTrio;

import uk.ac.warwick.cs126.util.DataChecker;
import uk.ac.warwick.cs126.util.StringFormatter;


public class CustomerStore implements ICustomerStore {

    private KVLTree<Long,Customer> customerTree;
    private KVLTree<OrderedTrio<String,String,Long>,Customer> alphabeticalCustomerTree;
    private DataChecker dataChecker;
    private KVLTree<Long,Integer> blacklist;
    public CustomerStore() {
        // Initialise variables here
        customerTree= new KVLTree<Long,Customer>();
        alphabeticalCustomerTree= new KVLTree<OrderedTrio<String,String,Long>,Customer>();
        dataChecker = new DataChecker();
        blacklist = new KVLTree<Long,Integer>();
    }

    public Customer[] loadCustomerDataToArray(InputStream resource) {
        Customer[] customerArray = new Customer[0];

        try {
            byte[] inputStreamBytes = IOUtils.toByteArray(resource);
            BufferedReader lineReader = new BufferedReader(new InputStreamReader(
                    new ByteArrayInputStream(inputStreamBytes), StandardCharsets.UTF_8));

            int lineCount = 0;
            String line;
            while ((line=lineReader.readLine()) != null) {//Reads all the lines, and increments the line count if they aren't empty
                if (!("".equals(line))) {
                    lineCount++;
                }
            }
            lineReader.close();

            Customer[] loadedCustomers = new Customer[lineCount - 1];

            BufferedReader csvReader = new BufferedReader(new InputStreamReader(
                    new ByteArrayInputStream(inputStreamBytes), StandardCharsets.UTF_8));

            int customerCount = 0;
            String row;
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

            csvReader.readLine();
            while ((row = csvReader.readLine()) != null) {
                if (!("".equals(row))) {
                    String[] data = row.split(",");

                    Customer customer = (new Customer(
                            Long.parseLong(data[0]),
                            data[1],
                            data[2],
                            formatter.parse(data[3]),
                            Float.parseFloat(data[4]),
                            Float.parseFloat(data[5])));

                    loadedCustomers[customerCount++] = customer;
                }
            }
            csvReader.close();

            customerArray = loadedCustomers;

        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

        return customerArray;
    }

    public boolean addCustomer(Customer customer) {
    		if(dataChecker.isValid(customer) && allowAdd(customer))
    		{
      			customerTree.add(customer.getID(),customer);
            alphabeticalCustomerTree.add(new OrderedTrio<String,String,Long>(customer.getLastName(),customer.getFirstName(),customer.getID()),customer);
            return true;
    		}
        return false;
	  }

    private boolean allowAdd(Customer customer)//Checks if an object is inputted more than once or is on the blacklist
    {
        Long id = customer.getID();
      	if(getCustomer(id) != null)
      	{
          	blacklist.add(id,0);
            Customer temp = customerTree.get(id);
            alphabeticalCustomerTree.remove(new OrderedTrio<String,String,Long>(temp.getLastName(),temp.getFirstName(),temp.getID()));
          	customerTree.remove(id);
          	return false;
      	}
      	return blacklist.get(id) == null;
    }

    public boolean addCustomer(Customer[] customers) {
        int i = 0;//Adds each element in the customers array to customerArray, and returns false if any of the additions return false
        boolean success = true;
        for(i = 0; i < customers.length; i++)
        {
	          if(!addCustomer(customers[i]))
      	    {
	             success = false;
	          }
        }
        return success;
    }

    public Customer getCustomer(Long id) {
        if(dataChecker.isValid(id))
        {
          return customerTree.get(id);
        }
        return null;
    }

    public Customer[] getCustomers() {
        return (getListArray(customerTree.getList()));
    }


    public Customer[] getCustomers(Customer[] customers) {
        int i = 0;
        KVPTree<Long,Customer> tree = new KVPTree<Long,Customer>();
        for(i = 0;i < customers.length;i++) //Makes sure each customer is valid and in the map
        {
            if(!dataChecker.isValid(customers[i]))
            {
                return new Customer[0];
            }
            else
            {
                tree.add(customers[i].getID(),customers[i]);
            }
        }
        return (getListArray(tree.getList()));
    }

    public Customer[] getCustomersByName() {
        return (getListArray(alphabeticalCustomerTree.getList()));
    }

    public Customer[] getCustomersByName(Customer[] customers) {
        int i = 0;
        KVPTree<OrderedTrio<String,String,Long>,Customer> tree = new KVPTree<OrderedTrio<String,String,Long>,Customer>();
        for(i = 0;i < customers.length;i++)
        {
            if(!dataChecker.isValid(customers[i]))
            {
                return new Customer[0];
            }
            else
            {//The ordered pair tree makes sure the data is ordered in the correct manner
                tree.add(new OrderedTrio<String,String,Long>(customers[i].getLastName(),customers[i].getFirstName(),customers[i].getID()),customers[i]);

            }
        }
        return (getListArray(tree.getList()));
    }


    public Customer[] getCustomersContaining(String searchTerm) {
        MyArrayList<Customer> list = alphabeticalCustomerTree.getList();
        searchTerm = StringFormatter.convertAccentsFaster(searchTerm);
        MyArrayList<Customer> list2 = new MyArrayList<Customer>();
        String str1 = "";
        String str2 = "";
        int i = 0;
        for(i = 0; i < searchTerm.length(); i++) //Seperates the two parts of the searchTerm
        {
    			if(searchTerm.charAt(i) == ' ')
    			{
    				for(i=i+1; i< searchTerm.length(); i++)
    				{
    					str2 += searchTerm.charAt(i);
    				}
    				break;
    			}
    			str1 += searchTerm.charAt(i);
        }
        str1 = str1.toLowerCase();
        str2 = str2.toLowerCase();
        for(i = 0; i < list.size(); i++)
        {//Checks if the first name contains str1 and the last str2, or if there is only str1 and either name contains it
            if((StringFormatter.convertAccentsFaster(list.get(i).getFirstName()).toLowerCase().contains(str1) && StringFormatter.convertAccentsFaster(list.get(i).getLastName()).toLowerCase().contains(str2))
            || (str2.compareTo("") == 0 && (StringFormatter.convertAccentsFaster(list.get(i).getFirstName()).toLowerCase().contains(str1) || StringFormatter.convertAccentsFaster(list.get(i).getLastName()).toLowerCase().contains(str1))))
            {
                list2.add(list.get(i));
            }
        }

		    return getListArray(list2);
    }

    private Customer[] getListArray(MyArrayList<Customer> favList){//Converts the arraylist to an array by checking through its linked list array
        Customer[] arr = new Customer[favList.size()];
        int i = 0;
        for(i = 0;i < arr.length;i++)
        {
            arr[i] = favList.get(i);
        }
        return arr;
    }


}
