package uk.ac.warwick.cs126.stores;

import uk.ac.warwick.cs126.interfaces.IFavouriteStore;
import uk.ac.warwick.cs126.models.Favourite;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.commons.io.IOUtils;

import uk.ac.warwick.cs126.structures.MyArrayList;
import uk.ac.warwick.cs126.structures.KVLTree;
import uk.ac.warwick.cs126.structures.KVPTree;
import uk.ac.warwick.cs126.structures.OrderedPair;
import uk.ac.warwick.cs126.structures.OrderedTrio;

import uk.ac.warwick.cs126.util.DataChecker;
import java.util.Date;

public class FavouriteStore implements IFavouriteStore {

    private KVLTree<Long, Favourite> favouriteTree;
    private KVLTree<Long, KVLTree<Long,Favourite>> customerIdTree;
    private KVLTree<Long, KVLTree<Long,Favourite>> restaurantIdTree;
    private DataChecker dataChecker;
    private KVLTree<Long,Integer> blacklist;
    private KVLTree<OrderedPair<Long,Long>,KVLTree<Date,Favourite>> outdated;
    private KVLTree<Long,Favourite> outdatedIds;
    public FavouriteStore() {
        // Initialise variables here
        favouriteTree = new KVLTree<Long, Favourite>();//An arraylist is more appropriate as there are multiple ways the values can be referenced
        dataChecker = new DataChecker();
        blacklist = new KVLTree<Long,Integer>();
        customerIdTree = new KVLTree<Long, KVLTree<Long,Favourite>>();
        restaurantIdTree = new KVLTree<Long, KVLTree<Long,Favourite>>();
        outdated = new KVLTree<OrderedPair<Long,Long>,KVLTree<Date,Favourite>>();
        outdatedIds = new KVLTree<Long,Favourite>();
    }

    public Favourite[] loadFavouriteDataToArray(InputStream resource) {
        Favourite[] favouriteArray = new Favourite[0];

        try {
            byte[] inputStreamBytes = IOUtils.toByteArray(resource);
            BufferedReader lineReader = new BufferedReader(new InputStreamReader(
                    new ByteArrayInputStream(inputStreamBytes), StandardCharsets.UTF_8));

            int lineCount = 0;
            String line;
            while ((line = lineReader.readLine()) != null) {
                if (!("".equals(line))) {
                    lineCount++;
                }
            }
            lineReader.close();

            Favourite[] loadedFavourites = new Favourite[lineCount - 1];

            BufferedReader csvReader = new BufferedReader(new InputStreamReader(
                    new ByteArrayInputStream(inputStreamBytes), StandardCharsets.UTF_8));

            int favouriteCount = 0;
            String row;
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

            csvReader.readLine();
            while ((row = csvReader.readLine()) != null) {
                if (!("".equals(row))) {
                    String[] data = row.split(",");
                    Favourite favourite = new Favourite(
                            Long.parseLong(data[0]),
                            Long.parseLong(data[1]),
                            Long.parseLong(data[2]),
                            formatter.parse(data[3]));
                    loadedFavourites[favouriteCount++] = favourite;
                }
            }
            csvReader.close();

            favouriteArray = loadedFavourites;

        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

        return favouriteArray;
    }

    public boolean addFavourite(Favourite favourite) {
      if(dataChecker.isValid(favourite) && allowAdd(favourite))
      {
        favouriteTree.add(favourite.getID(),favourite);
        KVLTree<Long,Favourite> customerTemp = customerIdTree.get(favourite.getCustomerID());
        KVLTree<Long,Favourite> restaurantTemp = restaurantIdTree.get(favourite.getRestaurantID());
        if(customerTemp != null) //If the tree contains a tree with this customer ID already, adds to that subtree. Otherwise, adds a new subtree for that ID
        {
            customerIdTree.get(favourite.getCustomerID()).add(favourite.getRestaurantID(),favourite);
        }
        else
        {
            customerTemp = new KVLTree<Long,Favourite>();
            customerTemp.add(favourite.getRestaurantID(),favourite);
            customerIdTree.add(favourite.getCustomerID(),customerTemp);
        }
        if(restaurantTemp != null)
        {
            restaurantIdTree.get(favourite.getRestaurantID()).add(favourite.getCustomerID(),favourite);
        }
        else
        {
            restaurantTemp = new KVLTree<Long,Favourite>();
            restaurantTemp.add(favourite.getCustomerID(),favourite);
            restaurantIdTree.add(favourite.getRestaurantID(),restaurantTemp);
        }
        return true;
      }
      return false;
    }

      private boolean allowAdd(Favourite favourite)//Checks if an object is inputted more than once or is on the blacklist
      {
        OrderedPair<Long,Long> temp = new OrderedPair<Long,Long>(favourite.getCustomerID(),favourite.getRestaurantID());
        if(getFavourite(favourite.getID()) != null)
        {

            blacklist.add(favourite.getID(),0);//Removes from all 3 trees
            customerIdTree.get(favouriteTree.get(favourite.getID()).getCustomerID()).remove(favourite.getCustomerID());
            restaurantIdTree.get(favouriteTree.get(favourite.getID()).getRestaurantID()).remove(favourite.getRestaurantID());
            favouriteTree.remove(favourite.getID());
            if(outdated.get(temp) != null)
            {
                addFavourite(outdated.get(temp).getLowest());
            }
            return false;
        }
        else if(outdatedIds.get(favourite.getID()) != null)//Blacklists data permenantly if it was only outdated
        {
            blacklist.add(favourite.getID(),0);//Removes from outdated and outdatedIds
            outdated.get(temp).remove(outdatedIds.get(favourite.getID()).getDateFavourited());
            outdatedIds.remove(favourite.getID());
            if(outdated.get(temp) != null)
            {
                addFavourite(outdated.get(temp).getLowest());
            }
            return false;
        }

        if(blacklist.get(favourite.getID()) != null)
        {
            return false;
        }
        if(customerIdTree.get(favourite.getCustomerID()) != null)
        {
            MyArrayList<Favourite> customerFavourites = customerIdTree.get(favourite.getCustomerID()).getList();
            for(int i = 0; i < customerFavourites.size();i++)//Checks through the customers with the same Id and outdates what is appropriate
            {
                Favourite oldFavourite = customerFavourites.get(i);
                if(oldFavourite.getRestaurantID() == favourite.getRestaurantID())//If they have the same restaurant and customer id, then checks which Favourite came before
                {
                    if(oldFavourite.getDateFavourited().after(favourite.getDateFavourited()))
                    {
                        outdatedIds.add(oldFavourite.getID(),favourite);
                        favouriteTree.remove(oldFavourite.getID());
                        KVLTree<Date,Favourite> temp2 = outdated.get(temp);
                        if(temp2 != null)
                        {
                            temp2.add(oldFavourite.getDateFavourited(),oldFavourite);
                            outdated.add(temp,temp2);
                        }
                        else
                        {
                            temp2 = new KVLTree<Date,Favourite>();
                            temp2.add(oldFavourite.getDateFavourited(),oldFavourite);
                            outdated.add(temp,temp2);
                        }
                        return true;
                    }
                    else
                    {
                        outdatedIds.add(favourite.getID(),favourite);
                        KVLTree<Date,Favourite> temp2 = outdated.get(temp);
                        if(temp2 != null)
                        {
                            temp2.add(favourite.getDateFavourited(),favourite);
                            outdated.add(temp,temp2);
                        }
                        else
                        {
                            temp2 = new KVLTree<Date,Favourite>();
                            temp2.add(favourite.getDateFavourited(),favourite);
                            outdated.add(temp,temp2);
                        }
                        return false;
                    }
                }
            }
        }
        return true;
      }

    public boolean addFavourite(Favourite[] favourites) {
      int i = 0;//Adds each element in the customers array to customerArray, and returns false if any of the additions return false
      boolean success = true;
      for(i = 0; i < favourites.length; i++)
      {
          if(!addFavourite(favourites[i]))
          {
             success = false;
          }
      }
      return success;
    }

    public Favourite getFavourite(Long id) {
        if(dataChecker.isValid(id))
        {
          return favouriteTree.get(id);
        }
        return null;
    }

    public Favourite[] getFavourites() {
        return getListArray(favouriteTree.getList());
    }

    public Favourite[] getFavouritesByCustomerID(Long id) {
        if(dataChecker.isValid(id) && customerIdTree.get(id) != null)
        {
            int i = 0;
            KVPTree<OrderedPair<Date,Long>,Favourite> tree = new KVPTree<OrderedPair<Date,Long>,Favourite>(-1);
            MyArrayList<Favourite> arr = customerIdTree.get(id).getList();
            for(i = 0;i < arr.size();i++) //Makes sure each customer is valid and in the map
            {
                tree.add(new OrderedPair<Date,Long>(arr.get(i).getDateFavourited(), - arr.get(i).getID()),arr.get(i));
            }
            return (getListArray(tree.getList()));
        }
        return new Favourite[0];
    }

    public Favourite[] getFavouritesByRestaurantID(Long id) {
        if(dataChecker.isValid(id) && restaurantIdTree.get(id) != null)
        {
            int i = 0;
            KVPTree<OrderedPair<Date,Long>,Favourite> tree = new KVPTree<OrderedPair<Date,Long>,Favourite>(-1);
            MyArrayList<Favourite> arr = restaurantIdTree.get(id).getList();
            for(i = 0;i < arr.size();i++) //Makes sure each customer is valid and in the map
            {
                tree.add(new OrderedPair<Date,Long>(arr.get(i).getDateFavourited(), - arr.get(i).getID()),arr.get(i));
            }
            return (getListArray(tree.getList()));
        }
        return new Favourite[0];
    }

    public Long[] getCommonFavouriteRestaurants(Long customer1ID, Long customer2ID) {
        if(dataChecker.isValid(customer1ID) && dataChecker.isValid(customer2ID) && customerIdTree.get(customer1ID) != null && customerIdTree.get(customer2ID) != null)
        {
            MyArrayList<Favourite> customer1Favourites = customerIdTree.get(customer1ID).getList();
            MyArrayList<Favourite> customer2Favourites = customerIdTree.get(customer2ID).getList();
            KVPTree<Date,Long> temp = new KVPTree<Date,Long>(-1);
            int i = 0;
            int j = 0;
            while(i < customer1Favourites.size() && j < customer2Favourites.size())//Loops through the array of the customer subtree, and if they share a restaurant ID adds them to a new array
            {
                if(customer1Favourites.get(i).getRestaurantID() < customer1Favourites.get(j).getRestaurantID())
                {
                    i++;
                }
                else if(customer1Favourites.get(i).getRestaurantID() > customer1Favourites.get(j).getRestaurantID())
                {
                    j++;
                }
                else
                {
                    if(customer1Favourites.get(i).getDateFavourited().before(customer2Favourites.get(j).getDateFavourited()))
                    {
                        temp.add(customer2Favourites.get(j).getDateFavourited(),-customer2Favourites.get(j).getRestaurantID());
                    }
                    else
                    {
                        temp.add(customer1Favourites.get(i).getDateFavourited(), -customer1Favourites.get(i).getRestaurantID());
                    }
                    i++;
                    j++;
                }
            }
            return getLongListArray(temp.getList());
        }
        return new Long[0];
    }

    public Long[] getMissingFavouriteRestaurants(Long customer1ID, Long customer2ID) {
      if(dataChecker.isValid(customer1ID) && dataChecker.isValid(customer2ID) && customerIdTree.get(customer1ID) != null && customerIdTree.get(customer2ID) != null)
      {
          MyArrayList<Favourite> customer1Favourites = customerIdTree.get(customer1ID).getList();
          MyArrayList<Favourite> customer2Favourites = customerIdTree.get(customer2ID).getList();
          KVPTree<Date,Long> temp = new KVPTree<Date,Long>(-1);
          int i = 0;
          int j = 0;
          while(i < customer1Favourites.size() && j < customer2Favourites.size())//Loops through the array of the customer subtree, and if they don't share a restaurant ID adds them to a new array
          {
              if(customer1Favourites.get(i).getRestaurantID() < customer1Favourites.get(j).getRestaurantID())
              {
                  temp.add(customer1Favourites.get(i).getDateFavourited(), - customer1Favourites.get(i).getRestaurantID());
                  i++;
              }
              else if(customer1Favourites.get(i).getRestaurantID() > customer1Favourites.get(j).getRestaurantID())
              {
                  j++;
              }
              else
              {
                  i++;
              }
          }
          for(; i < customer1Favourites.size(); i++)//Adds remaining values if second list is exhausted
          {
              temp.add(customer1Favourites.get(i).getDateFavourited(),- customer1Favourites.get(i).getRestaurantID());
          }
          return getLongListArray(temp.getList());
        }
        return new Long[0];
    }

    public Long[] getNotCommonFavouriteRestaurants(Long customer1ID, Long customer2ID) {
      if(dataChecker.isValid(customer1ID) && dataChecker.isValid(customer2ID) && customerIdTree.get(customer1ID) != null && customerIdTree.get(customer2ID) != null)
      {
          MyArrayList<Favourite> customer1Favourites = customerIdTree.get(customer1ID).getList();
          MyArrayList<Favourite> customer2Favourites = customerIdTree.get(customer2ID).getList();
          KVPTree<Date,Long> temp = new KVPTree<Date,Long>(-1);
          int i = 0;
          int j = 0;
          while(i < customer1Favourites.size() && j < customer2Favourites.size())//Loops through the array of the customer subtree, and if they don't share a restaurant ID adds them to a new array
          {
              if(customer1Favourites.get(i).getRestaurantID() < customer1Favourites.get(j).getRestaurantID())
              {
                  temp.add(customer1Favourites.get(i).getDateFavourited(),- customer1Favourites.get(i).getRestaurantID());
                  i++;
              }
              else if(customer1Favourites.get(i).getRestaurantID() > customer1Favourites.get(j).getRestaurantID())
              {
                  temp.add(customer2Favourites.get(i).getDateFavourited(),- customer2Favourites.get(i).getRestaurantID());
                  j++;
              }
              else
              {
                  i++;
              }
          }
          for(; i < customer1Favourites.size(); i++)//Adds remaining values if either list is exhausted
          {
              temp.add(customer1Favourites.get(i).getDateFavourited(),- customer1Favourites.get(i).getRestaurantID());
          }
          for(; j < customer1Favourites.size(); j++)
          {
              temp.add(customer2Favourites.get(i).getDateFavourited(),- customer2Favourites.get(i).getRestaurantID());
          }
          return getLongListArray(temp.getList());
        }
        return new Long[0];
    }


    public Long[] getTopCustomersByFavouriteCount() {//Finds the size of the subtrees for each customer, and sorts them
        MyArrayList<KVLTree<Long,Favourite>> li1 = customerIdTree.getList();
        if(li1 != null)
        {
            KVPTree<OrderedTrio<Integer,Date,Long>, Long> tree = new KVPTree<OrderedTrio<Integer,Date,Long>, Long>();//Uses a tree with key value trio to make sure data is sorted correctly
            for(int i = 0; i < li1.size(); i++)
            {
                Favourite temp = li1.get(i).getRoot().getValue().getValue();
                tree.add(new OrderedTrio<Integer,Date,Long>(- li1.get(i).size(),temp.getDateFavourited(),temp.getID()),temp.getCustomerID());
            }
            MyArrayList<Long> li2 = tree.getList();
            Long[] arr = new Long[20];
            for(int i=0;i<20 && i < li2.size();i++)
            {
                arr[i] = li2.get(i);
            }
            return arr;
          }
          return new Long[20];
    }

    public Long[] getTopRestaurantsByFavouriteCount() {//Finds the size of the subtrees for each restaurant, and sorts them
        MyArrayList<KVLTree<Long,Favourite>> li1 = restaurantIdTree.getList();
        if(li1 != null)
        {
            KVPTree<OrderedTrio<Integer,Date,Long>, Long> tree = new KVPTree<OrderedTrio<Integer,Date,Long>, Long>();
            for(int i = 0; i < li1.size(); i++)
            {
                  Favourite temp = li1.get(i).getRoot().getValue().getValue();
                  tree.add(new OrderedTrio<Integer,Date,Long>(- li1.get(i).size(),temp.getDateFavourited(), temp.getID()),temp.getRestaurantID());
            }
            MyArrayList<Long> li2 = tree.getList();
            Long[] arr = new Long[20];
            for(int i=0;i<20 && i < li2.size();i++)
            {
                arr[i] = li2.get(i);
            }
            return arr;
        }
        return new Long[20];
    }


    private Favourite[] getListArray(MyArrayList<Favourite> favList){//Converts the arraylist to an array by checking through its linked list array
        Favourite[] arr = new Favourite[favList.size()];
        int i = 0;
        for(i = 0;i < arr.length;i++)
        {
            arr[i] = favList.get(i);
        }
        return arr;
    }

    private Long[] getLongListArray(MyArrayList<Long> favList){//Converts the arraylist to an array by checking through its linked list array
        Long[] arr = new Long[favList.size()];
        int i = 0;
        for(i = 0;i < arr.length;i++)
        {
            arr[i] = favList.get(i);
        }
        return arr;
    }


}
