package uk.ac.warwick.cs126.structures;

public class KVLTree<K extends Comparable<K>,V>{
  TreeNode<KeyValuePair<K,V>> root;
  int values;
  MyArrayList<V> contents;
  int depth;
  int inverse;
  public KVLTree() {
      root = null;
      values = 0;
      contents = new MyArrayList<V>();
      inverse = 1;
  }
  public KVLTree(int backwards) {//Put -1 as the field for the tree to be sorted backwards
    root = null;
    values = 0;
    contents = new MyArrayList<V>();
    inverse = backwards;//Stores whether the tree should be sorted in reverse order
  }

  public TreeNode<KeyValuePair<K,V>> getRoot()
  {
      return root;
  }

  private int height(TreeNode<KeyValuePair<K,V>> node) {
    if (node == null)
    {
        return 0;
    }
    return node.getHeight();
  }

  private int max(int val1, int val2) { //Finds the higher of two iintegers
    if(val1 > val2)
    {
        return val1;
    }
    return val2;
  }

  public int size()
  {
      return values;
  }

  private TreeNode<KeyValuePair<K,V>> rightRotate(TreeNode<KeyValuePair<K,V>> y) {//Rotates values to the left if unbalanced, making sure no nodes are deleted
      TreeNode<KeyValuePair<K,V>> x = y.getLeft();
      TreeNode<KeyValuePair<K,V>> z = x.getRight();
      x.setRight(y);
      y.setLeft(z);
      y.setHeight(max(height(y.getLeft()), height(y.getRight())) + 1);
      x.setHeight(max(height(x.getLeft()), height(x.getRight())) + 1);
      return x;
  }

  private TreeNode<KeyValuePair<K,V>> leftRotate(TreeNode<KeyValuePair<K,V>> x) {//Rotates values to the right if unbalanced, making sure no nodes are deleted
      TreeNode<KeyValuePair<K,V>> y = x.getRight();
      TreeNode<KeyValuePair<K,V>> z = y.getLeft();
      y.setLeft(x);
      x.setRight(z);
      x.setHeight(max(height(x.getLeft()), height(x.getRight())) + 1);
      y.setHeight(max(height(y.getLeft()), height(y.getRight())) + 1);
      return y;
  }

  // Get balance factor of a node
  private int getBalanceFactor(TreeNode<KeyValuePair<K,V>> node) {
    if (node == null)//Determines whether the tree is unbalanced by comparing the heights of children
    {
      return 0;
    }
    return height(node.getLeft()) - height(node.getRight());
  }

  // Insert a node

  public void add(K key, V value) {
      if(key != null)
      {
          if (root==null) {
              values ++;
              root = new TreeNode<>(new KeyValuePair<>(key,value));//Sets the root to the new node if it is not initialised yet, otherwise adds it normally
          }
          else
          {
              root = addToSubTree(root, key, value);//Adds the new value
          }
      }
  }

  public TreeNode<KeyValuePair<K,V>> addToSubTree(TreeNode<KeyValuePair<K,V>> node, K key, V value)
  {
      // Find the position and insert the node
      if (node == null) //Adds the new node to the tree as a leaf
      {
          values ++;
          return (new TreeNode<>(new KeyValuePair<>(key,value)));
      }
      if (key.compareTo(node.getValue().getKey()) * inverse  < 0) //Navigates the tree
      {
          node.setLeft(addToSubTree(node.getLeft(), key, value));
      }
      else if (key.compareTo(node.getValue().getKey()) * inverse  > 0)
      {
          node.setRight(addToSubTree(node.getRight(), key, value));
      }
      else //Overwrites the current node if it already exists
      {
          node.setValue(new KeyValuePair<>(key,value));
          return node;
      }
      // Update the balance factor of each node
      // And, balance the tree
      node.setHeight(1 + max(height(node.getLeft()), height(node.getRight())));
      int balanceFactor = getBalanceFactor(node);
      if (balanceFactor > 1) //Rebalances the tree as necesarry, depending on which side is too heavily weighted
      {
          if (key.compareTo(node.getLeft().getValue().getKey()) * inverse  < 0)
          {
              return rightRotate(node);
          }
          else if (key.compareTo(node.getLeft().getValue().getKey()) * inverse  > 0)
          {
              node.setLeft(leftRotate(node.getLeft()));
              return rightRotate(node);
          }
      }
      else if (balanceFactor < -1)
      {
          if (key.compareTo(node.getRight().getValue().getKey()) * inverse  > 0)
          {
              return leftRotate(node);
          }
          else if (key.compareTo(node.getRight().getValue().getKey()) * inverse  < 0)
          {
              node.setRight(rightRotate(node.getRight()));
              return leftRotate(node);
          }
      }
      return node;
  }

  public V getLowest()
  {
      if(root == null)
      {
          return null;
      }
      return  nodeWithMimumValue(root).getValue().getValue();
  }

  private TreeNode<KeyValuePair<K,V>> nodeWithMimumValue(TreeNode<KeyValuePair<K,V>> node)
  {
      TreeNode<KeyValuePair<K,V>> temp = root;//Gets the smallest node in a subtree
      while (temp.getLeft() != null)
      {
          temp = temp.getLeft();
      }
      return temp;
  }

  public void remove(K key) {
      if(key != null)
      {
          root = removeNode(root, key);
      }
  }
  // Delete a node
  public TreeNode<KeyValuePair<K,V>> removeNode(TreeNode<KeyValuePair<K,V>> node, K key) {
      // Find the node to be deleted and remove it
      if (node == null)
      {
          return node;
      }
      if (key.compareTo(node.getValue().getKey()) * inverse  < 0) //Navigates to the node that needs deleting
      {
          node.setLeft(removeNode(node.getLeft(), key));
      }
      else if (key.compareTo(node.getValue().getKey()) * inverse  > 0)
      {
          node.setRight(removeNode(node.getRight(), key));
      }
      else
      {
          if ((node.getLeft() == null) || (node.getRight() == null))
          {//Replaces the tree with its child's subtree if it only has one
              TreeNode<KeyValuePair<K,V>> temp = null;
              if (temp == node.getLeft())
              {
                  temp = node.getRight();
              }
              else
              {
                  temp = node.getLeft();
              }
              if (temp == null)
              {
                  temp = node;
                  node = null;
              }
              else
              {
                  node = temp;
              }
              values --;
          }
          else
          {//Overwrites this node's value with the smallest value in its right subtree, then deletes that value
              TreeNode<KeyValuePair<K,V>> temp = nodeWithMimumValue(node.getRight());
              node.setValue(temp.getValue());
              node.setRight(removeNode(node.getRight(), temp.getValue().getKey()));
          }
      }
      if (node == null)
      {
          return node;
      }
      // Update the balance factor of each node and balance the tree
      node.setHeight(max(height(node.getLeft()), height(node.getRight())) + 1);
      int balanceFactor = getBalanceFactor(node);
      if (balanceFactor > 1) {
          if (getBalanceFactor(node.getLeft()) * inverse  >= 0)
          {
              return rightRotate(node);
          }
          else
          {
              node.setLeft(leftRotate(node.getLeft()));
              return rightRotate(node);
          }
      }
      if (balanceFactor < -1)
      {
          if (getBalanceFactor(node.getRight()) * inverse <= 0)
          {
              return leftRotate(node);
          }
          else
          {
              node.setRight(rightRotate(node.getRight()));
              return leftRotate(node);
          }
      }
      return node;
  }

  public V get(K key)
  {
      if(key != null)
      {
          return getFromSubTree(root, key);
      }
      return null;
  }

  public V getFromSubTree(TreeNode<KeyValuePair<K,V>> node, K key)
  {
      if (node == null) //Returns null if the value isn't found
      {
          return null;
      }
      if (key.compareTo(node.getValue().getKey()) * inverse < 0) //Navigates to the node that you want to find
      {
          return getFromSubTree(node.getLeft(),key);
      }
      else if (key.compareTo(node.getValue().getKey()) * inverse > 0)
      {
          return getFromSubTree(node.getRight(),key);
      }
      else
      {
          return node.getValue().getValue();
      }
  }

  public MyArrayList<V> getList()
  {
      contents = new MyArrayList<V>(size());
      inOrder(root);
      return contents;
  }

  private void inOrder(TreeNode<KeyValuePair<K,V>>node) { //Traverses the tree, starting with the leftmost node
      if (node != null)
      {
          inOrder(node.getLeft());
          contents.add(node.getValue().getValue());
          inOrder(node.getRight());
      }
  }
}
