package uk.ac.warwick.cs126.util;

import uk.ac.warwick.cs126.interfaces.IDataChecker;

import uk.ac.warwick.cs126.models.Customer;
import uk.ac.warwick.cs126.models.Restaurant;
import uk.ac.warwick.cs126.models.Favourite;
import uk.ac.warwick.cs126.models.Review;
import java.lang.Math;
import java.util.Date;

public class DataChecker implements IDataChecker {

    public DataChecker() {
        // Initialise things here
    }

    public Long extractTrueID(String[] repeatedID) {
        if(repeatedID.length == 3)
        {
            if(repeatedID[0].compareTo(repeatedID[1]) == 0 || repeatedID[0].compareTo(repeatedID[2]) == 0)
            {
                return Long.parseLong(repeatedID[0]);
            }
            else if(repeatedID[1].compareTo(repeatedID[2]) == 0)
            {
                return Long.parseLong(repeatedID[1]);
            }
        }
        return null;
    }

    public boolean isValid(Long inputID) {
    if(inputID != null && inputID > 0)
        {
        Long i = 1L;
        int[] counts = {0,0,0,0,0,0,0,0,0,0};
            if(inputID < 10000000000000000L && inputID > 1111111111111110L)
            {
            for(i = 1L; i < 10000000000000000L; i *= 10L)
            {
                if((inputID/i) % 10L == 0L || ++ counts[(int) ((inputID/i) % 10L)] > 3)
                {
                    return false;
                }
            }
            return true;
            }
        }
    return false;
    }

    public boolean isValid(Customer customer) {
        return (customer != null &&
        customer.getID() != null &&
        customer.getFirstName() != null &&
        customer.getLastName() != null &&
        customer.getDateJoined() != null &&
        Math.abs(customer.getLatitude()) < 90 &&
        Math.abs(customer.getLongitude()) < 180 &&
        isValid(customer.getID()));
    }

    public boolean isValid(Restaurant restaurant) {
        if(restaurant != null)
        {
            restaurant.setID(extractTrueID(restaurant.getRepeatedID()));
            return (restaurant.getID() != null &&
            isValid(restaurant.getID()) &&
            restaurant.getRepeatedID() != null &&
            (restaurant.getCustomerRating() >= 0 &&
            restaurant.getCustomerRating() <= 5) &&
            (restaurant.getFoodInspectionRating() >= 0 &&
            restaurant.getFoodInspectionRating() <= 5) &&
            (restaurant.getWarwickStars() >= 0 && restaurant.getWarwickStars() <= 3) &&
            (restaurant.getDateEstablished().compareTo(restaurant.getLastInspectedDate()) < 0) &&
            restaurant.getName() != null &&
            restaurant.getOwnerFirstName() != null &&
            restaurant.getOwnerLastName() != null &&
            restaurant.getCuisine() != null &&
            restaurant.getEstablishmentType() != null &&
            restaurant.getPriceRange() != null &&
            restaurant.getDateEstablished() != null &&
            Math.abs(restaurant.getLatitude()) < 90 &&
            Math.abs(restaurant.getLongitude()) < 180 &&
            restaurant.getLastInspectedDate() != null);
        }
        else{
            return false;
        }
    }

    public boolean isValid(Favourite favourite) {
        return (favourite != null &&
        favourite.getID() != null &&
        isValid(favourite.getID()) &&
        favourite.getRestaurantID() != null &&
        isValid(favourite.getCustomerID()) &&
        favourite.getCustomerID() != null &&
        isValid(favourite.getRestaurantID()) &&
        favourite.getDateFavourited() != null);
    }

    public boolean isValid(Review review) {
        return (review != null &&
        review.getID() != null &&
        isValid(review.getID()) &&
        review.getRestaurantID() != null &&
        isValid(review.getRestaurantID()) &&
        review.getCustomerID() != null &&
        isValid(review.getCustomerID()) &&
        review.getReview() != null &&
        review.getDateReviewed() != null);
    }
}
