package uk.ac.warwick.cs126.structures;
public class KVPTree<K extends Comparable<K>,V> {
    TreeNode<KeyValuePair<K,V>> root;
    MyArrayList<V> contents;
      int values;
      int inverse;
    public KVPTree() {
        root = null;
        values = 0;
        contents = null;
        inverse = 1;
    }

    public KVPTree(int backwards) {
        root = null;
        values = 0;
        contents = null;
        inverse = backwards;
    }

    public int size()
    {
        return values;
    }

    private void addToSubTree(TreeNode<KeyValuePair<K,V>> n, K key, V value) {
        if (n!=null) // sanity check!
        {
            K nKey = n.getValue().getKey();
            if (key.compareTo(nKey) * inverse < 0)
            {
                if (n.getLeft()==null)
                {
                    n.setLeft(new TreeNode<>(new KeyValuePair<>(key,value)));
                    values ++;
                }
                else
                {
                    addToSubTree(n.getLeft(), key, value);
                }
            }
            else
           {
                if (n.getRight()==null)
                {
                    n.setRight(new TreeNode<>(new KeyValuePair<>(key,value)));
                    values ++;
                }
                else
                {
                    addToSubTree(n.getRight(), key, value);
                }
            }
        }
    }


    public void add(K key, V value) {
        if (root==null)
        {
            root = new TreeNode<>(new KeyValuePair<>(key,value));
        }
        else
        {
            addToSubTree(root, key, value);
        }
    }

    public MyArrayList<V> getList()
    {
        contents = new MyArrayList<V>();
        inOrder(root);
        return contents;
    }

    private void inOrder(TreeNode<KeyValuePair<K,V>>node) {
        if (node != null)
        {
            inOrder(node.getLeft());
            contents.add(node.getValue().getValue());
            inOrder(node.getRight());
        }
    }

}
