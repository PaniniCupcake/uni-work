package uk.ac.warwick.cs126.util;

import uk.ac.warwick.cs126.interfaces.IConvertToPlace;
import uk.ac.warwick.cs126.models.Place;
import uk.ac.warwick.cs126.structures.MyHashMap;


import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;

import org.apache.commons.io.IOUtils;

public class ConvertToPlace implements IConvertToPlace {

  private Place[] allPlaces;
  private MyHashMap<String,Place> placesHashMap;

  //in the constructor, I am adding all the places to the hashmap
  public ConvertToPlace() {
      allPlaces = getPlacesArray();
      placesHashMap = new MyHashMap<>(5009);
      String placeStr;
      for (Place place: allPlaces){
          placeStr = String.valueOf(place.getLatitude()) + String.valueOf(place.getLongitude());
          placesHashMap.add(placeStr, place);
      }

  }

  public Place convert(float latitude, float longitude) {
      //when I need to search for a place, I simply use the 'placesHashMap',
      //it much faster than a linear search of the 'allPlaces' array
      String placeStr = String.valueOf(latitude) + String.valueOf(longitude);
      Place place = placesHashMap.get(placeStr);

      if (place == null){
          return new Place("", "", 0.0f, 0.0f); //when no place is found
      }
      else{
          return place;
      }

  }

    public Place[] getPlacesArray() {
        Place[] placeArray = new Place[0];

        try {
            InputStream resource = ConvertToPlace.class.getResourceAsStream("/data/placeData.tsv");
            if (resource == null) {
                String currentPath = Paths.get(".").toAbsolutePath().normalize().toString();
                String resourcePath = Paths.get(currentPath, "data", "placeData.tsv").toString();
                File resourceFile = new File(resourcePath);
                resource = new FileInputStream(resourceFile);
            }

            byte[] inputStreamBytes = IOUtils.toByteArray(resource);
            BufferedReader lineReader = new BufferedReader(new InputStreamReader(
                    new ByteArrayInputStream(inputStreamBytes), StandardCharsets.UTF_8));

            int lineCount = 0;
            String line;
            while ((line = lineReader.readLine()) != null) {
                if (!("".equals(line))) {
                    lineCount++;
                }
            }
            lineReader.close();

            Place[] loadedPlaces = new Place[lineCount - 1];

            BufferedReader tsvReader = new BufferedReader(new InputStreamReader(
                    new ByteArrayInputStream(inputStreamBytes), StandardCharsets.UTF_8));

            int placeCount = 0;
            String row;

            tsvReader.readLine();
            while ((row = tsvReader.readLine()) != null) {
                if (!("".equals(row))) {
                    String[] data = row.split("\t");
                    Place place = new Place(
                            data[0],
                            data[1],
                            Float.parseFloat(data[2]),
                            Float.parseFloat(data[3]));
                    loadedPlaces[placeCount++] = place;
                }
            }
            tsvReader.close();

            placeArray = loadedPlaces;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return placeArray;
    }
}
