package uk.ac.warwick.cs126.structures;
public class TreeNode<E extends Comparable<E>> {

    private E value;
    private TreeNode<E> left;
    private TreeNode<E> right;
    private int height;

    public TreeNode(E val)
    {
        value = val;
        left = null;
        right = null;
        height = 1;
    }

    public void setHeight(int val)
    {
      height = val;
    }

    public int getHeight()
    {
      return height;
    }

    public E getValue() {
        return value;
    }

    public TreeNode<E> getLeft() {
        return left;
    }

    public TreeNode<E> getRight() {
        return right;
    }

    public void setValue(E v) {
        value = v;
    }

    public void setLeft(TreeNode<E> p) {
        left = p;
    }

    public void setRight(TreeNode<E> p) {
        right = p;
    }

}
