package uk.ac.warwick.cs126.structures;

public class KeyValuePair<K extends Comparable<K>,V> implements Comparable<KeyValuePair<K,V>> { //The keys must be able to be compared with other keys

    protected K key;
    protected V value;

    public KeyValuePair(K k, V v) { //Stores a key and a value
        key = k;
        value = v;
    }

    public K getKey() {
        return key;
    }

    public V getValue() {
        return value;
    }

    public int compareTo(KeyValuePair<K,V> o) {//Only compares the key with another KVP's key if compared
        return o.getKey().compareTo(this.getKey());
    }
}
