package uk.ac.warwick.cs126.structures;

public class KVPLinkedList<K extends Comparable<K>,V> { //Makes sure only comparables can be used

    protected ListElement<KeyValuePair<K,V>> head;
    protected int size;

    public KVPLinkedList() {
        head = null;
        size = 0;
    }

    public void add(K key, V value) {
        this.add(new KeyValuePair<K,V>(key,value));
    }

    public void add(KeyValuePair<K,V> kvp) {
        ListElement<KeyValuePair<K,V>> new_element = new ListElement<>(kvp);
        new_element.setNext(head);
        if(head != null)
        {
          head.setPrev(new_element);
        }
        head = new_element;
        size++;
    }


    public int size() {
        return size;
    }

    public ListElement<KeyValuePair<K,V>> getHead() {
        return head;
    }

    public V get(K key) {
        ListElement<KeyValuePair<K,V>> temp = head;
        while(temp != null) {
            if(temp.getValue().getKey().equals(key))
            {
                return temp.getValue().getValue();
            }
            temp = temp.getNext();
        }
        return null;
    }

    public ListElement<KeyValuePair<K,V>> getElement(K key) {
      ListElement<KeyValuePair<K,V>> temp = head;
      while(temp != null) {
          if(temp.getValue().getKey().equals(key))
          {
              return temp;
          }
          temp = temp.getNext();
      }
      return null;
    }

    public void remove(K key)
    {//Removes an unwanted element
      ListElement<KeyValuePair<K,V>> temp = getElement(key);

          if(temp.getNext() != null)
          {
              if(temp.getPrev() != null)
              {
                  temp.getNext().setPrev(temp.getPrev());
                  temp.getPrev().setNext(temp.getNext());
              }
              else
              {
                  temp.getNext().setPrev(null);
                  head = temp.getNext();
              }
          }
          else
          {
            if(temp.getPrev() != null)
            {
                temp.getPrev().setNext(null);
            }
            else
            {
                head = null;
            }
          }
          size --;
          }

}
