package uk.ac.warwick.cs126.structures;

public class OrderedTrio<E extends Comparable<E>,E2 extends Comparable<E2>,E3 extends Comparable<E3>> implements Comparable<OrderedTrio<E,E2,E3>>{
    private E val;
    private E2 val2;
    private E3 val3;
    public OrderedTrio(E Val1,E2 Val2, E3 Val3)//Stores three possibly different values, and allows them to be compared with other ordered trios of the same type
    {
        val = Val1;
        val2 = Val2;
        val3 = Val3;
    }

    public E getVal1()
    {
        return val;
    }

    public E2 getVal2()
    {
        return val2;
    }

    public E3 getVal3()
    {
        return val3;
    }

    public int compareTo(OrderedTrio<E,E2,E3> other)
    {
        if(val.compareTo(other.getVal1()) > 0)
        {
            return 1;
        }
        else if(val.compareTo(other.getVal1()) < 0)
        {
            return -1;
        }
        else if(val2.compareTo(other.getVal2()) > 0)
        {
            return 1;
        }
        else if(val2.compareTo(other.getVal2()) < 0)
        {
            return -1;
        }
        else if(val3.compareTo(other.getVal3()) > 0)
        {
            return 1;
        }
        else if(val3.compareTo(other.getVal3()) < 0)
        {
            return -1;
        }
        return 0;
    }

}
