package uk.ac.warwick.cs126.structures;
public class Merge<K extends Comparable<K>,V>//Didn't end up using this cus its harder to use in script than a tree sort
{
    public MyArrayList<KeyValuePair<K,V>> merge(MyArrayList<KeyValuePair<K,V>> Kvs) //A merge sort that sorts via id
    {
      if(Kvs.size() == 1)
      {
          return Kvs;
      }
      int i,j,k = 0;
      MyArrayList<KeyValuePair<K,V>> arr1 = new MyArrayList<KeyValuePair<K,V>>((Kvs.size() + 1)/2);
      MyArrayList<KeyValuePair<K,V>> arr2 = new MyArrayList<KeyValuePair<K,V>>(Kvs.size() /2);
      MyArrayList<KeyValuePair<K,V>> arr3 = new MyArrayList<KeyValuePair<K,V>>(Kvs.size());
      for(i=0;i<(Kvs.size()+1)/2;i++)
      {
          arr1.set(i,Kvs.get(i));
      }
      for(i = (Kvs.size() +1)/2;i< Kvs.size();i++)
      {
          arr2.set(i,Kvs.get(i));
      }
      i = j = 0;
      arr1 = merge(arr1);
      arr2 = merge(arr2);
      while(i < arr1.size() || j < arr2.size())
      {
        if(j >= arr2.size()  || i < arr1.size() && arr1.get(i).compareTo(arr2.get(i)) < 0)
        {//Checks each condition in turn
            arr3.set(k,arr1.get(i));
            i ++;
            k ++;
        }
        else
        {
            arr3.set(k,arr2.get(j));
            j ++;
            k ++;
        }
      }
      return arr3;
    }

    public MyArrayList<V> mergedValues(MyArrayList<KeyValuePair<K,V>> Kvs)
    {
        MyArrayList<V> arr = new MyArrayList<V>();
        for(int i = 0; i < Kvs.size(); i++)
        {
            arr.set(i,Kvs.get(i).getValue());
        }
        return arr;
    }
}
