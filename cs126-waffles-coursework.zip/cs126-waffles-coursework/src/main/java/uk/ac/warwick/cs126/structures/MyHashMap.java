package uk.ac.warwick.cs126.structures;
@SuppressWarnings("unchecked")
public class MyHashMap<K extends Comparable<K>,V>{
  protected KVPLinkedList<K,V>[] table;
  private int currentElements;

      public MyHashMap() {
          this(503);
      }

      public MyHashMap(int size) {
          table = new KVPLinkedList[size];
          currentElements = 0;
          initTable();
      }

      protected void initTable() {
          for(int i = 0; i < table.length; i++) {
              table[i] = new KVPLinkedList<>();
          }
      }

      protected int hash(K key) {
          int code = key.hashCode();
          return code;
      }


      public void add(K key, V value) {
          int hash_code = hash(key);
          int location = Math.abs(hash_code % table.length);
          table[location].add(key,value);
          currentElements ++;
      }

      public V get(K key) {
          int hash_code = hash(key);
          int location = Math.abs(hash_code % table.length);
          return table[location].get(key);
      }

      public void remove(K key)
      {
        if(get(key) != null)
        {
          int hash_code = hash(key);
          int location = Math.abs(hash_code % table.length);
          table[location].remove(key);
          currentElements --;
        }
      }

      public int size()
      {
        return currentElements;
      }

}
