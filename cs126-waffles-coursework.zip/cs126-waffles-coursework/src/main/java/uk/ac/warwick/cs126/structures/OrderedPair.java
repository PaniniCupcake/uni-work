package uk.ac.warwick.cs126.structures;

public class OrderedPair<E extends Comparable<E>,E2 extends Comparable<E2>> implements Comparable<OrderedPair<E,E2>>{
    private E val;
    private E2 val2;
    public OrderedPair(E Val1,E2 Val2)//Stores two possibly different values, and allows them to be compared with other ordered pairs of the same type
    {
        val = Val1;
        val2 = Val2;
    }

    public E getVal1()
    {
        return val;
    }

    public E2 getVal2()
    {
        return val2;
    }

    public int compareTo(OrderedPair<E,E2> other)
    {
        if(val.compareTo(other.getVal1()) > 0)
        {
            return 1;
        }
        else if(val.compareTo(other.getVal1()) < 0)
        {
            return -1;
        }
        else if(val2.compareTo(other.getVal2()) > 0)
        {
            return 1;
        }
        else if(val2.compareTo(other.getVal2()) < 0)
        {
            return -1;
        }
        return 0;
    }

}
