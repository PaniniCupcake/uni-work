#! /usr/bin/python
import rospy    # Import Python lib for ROS
rospy.init_node('printer_node')     # Init a node
print '\n\n HELLO WORLD - ROS\n\n'  # Print the message