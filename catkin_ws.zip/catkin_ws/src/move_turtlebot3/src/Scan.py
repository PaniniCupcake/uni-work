#!/usr/bin/env python

from math import pi, sqrt, atan2, cos, sin
import numpy as np

import rospy
import tf
from std_msgs.msg import Empty
from sensor_msgs.msg import LaserScan 
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist, Pose2D    
from control import Controller


class Turtlebot3():
    def __init__(self):
        rospy.init_node("turtlebot3_scan")
        rospy.loginfo("Press Ctrl + C to terminate")
        self.vel_pub = rospy.Publisher("cmd_vel", Twist, queue_size=10)
        self.rate = rospy.Rate(5)
        self.vel = Twist()
        self.rubberBand = 100
        self.rubberBand2 = 100
        # subscribe to scan
        self.cont = Controller(0.99,0.01,0)
        self.cont2 = Controller(0.99,0.01,0)
        self.cont.setPoint(0.3)
        self.logging_counter = 0
        self.l = list()
        self.pose = Pose2D()
        self.odom_sub = rospy.Subscriber("odom", Odometry, self.odom_callback)
        self.scan_sub = rospy.Subscriber("scan", LaserScan, self.scan_callback)
        self.rs = []
        for i in range(90):
            self.rs.append(100)
        while True:
            try:
                self.run()
            except rospy.ROSInterruptException:
                rospy.loginfo("Action terminated.")
                break


    def run(self):
        rospy.loginfo(self.rs[0])
        close = False
        self.vel.linear.x = 0
        self.vel.angular.z = 0
        for i in range(89):
            if self.rs[i] <= 0.3:
                rospy.loginfo(i)
                rospy.loginfo(self.rs[i])
                self.rubberBand -= 1
                self.cont2.setPoint(self.pose.theta - pi/2)
                close = True
        if self.rubberBand > 0:
            n = self.cont.update(self.rs[0])
            rospy.loginfo(n)
            self.vel.linear.x = -n
            self.vel.angular.z = 0
        elif close and self.rubberBand2 > 0:
            a = self.cont2.update(self.pose.theta)
            self.vel.linear.x = 0
            self.vel.angular.z = a
            self.rubberBand2 -= 1
        else:
            n = self.cont.update(self.rs[0])
            rospy.loginfo(n)
            self.vel.linear.x = -n
            self.vel.angular.z = 0
            self.rubberBand = 100
            self.rubberBand2 = 100

        self.vel_pub.publish(self.vel)
        self.rate.sleep()

    def scan_callback(self, msg):
        # get pose = (x, y, theta) from odometry topic
        for i in range(90):
            self.rs[i] = msg.ranges[i]

    
    def odom_callback(self, msg):
        # get pose = (x, y, theta) from odometry topic
        quaternion = [msg.pose.pose.orientation.x,msg.pose.pose.orientation.y,\
                    msg.pose.pose.orientation.z, msg.pose.pose.orientation.w]
        (roll, pitch, yaw) = tf.transformations.euler_from_quaternion(quaternion)
        self.pose.theta = yaw
        self.pose.x = msg.pose.pose.position.x
        self.pose.y = msg.pose.pose.position.y




if __name__ == '__main__':
    robot = Turtlebot3()
