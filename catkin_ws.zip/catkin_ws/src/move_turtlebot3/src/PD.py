#!/usr/bin/env python

from math import pi, sqrt, atan2, cos, sin
import numpy as np

import rospy
import tf
from std_msgs.msg import Empty
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist, Pose2D    
from control import Controller



class Turtlebot3():
    def __init__(self):
        rospy.init_node("turtlebot3_move_square")
        rospy.loginfo("Press Ctrl + C to terminate")
        self.vel_pub = rospy.Publisher("cmd_vel", Twist, queue_size=10)
        self.rate = rospy.Rate(5)
             
        # subscribe to odometry
        self.pose = Pose2D()
        self.logging_counter = 0
        self.trajectory = list()
        self.odom_sub = rospy.Subscriber("odom", Odometry, self.odom_callback)
        
        try:
            self.run()
        except rospy.ROSInterruptException:
            rospy.loginfo("Action terminated.")
        finally:
            # save trajectory into csv file
            np.savetxt('./trajectory.csv', np.array(self.trajectory), fmt='%f', delimiter=',')


    def run(self):
        vel = Twist()
        vel.linear.x = 0.5
        vel.angular.z = 0
        cont = Controller(0.99,0.01,0)
        for j in range(42):
            self.vel_pub.publish(vel)
            self.rate.sleep()

        cont.setPoint(pi/2)
        vel.linear.x = 0
        vel.angular.z = pi / 16
        for i in range(100):
            self.vel_pub.publish(vel)
            var = self.pose.theta
            if var < 0:
                var += 2*pi
            self.rate.sleep()
            vel.angular.z = cont.update(self.pose.theta)

        vel.linear.x = 0.5
        vel.angular.z = 0
        for j in range(42):
            self.vel_pub.publish(vel)
            self.rate.sleep()

        cont.setPoint(pi)
        vel.linear.x = 0
        vel.angular.z = pi / 16
        for i in range(100):
            self.vel_pub.publish(vel)
            var = self.pose.theta
            if var < 0:
                var += 2*pi
            self.rate.sleep()
            vel.angular.z = cont.update(self.pose.theta)
            
        vel.linear.x = 0.5
        vel.angular.z = 0
        for j in range(42):
            self.vel_pub.publish(vel)
            self.rate.sleep()

        cont.setPoint(-pi /2)
        vel.linear.x = 0
        vel.angular.z = pi / 16
        for i in range(100):
            self.vel_pub.publish(vel)
            var = self.pose.theta
            if var > 0:
                var -= 2*pi
            self.rate.sleep()
            vel.angular.z = cont.update(self.pose.theta)

        vel.linear.x = 0.5
        vel.angular.z = 0
        for j in range(42):
            self.vel_pub.publish(vel)
            self.rate.sleep()
        vel.linear.x = 0
        vel.angular.z = 0
        self.vel_pub.publish(vel)

    def odom_callback(self, msg):
        # get pose = (x, y, theta) from odometry topic
        quaternion = [msg.pose.pose.orientation.x,msg.pose.pose.orientation.y,\
                    msg.pose.pose.orientation.z, msg.pose.pose.orientation.w]
        (roll, pitch, yaw) = tf.transformations.euler_from_quaternion(quaternion)
        self.pose.theta = yaw
        self.pose.x = msg.pose.pose.position.x
        self.pose.y = msg.pose.pose.position.y

        # logging once every 100 times (Gazebo runs at 1000Hz; we save it at 10Hz)
        self.logging_counter += 1
        if self.logging_counter == 100:
            self.logging_counter = 0
            self.trajectory.append([self.pose.x, self.pose.y])  # save trajectory
            rospy.loginfo("odom: x=" + str(self.pose.x) +\
                ";  y=" + str(self.pose.y) + ";  theta=" + str(yaw))


if __name__ == '__main__':
    robot = Turtlebot3()
