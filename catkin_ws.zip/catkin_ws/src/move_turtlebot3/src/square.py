#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from math import pi

class Turtlebot3():
    def __init__(self):
        rospy.init_node("turtlebot3_move_square")
        rospy.loginfo("Press Ctrl + C to terminate")
        self.vel_pub = rospy.Publisher("cmd_vel", Twist, queue_size=10)
        self.rate = rospy.Rate(2.5)
        self.run()


    def run(self):
        vel = Twist()
        for i in range(4):
            vel.linear.x = 0.5
            vel.angular.z = 0
            for j in range(22):
                self.vel_pub.publish(vel)
                self.rate.sleep()
            vel.linear.x = 0
            vel.angular.z = pi / 16
            rospy.loginfo("Turning")
            for j in range(22):
                self.vel_pub.publish(vel)
                self.rate.sleep()
        vel.linear.x = 0
        vel.angular.z = 0
        self.vel_pub.publish(vel)

if __name__ == '__main__':
    try:
        robot = Turtlebot3()
    except rospy.ROSInterruptException:
        rospy.loginfo("Action terminated.")