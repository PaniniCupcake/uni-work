
from math import pi, sqrt, atan2, cos, sin
import numpy as np

import rospy
import tf
from std_msgs.msg import Empty
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist, Pose2D    
from control import Controller



class Turtlebot3():
    def __init__(self):
        rospy.init_node("turtlebot3_move_square")
        rospy.loginfo("Press Ctrl + C to terminate")
        self.vel_pub = rospy.Publisher("cmd_vel", Twist, queue_size=10)
        self.rate = rospy.Rate(5)
             
        # subscribe to odometry
        self.pose = Pose2D()
        self.logging_counter = 0
        self.trajectory = list()
        self.trackParticles = list()
        self.odom_sub = rospy.Subscriber("odom", Odometry, self.odom_callback)
        self.particles = []
        self.efg = []
        for i in range(100):
            self.particles.append([0,0,0])
            self.efg.append([np.random.normal() / 100,np.random.normal() / 100,np.random.normal() / 100])
        try:
            self.run()
        except rospy.ROSInterruptException:
            rospy.loginfo("Action terminated.")
        finally:
            # save trajectory into csv file
            np.savetxt('./trajectory.csv', np.array(self.trajectory), fmt='%f', delimiter=',')
            np.savetxt('./particles.csv', np.array(self.trackParticles), fmt='%f', delimiter=',')


    def translateParticles(self, dist):
        x_av = 0
        y_av = 0
        for i in range(100):
            self.particles[i][0] += (self.efg[i][0] + dist) * cos(self.particles[i][2])
            self.particles[i][1] += (self.efg[i][0] + dist) * sin(self.particles[i][2])
            self.particles[i][2] += self.efg[i][1]
            self.trackParticles.append([self.particles[i][0], self.particles[i][1]])
            x_av += self.particles[i][0]
            y_av += self.particles[i][1]
        x2 = 0
        y2 = 0
        xy = 0
        for i in range(100):
            x2 += (self.particles[i][0] - x_av)**2
            y2 += (self.particles[i][1] - y_av)**2
            xy += (self.particles[i][1] - y_av)*(self.particles[i][0] - x_av)
        #print("X mean:")
        #print(x_av / 100)
        #print("Y mean:")
        #print(y_av / 100)
        print("Covar:")
        print(str(x2) + ',' + str(xy))
        print(str(xy) + ',' + str(y2))

    def rotateParticles(self,amount):
        for i in range(100):
            self.particles[i][2] += self.efg[i][2] + amount

    def run(self):
        vel = Twist()
        cont = Controller(0.99,0.01,0)
        x_store = self.pose.x
        y_store = self.pose.y
        r_store = self.pose.theta
        #Move to 0,0,0
        cont.setPoint(-pi /2)
        vel.linear.x = 0
        vel.angular.z = pi / 16
        for i in range(75):
            self.vel_pub.publish(vel)
            var = self.pose.theta
            if var > 0:
                var -= 2*pi
            self.rate.sleep()
            vel.angular.z = cont.update(self.pose.theta)

        self.rotateParticles(self.pose.theta - r_store)
        x_store = self.pose.x
        y_store = self.pose.y
        r_store = self.pose.theta

        vel.linear.x = 0.25
        vel.angular.z = 0

        for j in range(14):
            self.vel_pub.publish(vel)
            self.rate.sleep()

        self.translateParticles(sqrt((self.pose.x - x_store)**2 + (self.pose.y - y_store)**2))

        x_store = self.pose.x
        y_store = self.pose.y
        r_store = self.pose.theta

        ##ore
        cont.setPoint(pi)
        vel.linear.x = 0
        vel.angular.z = pi / 16
        for i in range(100):
            self.vel_pub.publish(vel)
            var = self.pose.theta
            if var < 0:
                var += 2*pi
            self.rate.sleep()
            vel.angular.z = cont.update(self.pose.theta)
            
        self.rotateParticles(self.pose.theta - r_store)
        x_store = self.pose.x
        y_store = self.pose.y
        r_store = self.pose.theta

        vel.linear.x = 0.25
        vel.angular.z = 0
        for j in range(21):
            self.vel_pub.publish(vel)
            self.rate.sleep()

        self.translateParticles(sqrt((self.pose.x - x_store)**2 + (self.pose.y - y_store)**2))
        x_store = self.pose.x
        y_store = self.pose.y
        r_store = self.pose.theta

        cont.setPoint(pi)
        vel.linear.x = 0
        vel.angular.z = pi / 16
        for i in range(100):
            self.vel_pub.publish(vel)
            var = self.pose.theta
            if var < 0:
                var += 2*pi
            self.rate.sleep()
            vel.angular.z = cont.update(self.pose.theta)
            
        self.rotateParticles(self.pose.theta - r_store)
        x_store = self.pose.x
        y_store = self.pose.y
        r_store = self.pose.theta
        
        vel.linear.x = 0.25
        vel.angular.z = 0
        for j in range(42):
            self.vel_pub.publish(vel)
            self.rate.sleep()

        self.translateParticles(sqrt((self.pose.x - x_store)**2 + (self.pose.y - y_store)**2))
        x_store = self.pose.x
        y_store = self.pose.y
        r_store = self.pose.theta


        cont.setPoint(-pi /2)
        vel.linear.x = 0
        vel.angular.z = pi / 16
        for i in range(100):
            self.vel_pub.publish(vel)
            var = self.pose.theta
            if var > 0:
                var -= 2*pi
            self.rate.sleep()
            vel.angular.z = cont.update(self.pose.theta)

        self.rotateParticles(self.pose.theta - r_store)
        x_store = self.pose.x
        y_store = self.pose.y
        r_store = self.pose.theta

        vel.linear.x = 0.25
        vel.angular.z = 0
        for j in range(42):
            self.vel_pub.publish(vel)
            self.rate.sleep()
        vel.linear.x = 0
        vel.angular.z = 0
        self.vel_pub.publish(vel)
        
        self.translateParticles(sqrt((self.pose.x - x_store)**2 + (self.pose.y - y_store)**2))

    def odom_callback(self, msg):
        # get pose = (x, y, theta) from odometry topic
        quaternion = [msg.pose.pose.orientation.x,msg.pose.pose.orientation.y,\
                    msg.pose.pose.orientation.z, msg.pose.pose.orientation.w]
        (roll, pitch, yaw) = tf.transformations.euler_from_quaternion(quaternion)
        self.pose.theta = yaw
        self.pose.x = msg.pose.pose.position.x
        self.pose.y = msg.pose.pose.position.y

        # logging once every 100 times (Gazebo runs at 1000Hz; we save it at 10Hz)
        self.logging_counter += 1
        if self.logging_counter == 100:
            self.logging_counter = 0
            self.trajectory.append([self.pose.x, self.pose.y])  # save trajectory
            rospy.loginfo("odom: x=" + str(self.pose.x) +\
                ";  y=" + str(self.pose.y) + ";  theta=" + str(yaw))
            


if __name__ == '__main__':
    robot = Turtlebot3()
