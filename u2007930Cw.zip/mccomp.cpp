
#include "llvm/ADT/APFloat.h"
#include "llvm/ADT/Optional.h"
#include "llvm/ADT/STLExtras.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/Constants.h"
#include "llvm/IR/DerivedTypes.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Type.h"
#include "llvm/IR/Verifier.h"
#include "llvm/Support/FileSystem.h"
#include "llvm/Support/Host.h"
#include "llvm/MC/TargetRegistry.h"
#include "llvm/Support/TargetSelect.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Target/TargetMachine.h"
#include "llvm/Target/TargetOptions.h"
#include <algorithm>
#include <cassert>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <map>
#include <memory>
#include <queue>
#include <string.h>
#include <string>
#include <system_error>
#include <utility>
#include <vector>

using namespace llvm;
using namespace llvm::sys;

FILE *pFile;

//===----------------------------------------------------------------------===//
// Lexer
//===----------------------------------------------------------------------===//

// The lexer returns one of these for known things.
enum TOKEN_TYPE {

  IDENT = -1,        // [a-zA-Z_][a-zA-Z_0-9]*
  ASSIGN = int('='), // '='

  // delimiters
  LBRA = int('{'),  // left brace
  RBRA = int('}'),  // right brace
  LPAR = int('('),  // left parenthesis
  RPAR = int(')'),  // right parenthesis
  SC = int(';'),    // semicolon
  COMMA = int(','), // comma

  // types
  INT_TOK = -2,   // "int"
  VOID_TOK = -3,  // "void"
  FLOAT_TOK = -4, // "float"
  BOOL_TOK = -5,  // "bool"

  // keywords
  EXTERN = -6,  // "extern"
  IF = -7,      // "if"
  ELSE = -8,    // "else"
  WHILE = -9,   // "while"
  RETURN = -10, // "return"
  // TRUE   = -12,     // "true"
  // FALSE   = -13,     // "false"

  // literals
  INT_LIT = -14,   // [0-9]+
  FLOAT_LIT = -15, // [0-9]+.[0-9]+
  BOOL_LIT = -16,  // "true" or "false" key words

  // logical operators
  AND = -17, // "&&"
  OR = -18,  // "||"

  // operators
  PLUS = int('+'),    // addition or unary plus
  MINUS = int('-'),   // substraction or unary negative
  ASTERIX = int('*'), // multiplication
  DIV = int('/'),     // division
  MOD = int('%'),     // modular
  NOT = int('!'),     // unary negation

  // comparison operators
  EQ = -19,      // equal
  NE = -20,      // not equal
  LE = -21,      // less than or equal to
  LT = int('<'), // less than
  GE = -23,      // greater than or equal to
  GT = int('>'), // greater than

  // special tokens
  EOF_TOK = 0, // signal end of file

  // invalid
  INVALID = -100 // signal invalid token
};

// TOKEN struct is used to keep track of information about a token
struct TOKEN {
  int type = -100;
  std::string lexeme;
  int lineNo;
  int columnNo;
};

static std::string IdentifierStr; // Filled in if IDENT
static int IntVal;                // Filled in if INT_LIT
static bool BoolVal;              // Filled in if BOOL_LIT
static float FloatVal;            // Filled in if FLOAT_LIT
static std::string StringVal;     // Filled in if String Literal
static int lineNo, columnNo;

static TOKEN returnTok(std::string lexVal, int tok_type) {
  TOKEN return_tok;
  return_tok.lexeme = lexVal;
  return_tok.type = tok_type;
  return_tok.lineNo = lineNo;
  return_tok.columnNo = columnNo - lexVal.length() - 1;
  return return_tok;
}

// Read file line by line -- or look for \n and if found add 1 to line number
// and reset column number to 0
/// gettok - Return the next token from standard input.
static TOKEN gettok() {

  static int LastChar = ' ';
  static int NextChar = ' ';

  // Skip any whitespace.
  while (isspace(LastChar)) {
    if (LastChar == '\n' || LastChar == '\r') {
      lineNo++;
      columnNo = 1;
    }
    LastChar = getc(pFile);
    columnNo++;
  }

  if (isalpha(LastChar) ||
      (LastChar == '_')) { // identifier: [a-zA-Z_][a-zA-Z_0-9]*
    IdentifierStr = LastChar;
    columnNo++;

    while (isalnum((LastChar = getc(pFile))) || (LastChar == '_')) {
      IdentifierStr += LastChar;
      columnNo++;
    }

    if (IdentifierStr == "int")
      return returnTok("int", INT_TOK);
    if (IdentifierStr == "bool")
      return returnTok("bool", BOOL_TOK);
    if (IdentifierStr == "float")
      return returnTok("float", FLOAT_TOK);
    if (IdentifierStr == "void")
      return returnTok("void", VOID_TOK);
    if (IdentifierStr == "bool")
      return returnTok("bool", BOOL_TOK);
    if (IdentifierStr == "extern")
      return returnTok("extern", EXTERN);
    if (IdentifierStr == "if")
      return returnTok("if", IF);
    if (IdentifierStr == "else")
      return returnTok("else", ELSE);
    if (IdentifierStr == "while")
      return returnTok("while", WHILE);
    if (IdentifierStr == "return")
      return returnTok("return", RETURN);
    if (IdentifierStr == "true") {
      BoolVal = true;
      return returnTok("true", BOOL_LIT);
    }
    if (IdentifierStr == "false") {
      BoolVal = false;
      return returnTok("false", BOOL_LIT);
    }

    return returnTok(IdentifierStr.c_str(), IDENT);
  }

  if (LastChar == '=') {
    NextChar = getc(pFile);
    if (NextChar == '=') { // EQ: ==
      LastChar = getc(pFile);
      columnNo += 2;
      return returnTok("==", EQ);
    } else {
      LastChar = NextChar;
      columnNo++;
      return returnTok("=", ASSIGN);
    }
  }

  if (LastChar == '{') {
    LastChar = getc(pFile);
    columnNo++;
    return returnTok("{", LBRA);
  }
  if (LastChar == '}') {
    LastChar = getc(pFile);
    columnNo++;
    return returnTok("}", RBRA);
  }
  if (LastChar == '(') {
    LastChar = getc(pFile);
    columnNo++;
    return returnTok("(", LPAR);
  }
  if (LastChar == ')') {
    LastChar = getc(pFile);
    columnNo++;
    return returnTok(")", RPAR);
  }
  if (LastChar == ';') {
    LastChar = getc(pFile);
    columnNo++;
    return returnTok(";", SC);
  }
  if (LastChar == ',') {
    LastChar = getc(pFile);
    columnNo++;
    return returnTok(",", COMMA);
  }

  if (isdigit(LastChar) || LastChar == '.') { // Number: [0-9]+.
    std::string NumStr;

    if (LastChar == '.') { // Floatingpoint Number: .[0-9]+
      do {
        NumStr += LastChar;
        LastChar = getc(pFile);
        columnNo++;
      } while (isdigit(LastChar));

      FloatVal = strtof(NumStr.c_str(), nullptr);
      return returnTok(NumStr, FLOAT_LIT);
    } else {
      do { // Start of Number: [0-9]+
        NumStr += LastChar;
        LastChar = getc(pFile);
        columnNo++;
      } while (isdigit(LastChar));

      if (LastChar == '.') { // Floatingpoint Number: [0-9]+.[0-9]+)
        do {
          NumStr += LastChar;
          LastChar = getc(pFile);
          columnNo++;
        } while (isdigit(LastChar));

        FloatVal = strtof(NumStr.c_str(), nullptr);
        return returnTok(NumStr, FLOAT_LIT);
      } else { // Integer : [0-9]+
        IntVal = strtod(NumStr.c_str(), nullptr);
        return returnTok(NumStr, INT_LIT);
      }
    }
  }

  if (LastChar == '&') {
    NextChar = getc(pFile);
    if (NextChar == '&') { // AND: &&
      LastChar = getc(pFile);
      columnNo += 2;
      return returnTok("&&", AND);
    } else {
      LastChar = NextChar;
      columnNo++;
      return returnTok("&", int('&'));
    }
  }

  if (LastChar == '|') {
    NextChar = getc(pFile);
    if (NextChar == '|') { // OR: ||
      LastChar = getc(pFile);
      columnNo += 2;
      return returnTok("||", OR);
    } else {
      LastChar = NextChar;
      columnNo++;
      return returnTok("|", int('|'));
    }
  }

  if (LastChar == '!') {
    NextChar = getc(pFile);
    if (NextChar == '=') { // NE: !=
      LastChar = getc(pFile);
      columnNo += 2;
      return returnTok("!=", NE);
    } else {
      LastChar = NextChar;
      columnNo++;
      return returnTok("!", NOT);
      ;
    }
  }

  if (LastChar == '<') {
    NextChar = getc(pFile);
    if (NextChar == '=') { // LE: <=
      LastChar = getc(pFile);
      columnNo += 2;
      return returnTok("<=", LE);
    } else {
      LastChar = NextChar;
      columnNo++;
      return returnTok("<", LT);
    }
  }

  if (LastChar == '>') {
    NextChar = getc(pFile);
    if (NextChar == '=') { // GE: >=
      LastChar = getc(pFile);
      columnNo += 2;
      return returnTok(">=", GE);
    } else {
      LastChar = NextChar;
      columnNo++;
      return returnTok(">", GT);
    }
  }

  if (LastChar == '/') { // could be division or could be the start of a comment
    LastChar = getc(pFile);
    columnNo++;
    if (LastChar == '/') { // definitely a comment
      do {
        LastChar = getc(pFile);
        columnNo++;
      } while (LastChar != EOF && LastChar != '\n' && LastChar != '\r');

      if (LastChar != EOF)
        return gettok();
    } else
      return returnTok("/", DIV);
  }

  // Check for end of file.  Don't eat the EOF.
  if (LastChar == EOF) {
    columnNo++;
    return returnTok("0", EOF_TOK);
  }

  // Otherwise, just return the character as its ascii value.
  int ThisChar = LastChar;
  std::string s(1, ThisChar);
  LastChar = getc(pFile);
  columnNo++;
  return returnTok(s, int(ThisChar));
}

//===----------------------------------------------------------------------===//
// Parser
//===----------------------------------------------------------------------===//

/// CurTok/getNextToken - Provide a simple token buffer.  CurTok is the current
/// token the parser is looking at.  getNextToken reads another token from the
/// lexer and updates CurTok with its results.
static TOKEN CurTok;
static std::deque<TOKEN> tok_buffer;

static TOKEN getNextToken() {

  if (tok_buffer.size() == 0)
    tok_buffer.push_back(gettok());

  TOKEN temp = tok_buffer.front();
  tok_buffer.pop_front();

  return CurTok = temp;
}

static void putBackToken(TOKEN tok) { tok_buffer.push_front(tok); }




//===----------------------------------------------------------------------===//
// Code gen stuff (Wanted to put AST related things together)
//===----------------------------------------------------------------------===//

static LLVMContext TheContext;
static IRBuilder<> Builder(TheContext);
static std::unique_ptr<Module> TheModule;
static std::vector<std::map<std::string, AllocaInst*>> NamedValues; // local var table(s)
static std::map<std::string, GlobalVariable *> GlobalNamedValues; //global var table

//Unique alloca generation for each type
static AllocaInst *CreateEntryBlockAllocaVoid(Function *TheFunction,StringRef VarName) {
  IRBuilder<> TmpB(&TheFunction->getEntryBlock(), TheFunction->getEntryBlock().begin());
  
  return TmpB.CreateAlloca(Type::getVoidTy(TheContext), nullptr, VarName);
}
static AllocaInst *CreateEntryBlockAllocaBool(Function *TheFunction,StringRef VarName) {
  IRBuilder<> TmpB(&TheFunction->getEntryBlock(), TheFunction->getEntryBlock().begin());
  
  return TmpB.CreateAlloca(Type::getInt1Ty(TheContext), nullptr, VarName);
}
static AllocaInst *CreateEntryBlockAllocaFloat(Function *TheFunction,StringRef VarName) {
  IRBuilder<> TmpB(&TheFunction->getEntryBlock(), TheFunction->getEntryBlock().begin());
  
  return TmpB.CreateAlloca(Type::getFloatTy(TheContext), nullptr, VarName);
}
static AllocaInst *CreateEntryBlockAllocaInt(Function *TheFunction,StringRef VarName) {
  IRBuilder<> TmpB(&TheFunction->getEntryBlock(), TheFunction->getEntryBlock().begin());
  
  return TmpB.CreateAlloca(Type::getInt32Ty(TheContext), nullptr, VarName);
}

static Value * cast(Value *v, Type * ty) //Cast from one type to another
{
    Value *Result = v;
    if(v->getType()->isFloatTy())
    {
        if(ty->isIntegerTy(1))
        {
            fprintf(stderr,"Warning: Conversion from float to bool may result in loss");
            Result = Builder.CreateFPToSI(Result,Type::getFloatTy(TheContext));
            Result = Builder.CreateIntCast(Result, Type::getInt1Ty(TheContext), true);
        }
        else if(ty->isIntegerTy(32))
        {
            fprintf(stderr,"Warning: Conversion from float to int may result in loss");
            Result = Builder.CreateFPToSI(v,Type::getFloatTy(TheContext));
        }
    }
    else if(v->getType()->isIntegerTy(1))
    {
        if(ty->isFloatTy())
        {
            Result = Builder.CreateSIToFP(v,Type::getFloatTy(TheContext));
        }
        else if(ty->isIntegerTy(32))
        {
            Result = Builder.CreateIntCast(Result, Type::getInt32Ty(TheContext), true);
        }
    }
    else if(v->getType()->isIntegerTy(32))
    {
        if(ty->isFloatTy())
        {
            Result = Builder.CreateSIToFP(v,Type::getFloatTy(TheContext));
        }
        else if(ty->isIntegerTy(1))
        {
            fprintf(stderr,"Warning: Conversion from int to bool may result in loss");
            Result = Builder.CreateIntCast(Result, Type::getInt1Ty(TheContext), true);
        }
    }
    return v;
}

static Value * cast(Value *v, std::string ty) //Same as above but when you know what to cast to
{
    Value *Result = v;
    if(v->getType()->isFloatTy())
    {
        if(ty.compare("bool") == 0)
        {
            Result = Builder.CreateFPToSI(Result,Type::getFloatTy(TheContext));
            Result = Builder.CreateIntCast(Result, Type::getInt1Ty(TheContext), true);
        }
        else if(ty.compare("float") == 0)
        {
            Result = Builder.CreateFPToSI(v,Type::getFloatTy(TheContext));
        }
    }
    else if(v->getType()->isIntegerTy(1))
    {
        if(ty.compare("float") == 0)
        {
            Result = Builder.CreateSIToFP(v,Type::getFloatTy(TheContext));
        }
        else if(ty.compare("int") == 0)
        {
            Result = Builder.CreateIntCast(Result, Type::getInt32Ty(TheContext), true);
        }
    }
    else if(v->getType()->isIntegerTy(32))
    {
        if(ty.compare("float") == 0)
        {
            Result = Builder.CreateSIToFP(v,Type::getFloatTy(TheContext));
        }
        else if(ty.compare("bool") == 0)
        {
            Result = Builder.CreateIntCast(Result, Type::getInt1Ty(TheContext), true);
        }
    }
    return v;
}

//===----------------------------------------------------------------------===//
// AST nodes
//===----------------------------------------------------------------------===//

static int depth; //Used for ast tree and scope
static int max_depth = 0;

std::string GetIndent() //An indent for printing the ast tree
{
  std::string s = "";
  int i;
  for(i = 0;i<depth;i++)
  {
    s += "  ";
  }
  s += "-|-|";
  return s;
}

/// ASTnode - Base class for all AST nodes.
class ASTnode {
public:
  virtual ~ASTnode() {}
  virtual Value *codegen() = 0;
  int type;
  virtual std::string to_string() const {};
  std::string Name;
  std::string getName()
  {
    return Name;
  }
};

class IdentASTnode : public ASTnode {
  std::string Val;
  TOKEN Tok;
  std::string Name;
  int type;
public:
  IdentASTnode(TOKEN tok, std::string val) : Val(std::move(val)), Tok(tok){}
  virtual Value *codegen() override{
      Name = Val;
      GlobalVariable* g = GlobalNamedValues[Name];
      if(!g)//Check global variables, then each level of local
      {
          AllocaInst *V = NamedValues[depth][Name];
          int i = depth - 1;
          fprintf(stderr,"Parsing variable (%s) \n",Val.c_str());
          while (!V && i >= 0)
          {
              V = NamedValues[i][Name];
              i--;
          }
          if(!V)
          {
            fprintf(stderr,"Reference to unknown variable (%s) \n",Val.c_str());
            exit(0);
          }
          return Builder.CreateLoad(V->getAllocatedType(), V, Name); //Builds the correct value
      }
      return Builder.CreateLoad(g->getValueType(), g, Name);
  };
  std::string getName()
  {
    return Val;
  }
  virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+= "Identity: ";
        s+= Val;
        s+="\n";
        depth--;
        return s;
    }
};

class TypeASTnode : public ASTnode {//Just stores a type
  TOKEN Type;
  TOKEN Tok;
  std::string Name;
  int type;
public:
  TypeASTnode(TOKEN tok, TOKEN type) : Type(std::move(type)), Tok(tok),Name(type.lexeme.c_str()) {}

  virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+= "Type: ";
        s+= Type.lexeme.c_str();
        s+="\n";
        depth--;
        return s;
    }

};


/// IntASTnode - Class for integer literals like 1, 2, 10,
class IntASTnode : public ASTnode {
  int Val;
  TOKEN Tok;
  std::string Name;
  int type = 1;
public:
  IntASTnode(TOKEN tok, int val) : Val(std::move(val)), Tok(tok) {}
  virtual Value *codegen() override{
     return ConstantInt::get(TheContext, APInt(32,Val,true));
  };
  virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+="Integer: ";
        s+= std::to_string(Val);
        s+= "\n";
        depth--;
        return s;
    }
};
class FloatASTnode : public ASTnode {
  float Val;
  TOKEN Tok;
  std::string Name;
  int type = 2;
public:
  FloatASTnode(TOKEN tok, float val) : Val(std::move(val)), Tok(tok) {}
  virtual Value *codegen() override{
    fprintf(stderr,"Creating float %f\n",Val);
    return ConstantFP::get(TheContext, APFloat(Val));
  };
  virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+= "Float: ";
        s+= std::to_string(Val);
        s+= "\n";
        depth--;
        return s;
    }

};

class BoolASTnode : public ASTnode {
  bool Val;
  TOKEN Tok;
  std::string Name;
  int type = 0;
public:
  BoolASTnode(TOKEN tok, bool val) : Val(std::move(val)), Tok(tok) {}
  virtual Value *codegen() override{
    if(Val)
    {
      return ConstantInt::get(TheContext, APInt(1,1,false));
    }
    return ConstantInt::get(TheContext, APInt(1,0,false));
  };
  virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+= "Bools+= ";
        s+= std::to_string(Val);
        s+= "\n";
        depth--;
        return s;
    }

};


class BinaryOperatorAST : public ASTnode {
  TOKEN Op;
  std::unique_ptr<ASTnode> LHS,RHS;
  TOKEN Tok;
  std::string Name;
  int type; //0 For bool, 1 for int, 2 for float
  public:
  BinaryOperatorAST(TOKEN op, std::unique_ptr<ASTnode> LHS,
                std::unique_ptr<ASTnode> RHS,TOKEN tok)
    :Op(std::move(op)), LHS(std::move(LHS)), RHS(std::move(RHS)), Tok(tok) {}
    virtual Value *codegen() override{
        fprintf(stderr,"Gen binop\n");
        Value* left = LHS->codegen();
        Value* right = RHS->codegen();
        type = 1;
        if(left->getType()->isFloatTy())//Converts both to float if one side is a float
        {
          if(!right->getType()->isFloatTy()) 
          {
              right = Builder.CreateSIToFP(right,Type::getFloatTy(TheContext));
          }
          type = 2;
        }
        else if(right->getType()->isFloatTy())
        {
          if(!left->getType()->isFloatTy())
          {
              left = Builder.CreateSIToFP(left,Type::getFloatTy(TheContext));
          }
          type = 2;
        }
        switch(Op.type)
        {
          case PLUS:
            {
              if(type == 2)
              {
                return Builder.CreateFAdd(left,right);//Chooses which operator to use
              }
              return Builder.CreateAdd(left,right);
            }
          case MINUS:
            {
              if(type == 2)
              {
                return Builder.CreateFSub(left,right);
              }
              return Builder.CreateSub(left,right);
            }
          case ASTERIX:
            {
              if(type == 2)
              {
                return Builder.CreateFMul(left,right);
              }
              return Builder.CreateMul(left,right);
            }
          case DIV:
            {
              if(type == 2)
              {
                return Builder.CreateFDiv(left,right);
              }
              return Builder.CreateSDiv(left,right);
            }
          case MOD:
            {
              if(type == 2)
              {
                return Builder.CreateFRem(left,right);
              }
              return Builder.CreateSRem(left,right);
            }
          default:
            break;
        }
        right = Builder.CreateSIToFP(right,Type::getFloatTy(TheContext));//These operators only return bool, so both types can be converted to floats
        left = Builder.CreateSIToFP(left,Type::getFloatTy(TheContext));
        type = 0;
        switch(Op.type)
        {
          case EQ:
            {
              return Builder.CreateFCmpUEQ(left,right);
            }
          case NE:
            {
              return Builder.CreateFCmpUNE(left,right);
            }
          case LE:
            {
              return Builder.CreateFCmpULE(left,right);
            }
          case LT:
            {
              return Builder.CreateFCmpULT(left,right);
            }
          case GE:
            {
              return Builder.CreateFCmpUGE(left,right);
            }
          case GT:
            {
              return Builder.CreateFCmpUGT(left,right);
            }
          case OR:
            {
              return Builder.CreateOr(left,right);
            }
          case AND:
            {
              return Builder.CreateAnd(left,right);
            }
          default:
          {
              fprintf(stderr,"Invalid operator");
              exit(0);
          }
        }

    };
    virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+= "Binary Operator: ";
        s+= Op.lexeme.c_str();
        s+= "\n";
        s+= LHS->to_string().c_str();
        s+= RHS->to_string().c_str();
        depth--;
        return s;
    }
};


class UnaryOperatorAST : public ASTnode {
  TOKEN Op;
  std::unique_ptr<ASTnode> RHS;
  TOKEN Tok;
  std::string Name;
  int type;
  public:
  UnaryOperatorAST(TOKEN op, std::unique_ptr<ASTnode> RHS,TOKEN tok)
    : Op(std::move(op)),RHS(std::move(RHS)), Tok(tok) {}
    virtual Value *codegen() override{
      Value* right = RHS->codegen();
      type = 1;
      if(right->getType()->isFloatTy())
      {
        type = 2;
      }
      switch(Op.type)
        {
          case MINUS:
            {
              if(type == 2)//Chooses the appropriate type
              {
                return Builder.CreateFSub(ConstantFP::get(TheContext, APFloat(0.0f)),right);
              }
              return Builder.CreateSub(ConstantInt::get(TheContext, APInt(32,0,true)),right);
            }
          case NOT:
            {
              type = 0;
              return Builder.CreateNot(right);
            }
        }
      return nullptr;
    };
    virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+= "Unary Operator: ";
        s+= Op.lexeme.c_str();
        s+= "\n";
        s+= RHS->to_string().c_str();
        depth--;
        return s;
    }
};

class GlobalVarDeclAST : public ASTnode {
  TOKEN Tok;
  public:
  std::string Name;
  std::string Type;
  GlobalVarDeclAST(std::string type,
                std::string name,TOKEN tok)
    :Type(type), Name(name), Tok(tok) {}
      virtual Value *codegen() override{
        GlobalVariable* var;
        fprintf(stderr,"Creating global variable %s\n",Type.c_str());
        Value *InitVal;
        if(Type.compare("int") == 0)//Sets type
        {
          fprintf(stderr,"Creating global variable %s\n",Type.c_str());
            var = new GlobalVariable(*(TheModule.get()),Type::getInt32Ty(TheContext),false,GlobalValue::CommonLinkage,ConstantInt::get(TheContext, APInt(32,0,false)));
        }
        else if(Type.compare("float") == 0)
        { 
            var = new GlobalVariable(*(TheModule.get()),Type::getFloatTy(TheContext),false,GlobalValue::CommonLinkage,ConstantFP::get(TheContext, APFloat(0.0f)));
        }
        else if(Type.compare("bool") == 0)
        {
            var = new GlobalVariable(*(TheModule.get()),Type::getInt1Ty(TheContext),false,GlobalValue::CommonLinkage,ConstantInt::get(TheContext, APInt(1,0,false)));
        }
        else
        {
          fprintf(stderr,"Global variable typed incorrectly\n");
          exit(0);
        }
        fprintf(stderr,"Creatied global variable %s\n",Type.c_str());
        fprintf(stderr,"-.-\n");
        GlobalNamedValues[Name] = var;//Saves
        return var;
    }
    virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+= "Variable declaration: ";
        s+= Name;
        s+= "\n";
        depth--;
        return s;
    }
    std::string getName()
    {
      return Name;
    }
};

class VarDeclAST : public ASTnode {
  TOKEN Tok;
  public:
  std::string Name;
  std::string Type;
  VarDeclAST(std::string type,
                std::string name,TOKEN tok)
    :Type(type), Name(name), Tok(tok) {}
    virtual Value *codegen() override{//Acts as a store for the block
        return nullptr;
    }
    virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+= "Variable declaration: ";
        s+= Name;
        s+="\n";
        depth--;
        return s;
    }
    std::string getName()
    {
      return Name;
    }
};



class FuncHeadAST{
    std::string MyType;
    std::vector<std::unique_ptr<VarDeclAST>> Params; //Can be empty, a list or only void
    TOKEN Tok;
    std::string Name;
    public:
    FuncHeadAST(std::string type,std::string name,std::vector<std::unique_ptr<VarDeclAST> > params,TOKEN tok)
    :MyType(std::move(type)),Name(name),Params(std::move(params)), Tok(tok) {}
    virtual std::string getName()
    {
      return Name;
    }
    virtual Function *codegen(){
      fprintf(stderr,"Parsing for Func Head %s\n",MyType.c_str());
      fprintf(stderr,"%zu \n",Params.size());
      std::vector<Type *> Parameters;
      for (unsigned i = 0, e = Params.size(); i != e; ++i) //Determines parameter types
      {
        if(Params[i]->Type.compare("void") == 0)
        {
          fprintf(stderr,"Added void param \n");
          Parameters.push_back(Type::getVoidTy(TheContext));
        }
        else if(Params[i]->Type.compare("int") == 0)
        {
          fprintf(stderr,"Added int param \n");
          Parameters.push_back(Type::getInt32Ty(TheContext));
        }
        else if(Params[i]->Type.compare("bool") == 0)
        {
          fprintf(stderr,"Added bool param \n");
          Parameters.push_back(Type::getInt1Ty(TheContext));
        }
        else if(Params[i]->Type.compare("float") == 0)
        {
          fprintf(stderr,"Added float param \n");
          Parameters.push_back(Type::getFloatTy(TheContext));
        }
        else
        {
            fprintf(stderr,"Invalid param type");
        }
        
        if (!Params.back())
        {
          fprintf(stderr,"Loop error");
          exit(0);
        }
      }
      FunctionType *FT;
      if(MyType.compare("void") == 0)//Determines function type
      {
        FT = FunctionType::get(Type::getVoidTy(TheContext), Parameters, false);
      }
      else if(MyType.compare("int") == 0)
      {
        FT = FunctionType::get(Type::getInt32Ty(TheContext), Parameters, false);
      }
      else if(MyType.compare("bool") == 0)
      {
        FT = FunctionType::get(Type::getInt1Ty(TheContext), Parameters, false);
      }
      else if(MyType.compare("float") == 0)
      {
        FT = FunctionType::get(Type::getFloatTy(TheContext), Parameters, false);
      }
      else
      {
        fprintf(stderr,"Invalid param type");
        exit(0);
      }
      Function *F = Function::Create(FT, Function::ExternalLinkage, Name, TheModule.get());
      fprintf(stderr,"Created function %s\n",Name.c_str());
      // Set names for all arguments.
      unsigned Idx = 0;
      fprintf(stderr,"%s\n",Name.c_str());
      for (auto &Arg : F->args())
      {
          Arg.setName(Params[Idx++]->Name);
      }
      return F;
    }; 
    virtual std::string to_string(){
        depth++;
        std::string s = GetIndent();
        s+= "Function Head ";
        s+= MyType;
        s+= " ";
        s+= Name;
        s+= "\n";
        depth--;
        return s;
    }
};

class FunDeclAST : public ASTnode {
    std::unique_ptr<FuncHeadAST> Head;
    std::unique_ptr<ASTnode> Block;
    TOKEN Tok;
    std::string Name;
    public:
    FunDeclAST(std::unique_ptr<FuncHeadAST> head,std::unique_ptr<ASTnode> block,TOKEN tok)
    :Head(std::move(head)),Block(std::move(block)), Tok(tok) {}
    virtual Function *codegen() override{
          fprintf(stderr,"Codegen for function\n");
          Function *TheFunction = TheModule->getFunction(Head->getName());
          if (!TheFunction)
          {
            TheFunction = Head->codegen();
          }
          BasicBlock *BB = BasicBlock::Create(TheContext, "entry", TheFunction);
          Builder.SetInsertPoint(BB);
          // Record the function arguments in the NamedValues map.
          NamedValues[depth].clear();
          for (Argument &Arg : TheFunction->args()) 
          {

              AllocaInst * Alloca;
              if(Arg.getType()->isIntegerTy(32))
              {
                  Alloca = CreateEntryBlockAllocaInt(TheFunction, Arg.getName());
              }
              else if(Arg.getType()->isIntegerTy(1))
              {
                  Alloca = CreateEntryBlockAllocaBool(TheFunction, Arg.getName());
              }
              else if(Arg.getType()->isFloatTy())
              {
                  Alloca = CreateEntryBlockAllocaFloat(TheFunction, Arg.getName());
              }
              else if(Arg.getType()->isVoidTy())
              {
                  Alloca = CreateEntryBlockAllocaVoid(TheFunction, Arg.getName());
              }
              else{
                fprintf(stderr,"Invalid Param\n");
                exit(0);
              }
              Builder.CreateStore(&Arg, Alloca);
              fprintf(stderr,"Adding alloca %s \n",std::string(Arg.getName()).c_str());
              NamedValues[depth][std::string(Arg.getName())] = Alloca;
          }
          if (Value *RetVal = Block->codegen()) {
            // Finish off the function.
              Builder.CreateRet(RetVal);
          }
          // Validate the generated code, checking for consistency.
          verifyFunction(*TheFunction);
          return nullptr;
      }


    virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+= "Function declaration\n";
        s+= Head->to_string().c_str();
        s+= Block->to_string().c_str();
        depth--;
        return s;
    }
};



class ProgramAST : public ASTnode {
  std::list<std::unique_ptr<FuncHeadAST>> Externs;
  std::list<std::unique_ptr<ASTnode>> Decls;
  TOKEN Tok;
  std::string Name;
  public:
  ProgramAST(std::list<std::unique_ptr<FuncHeadAST>> externs, std::list<std::unique_ptr<ASTnode>> decls,TOKEN tok)
    : Externs(std::move(externs)),Decls(std::move(decls)), Tok(tok) {}
    virtual Value *codegen() override{

      fprintf(stderr,"Codegen for program\n");

      for (auto const& i : Externs) {//Parses all the externs, then all the decls
            i->codegen();
      }
      fprintf(stderr,"Finished with externs\n");
      for (auto const& i : Decls) {
            i->codegen();
      }
      return nullptr;
    }
    virtual std::string to_string() const override {
        std::string s = "--|Program\n";
        depth++;
        s+= "  -|-|Externs\n"; 
        for (auto const& i : Externs) {
            s+= i->to_string().c_str();
        }
        s+= "  -|-|Declarations\n"; 
        for (auto const& i : Decls) {
            s+= i->to_string().c_str();
        }
        depth--;
        return s;
    }
};



class BlockAST : public ASTnode {
    std::list<std::unique_ptr<VarDeclAST>> Decls;
    std::list<std::unique_ptr<ASTnode>> Statements;
    TOKEN Tok;
    std::string Name;
    public:
    BlockAST(std::list<std::unique_ptr<VarDeclAST>> decls,std::list<std::unique_ptr<ASTnode>> statements,TOKEN tok)
    :Decls(std::move(decls)),Statements(std::move(statements)), Tok(tok) {}
    virtual Value *codegen() override{

      depth ++;//Increments the scope depth
      if(depth > max_depth)//Overwrites previous if already existed, otherwise pushes a new map
      {
        std::map<std::string, AllocaInst*> temp;
        NamedValues.push_back(temp);
        max_depth = depth;
      }
      NamedValues[depth].clear();

      std::vector<AllocaInst *> OldBindings;
      Function *TheFunction = Builder.GetInsertBlock()->getParent();
      // Register all variables and emit their initializer.
      for (auto const& i : Decls) {
        const std::string &VarName = i->getName();
        Value *InitVal;
        AllocaInst *Alloca;
        if(i->Type.compare("int") == 0)
        {
            Alloca = CreateEntryBlockAllocaInt(TheFunction, VarName);
            InitVal = ConstantInt::get(TheContext, APInt(32,0,false));
        }
        else if(i->Type.compare("float") == 0)
        { 
            Alloca = CreateEntryBlockAllocaFloat(TheFunction, VarName);
            InitVal = ConstantFP::get(TheContext, APFloat(0.0f));
        }
        else if(i->Type.compare("bool") == 0)
        {
            Alloca = CreateEntryBlockAllocaBool(TheFunction, VarName);
            InitVal = ConstantInt::get(TheContext, APInt(1,0,false));
        }
        else
        {
          fprintf(stderr,"Variable typed incorrectly");
          exit(0);
        }
        Builder.CreateStore(InitVal, Alloca);
        // Remember the old variable binding so that we can restore the binding when
        // we unrecurse.
        OldBindings.push_back(NamedValues[depth][VarName]);
        // Remember this binding.
        NamedValues[depth][VarName] = Alloca;
      }
      GenerateBody();
      int j = 0;
      for (auto const& i : Decls) 
      {
          NamedValues[depth][i->getName()] = OldBindings[j];
          j++;
      }
      depth --;
      return nullptr;
    };
    Value *GenerateBody()
    {
        for (auto const& i : Statements) {
            fprintf(stderr,"Generating statement\n");
            i->codegen();
        }
        return nullptr;
    }
    virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+= "Block\n";
        depth++;
        s+= GetIndent();
        s+= "Declarations\n";
        for (auto const& i : Decls) {
            s+= i->to_string().c_str();
        }
        s+= GetIndent();
        s+= "Statements\n";
        for (auto const& i : Statements) {
            s+= i->to_string().c_str();
        }
        depth--;
        depth--;
        return s;
    }
    std::string getName()
    {
      return Name;
    }
};

class ReturnAST : public ASTnode {
    TOKEN Ret;
    std::unique_ptr<ASTnode> Expr;
    TOKEN Tok;   
    std::string Name;
    public:
    ReturnAST(TOKEN ret,std::unique_ptr<ASTnode> expr,TOKEN tok)
    :Ret(std::move(ret)),Expr(std::move(expr)), Tok(tok) {}

    virtual Value *codegen() override{//Ensures function is correct type
      Type * FuncType = Builder.getCurrentFunctionReturnType();
      if(FuncType->isVoidTy())
      {
        if(!Expr->codegen())//Empty ast returns nothing
        {
            Builder.CreateRet(nullptr);
            return nullptr;
        }
        //error
        fprintf(stderr,"Should be void return");
        exit(0);
      }
      else
      {
        if(!Expr->codegen())
        {
          fprintf(stderr,"Should be void return");
          exit(0);
        }
        auto value = cast(Expr->codegen(),FuncType);
        Builder.CreateRet(value);
      }
      return nullptr;
    };
    virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+= "Return\n";
        s+= Expr->to_string().c_str();
        depth--;
        return s;
    }
};

class IfElseAST : public ASTnode {
    std::unique_ptr<ASTnode>  Expr, Block, Else;
    TOKEN Tok;   
    std::string Name;
    public:
    IfElseAST(std::unique_ptr<ASTnode> expr,std::unique_ptr<ASTnode> block,std::unique_ptr<ASTnode> el,TOKEN tok)
    :Expr(std::move(expr)),Block(std::move(block)),Else(std::move(el)), Tok(tok) {}
    virtual Value *codegen() override{
      Function* TheFunction = Builder.GetInsertBlock()->getParent();
      Value* cond = Expr->codegen();
      cond = cast(cond,"bool");
      Value* comp = Builder.CreateICmpNE(cond, ConstantInt::get(TheContext, APInt(1,0,true)),"ifcond");
      fprintf(stderr,"Else\n");
      
      BasicBlock *ThenBB = BasicBlock::Create(TheContext, "then", TheFunction);//Blocks for each part
      BasicBlock *ElseBB = BasicBlock::Create(TheContext, "else");
      BasicBlock *MergeBB = BasicBlock::Create(TheContext, "ifcont");
      //Creates the branches and block contents
      Builder.CreateCondBr(comp, ThenBB, ElseBB);
      Builder.SetInsertPoint(ThenBB);

      Block->codegen();

      
      Builder.CreateBr(MergeBB);
      ThenBB = Builder.GetInsertBlock();

      TheFunction->getBasicBlockList().push_back(ElseBB);
      Builder.SetInsertPoint(ElseBB);

      Else->codegen();
      fprintf(stderr,"Else done\n");
      Builder.CreateBr(MergeBB);
      ElseBB = Builder.GetInsertBlock();

      TheFunction->getBasicBlockList().push_back(MergeBB);
      Builder.SetInsertPoint(MergeBB);
      return nullptr;

    };
    virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+= "If statement\n";
        s+= Expr->to_string().c_str();
        s+= Block->to_string().c_str();
        if(!Else)
        {
          depth--;
          return s;
        }
        s+= Else->to_string().c_str();
        depth--;
        return s;
    }
};

class WhileAST: public ASTnode{
    std::unique_ptr<ASTnode>  Expr, Stmt;
    TOKEN Tok;   
    std::string Name;
    public:
    WhileAST(std::unique_ptr<ASTnode>  expr,std::unique_ptr<ASTnode>  stmt,TOKEN tok)
    :Expr(std::move(expr)),Stmt(std::move(stmt)), Tok(tok) {}
    virtual Value *codegen() override{
        Function *TheFunction = Builder.GetInsertBlock()->getParent();
        BasicBlock *PreheaderBB = Builder.GetInsertBlock();
        BasicBlock *LoopBB = BasicBlock::Create(TheContext, "loop", TheFunction);
        BasicBlock *AfterBB = BasicBlock::Create(TheContext, "afterloop", TheFunction);
        Value* cond = Expr->codegen();
        cond = cast(cond,"bool");
        Value* comp = Builder.CreateICmpNE(cond, ConstantInt::get(TheContext, APInt(1,0,true)),"ifcond");
        //Initial condition check
        Builder.CreateCondBr(comp, LoopBB, AfterBB);
        Builder.SetInsertPoint(LoopBB);

        Stmt->codegen();
        //Remainder of loop
        cond = Expr->codegen();
        cond = cast(cond,"bool");
        comp = Builder.CreateICmpNE(cond, ConstantInt::get(TheContext, APInt(1,0,true)),"ifcond");
        BasicBlock *LoopEndBB = Builder.GetInsertBlock();


        Builder.CreateCondBr(comp, LoopBB, AfterBB);

        Builder.SetInsertPoint(AfterBB);



        return nullptr;
    };
    virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+= "While statement\n";
        s+= Expr->to_string().c_str();
        s+= Stmt->to_string().c_str();
        depth--;
        return s;
    }
};

class ExprAST : public ASTnode { //For variable definitions
    std::unique_ptr<ASTnode>  Id,Expr;
    TOKEN Tok;   
    std::string Name;
    public:
    ExprAST(std::unique_ptr<ASTnode> id,std::unique_ptr<ASTnode> expr,std::string name,TOKEN tok)
    :Id(std::move(id)),Expr(std::move(expr)),Name(name), Tok(tok) {}
    virtual Value *codegen() override{
      
      GlobalVariable* g = GlobalNamedValues[Name];
      fprintf(stderr,"Gen Expression (%s)\n",Name.c_str());

      IdentASTnode *LHSE = dynamic_cast<IdentASTnode*>(Id.get());
      if (!LHSE)
      {
          fprintf(stderr,"LHS must be a variable");
          exit(0);
      }
      Value *Val = Expr->codegen();
      if (!Val)
      {
        fprintf(stderr,"Invalid Expression");
        exit(0);
      }
      // Look up the name.

      g = GlobalNamedValues[Name.c_str()];
      fprintf(stderr,"Assigning to variable (%s)\n ",Name.c_str());
      if(!g)//Gets the correct scope
      {
          auto *Variable = NamedValues[depth][Name];//Local scope
          int i = depth - 1;
          while(!Variable && i >= 0)
          {
            Variable = NamedValues[i][Name];
            i--;
          }
          if (!Variable)
          {
              fprintf(stderr,"Unknown variable name (%s)\n ",Name.c_str());
              exit(0);
          }
          Val = cast(Val,Variable->getType());
          Builder.CreateStore(Val, Variable);
      }
      else
      {//Global scope
          Val = cast(Val,g->getInitializer()->getType());
          Builder.CreateStore(Val,g);
      }
      if(Val->getType()->isDoubleTy())
      {
        fprintf(stderr,"Cuntbag twatwomble\n");
      }
      return Val;
    };
    virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+= "Expression\n";
        s+= Id->to_string().c_str();
        s+= Expr->to_string().c_str();
        depth--;
        return s;
    }
};

class EmptyAST : public ASTnode {
    TOKEN Tok;
    std::string Name = "I am empty";
    public:
    EmptyAST(TOKEN tok)
    :Tok(tok) {}
    virtual Value *codegen() override{
      return nullptr;
    };
    virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+= "Empty\n";
        depth--;
        return s;
    }
    std::string getName()
    {
      return "I am empty";
    }
};

class FuncCallAST : public ASTnode {
    std::string Val;
    std::list<std::unique_ptr<ASTnode>> Exprs;
    TOKEN Tok;
    std::string Name;
    public:
    FuncCallAST(std::string val,std::list<std::unique_ptr<ASTnode>> exprs,TOKEN tok)
    :Val(val),Exprs(std::move(exprs)),Tok(tok) {}
    virtual Value *codegen() override{
      fprintf(stderr,"Calling function %s",Val.c_str());
      Function *CalleeF = TheModule->getFunction(Val);
      if (!CalleeF)
      {
          fprintf(stderr,"Unknown function referenced");
          exit(0);
      }

      // If argument mismatch error.
      if (CalleeF->arg_size() != Exprs.size())
      {
          fprintf(stderr,"Incorrect number of arguments passed");
          exit(0);
      }

      std::vector<Value *> ArgsV;
      for (auto const& i : Exprs) {
            ArgsV.push_back(i->codegen()); 
            if (!ArgsV.back())
            {
                exit(0);
            }
      }

      return Builder.CreateCall(CalleeF, ArgsV, "calltmp");
    };
    virtual std::string to_string() const override {
        depth++;
        std::string s = GetIndent();
        s+= "Function call\n";
        for (auto const& i : Exprs) {
            s+= i->to_string().c_str();
        }
        depth--;
        return s;
    }
};
/* add other AST nodes as necessary */


//===----------------------------------------------------------------------===//
// Recursive Descent Parser - Function call for each production
//===----------------------------------------------------------------------===//

/* Add function calls for each production */

// program ::= extern_list decl_list

static std::unique_ptr<ASTnode> ParseBlock();
static std::unique_ptr<ASTnode> ParseOr();
static std::unique_ptr<ASTnode> ParseElse();
static std::unique_ptr<ASTnode> ParseStatement();
static std::unique_ptr<VarDeclAST> ParseVarDecl();
static std::unique_ptr<ASTnode> ParseGlobalVarDecl();


static std::unique_ptr<ASTnode> ParseIdent() {
  fprintf(stderr,"Parsing ident Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
  auto Result = std::make_unique<IdentASTnode>(CurTok,IdentifierStr);
  getNextToken();
  return std::move(Result);
}

static std::unique_ptr<ASTnode> ParseIntExpr() {
  fprintf(stderr,"Parsing int. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
  auto Result = std::make_unique<IntASTnode>(CurTok,IntVal);
  getNextToken(); // consume the number
  return std::move(Result);
}
static std::unique_ptr<ASTnode> ParseFloatExpr() {
  fprintf(stderr,"Parsing float. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
  auto Result = std::make_unique<FloatASTnode>(CurTok,FloatVal);
  getNextToken(); 
  return std::move(Result);
}
static std::unique_ptr<ASTnode> ParseBoolExpr() {
  fprintf(stderr,"Parsing bool. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
  auto Result = std::make_unique<BoolASTnode>(CurTok,BoolVal);
  getNextToken(); 
  return std::move(Result);
}


static std::unique_ptr<ASTnode> ParseExpr(){
  fprintf(stderr,"Parsing expression. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
    TOKEN Temp = CurTok;
    getNextToken();
    if(CurTok.type == int('='))
    {
      if(Temp.type != -1)
      {
        fprintf(stderr,"Ident expected got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
        return nullptr;
      }
      putBackToken(CurTok);
      CurTok = Temp;
      auto Id = ParseIdent();
      getNextToken();
      auto Expr = ParseExpr();
      if(!Expr)
      {
        fprintf(stderr,"Invalid expr got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
        return nullptr;
      }
      auto Result = std::make_unique<ExprAST>(std::move(Id),std::move(Expr),Temp.lexeme.c_str(),CurTok);
      return Result;
    }
    putBackToken(CurTok);
    CurTok = Temp;
    auto Or = ParseOr();
    if(!Or)
    {
      fprintf(stderr,"Invalid Or got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    } 
    return Or;
}

static std::unique_ptr<ASTnode> ParseRval(){ 
  fprintf(stderr,"Parsing rval. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
    TOKEN temp = CurTok;
    switch(temp.type)
    {
      case int('-'):
      case int('!'):
      {
        getNextToken();
        auto RHS = ParseRval();
        auto Result = std::make_unique<UnaryOperatorAST>(temp,std::move(RHS),temp);
        return Result;
      }
      case INT_LIT:
      {
        return ParseIntExpr();
      }
      case FLOAT_LIT:
      {
        return ParseFloatExpr();
      }
      case BOOL_LIT: 
      {
        return ParseBoolExpr();
      }
      case int('('):
      {
        getNextToken();
        auto Result = ParseExpr();
        if(!Result || CurTok.type != int(')'))
        {
          fprintf(stderr,"Invalid result or expected ) got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
          return nullptr;
        }
        getNextToken();
        return Result;
      }
      case -1:
      {
        TOKEN Temp = CurTok;
        auto Id = ParseIdent();
        if(CurTok.type == int('('))
        {
          getNextToken();
          std::list<std::unique_ptr<ASTnode>> Exprs;
          while(CurTok.type == int('-') || CurTok.type == int('!') ||  CurTok.type == INT_LIT || 
          CurTok.type == FLOAT_LIT || CurTok.type == BOOL_LIT || CurTok.type == int('(')|| CurTok.type == -1)
          {
              auto Expr = ParseExpr();
              if(!Expr)
              {
                fprintf(stderr,"Invalid expr or expected ) got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
                return nullptr;
              }
              Exprs.push_back(std::move(Expr));
              if(CurTok.type != int(','))
              {
                break;
              }
              getNextToken();
          } 
          if( CurTok.type != int(')'))
          {
            fprintf(stderr,"expected ) got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
            break;
          } 
          getNextToken();
          auto Result =  std::make_unique<FuncCallAST>(Temp.lexeme.c_str(),std::move(Exprs),CurTok);
          return Result;
        }
        return Id;
      }
      default:
        break;
    }
    fprintf(stderr,"Expected valid rval token got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
    return nullptr;
}

static std::unique_ptr<ASTnode> ParseMulDiv(){ //Chain of near identical operators, in order of precedence.
  fprintf(stderr,"Parsing mul/div/mod. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
    auto LHS = ParseRval();
    if(!LHS)
    {
      fprintf(stderr,"Invalid rval got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    while(CurTok.type == int('*') || CurTok.type == int('/') || CurTok.type == int('%'))
    {
      TOKEN Temp = CurTok;
      getNextToken();
      auto RHS = ParseRval();
      if(!RHS)
      {fprintf(stderr,"Invalid rval got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
        return nullptr;
      }
      LHS = std::make_unique<BinaryOperatorAST>(Temp,std::move(LHS),std::move(RHS),Temp);
    }
    return LHS;
}

static std::unique_ptr<ASTnode> ParsePlusMinus(){
  fprintf(stderr,"Parsing plus/minus. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
    auto LHS = ParseMulDiv();
    if(!LHS)
    {
     fprintf(stderr,"Invalid */ got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    while(CurTok.type == int('+')||CurTok.type == int('-'))
    {
      TOKEN Temp = CurTok;
      getNextToken();
      auto RHS = ParseMulDiv();
      if(!RHS)
      {fprintf(stderr,"Invalid */ got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
        return nullptr;
      }
      LHS = std::make_unique<BinaryOperatorAST>(Temp,std::move(LHS),std::move(RHS),Temp);
    }
    return LHS;
}

static std::unique_ptr<ASTnode> ParseComparator(){
  fprintf(stderr,"Parsing comp. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
    auto LHS = ParsePlusMinus();
    if(!LHS)
    {
      fprintf(stderr,"Invalid +- got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    while(CurTok.type == LE||CurTok.type == GE||CurTok.type == int('<')||CurTok.type == int('>'))
    {
      TOKEN Temp = CurTok;
      getNextToken();
      auto RHS = ParsePlusMinus();
      if(!RHS)
      {fprintf(stderr,"Invalid +- got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
        return nullptr;
      }
      LHS = std::make_unique<BinaryOperatorAST>(Temp,std::move(LHS),std::move(RHS),Temp);
    }
    return LHS;
}

static std::unique_ptr<ASTnode> ParseEquality(){
  fprintf(stderr,"Parsing equality. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
    auto LHS = ParseComparator();
    if(!LHS)
    {
      fprintf(stderr,"Invalid comp got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    while(CurTok.type == EQ || CurTok.type == NE)
    {
      TOKEN Temp = CurTok;
      getNextToken();
      auto RHS = ParseComparator();
      if(!RHS)
      {fprintf(stderr,"Invalid comp got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
        return nullptr;
      }
      LHS = std::make_unique<BinaryOperatorAST>(Temp,std::move(LHS),std::move(RHS),Temp);
    }
    return LHS;
}

static std::unique_ptr<ASTnode> ParseAnd(){
  fprintf(stderr,"Parsing and Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
    auto LHS = ParseEquality();
    if(!LHS)
    {
      fprintf(stderr,"Invalid eq got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    while(CurTok.type == AND)
    {
      TOKEN Temp = CurTok;
      getNextToken();
      auto RHS = ParseEquality();
      if(!RHS)
      {fprintf(stderr,"Invalid eq got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
        return nullptr;
      }
      LHS = std::make_unique<BinaryOperatorAST>(Temp,std::move(LHS),std::move(RHS),Temp);
    }
    return LHS;
}

static std::unique_ptr<ASTnode> ParseOr(){
  fprintf(stderr,"Parsing or. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
    std::unique_ptr<ASTnode>  LHS = ParseAnd();
    if(!LHS)
    {
      fprintf(stderr,"Invalid and got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    while(CurTok.type == OR)
    {
      TOKEN Temp = CurTok;
      getNextToken();
      auto RHS = ParseAnd();
      if(!RHS)
      {fprintf(stderr,"Invalid and got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
        return nullptr;
      }
      LHS = std::make_unique<BinaryOperatorAST>(Temp,std::move(LHS),std::move(RHS),Temp);
    }
    return LHS;
}


static std::unique_ptr<ASTnode> ParseIf() {
  fprintf(stderr,"Parsing if. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
  if(CurTok.type != IF) //Ensure valid tokens are eaten leading up to relevant AST content
  {
    return nullptr;
  }
  getNextToken();
  if(CurTok.type != int('('))
  {
    fprintf(stderr,"Expected ( got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
    return nullptr;
  }
  getNextToken();
  auto Expr = ParseExpr();
  if(!Expr || CurTok.type != int(')'))
  {
    fprintf(stderr,"Invalid Expr or expected ) got %d %s\n",CurTok.type,CurTok.lexeme.c_str());;
    return nullptr;
  }
  getNextToken();
  auto Block = ParseBlock();
  if(!Block)
  {
    fprintf(stderr,"Invalid block got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
    return nullptr;
  }
  if(CurTok.type == ELSE)
  {
    getNextToken();
    auto Else = ParseBlock();
    if(!Else)
    {
      fprintf(stderr,"Invalid else got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    auto Result = std::make_unique<IfElseAST>(std::move(Expr),std::move(Block),std::move(Else),CurTok);
    return Result;
  }
  auto Result = std::make_unique<IfElseAST>(std::move(Expr),std::move(Block),std::make_unique<EmptyAST>(CurTok),CurTok);
  return Result;
}

static std::unique_ptr<ASTnode> ParseElse() {//Checks for else before parsing block
  fprintf(stderr,"Parsing else. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
  if(CurTok.type != ELSE)
  {
    fprintf(stderr,"Else expected got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
    return nullptr;
  }
  getNextToken();
  auto Block = ParseBlock();
  if(!Block)
  {
    fprintf(stderr,"Invalid block got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
    return nullptr;
  }
  return Block;
}

static std::unique_ptr<ASTnode> ParseWhile() {
  fprintf(stderr,"Parsing while. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
  if(CurTok.type != WHILE)
  {
    fprintf(stderr,"While expected got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
    return nullptr;
  }
  getNextToken();
  if(CurTok.type != int('('))
  {
    fprintf(stderr,"( expected) got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
    return nullptr;
  }
  getNextToken();
  auto Expr = ParseExpr();
  if(!Expr || CurTok.type != int(')'))
  {
    fprintf(stderr,"Invalid expr or expected ) got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
    return nullptr;
  }
  getNextToken();
  auto Stmt = ParseStatement();
  if(!Stmt)
  {
    fprintf(stderr,"Invalid stmt got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
    return nullptr;
  }
  auto Result = std::make_unique<WhileAST>(std::move(Expr),std::move(Stmt),CurTok);
  return Result;
}

static std::unique_ptr<ASTnode> ParseReturn() {
  fprintf(stderr,"Parsing return. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
  if(CurTok.type != RETURN)
  {
    fprintf(stderr,"Return expected got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
    return nullptr;
  }
  getNextToken();
  std::unique_ptr<ASTnode> Expr;
  if(CurTok.type == int(';')) //Gets an empty ast node if there is no return value
  {
      getNextToken();
      Expr = std::make_unique<EmptyAST>(CurTok);
  }
  else if(CurTok.type == int('-') || CurTok.type == int('!') ||  CurTok.type == INT_LIT || 
   CurTok.type == FLOAT_LIT || CurTok.type == BOOL_LIT || CurTok.type == int('(')|| CurTok.type == -1)
  {
      Expr = ParseExpr();
      if(!Expr || CurTok.type != int(';'))
      {
        fprintf(stderr,"Invalid expr or Expected ; got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
        return nullptr;
      }
      getNextToken();
  }
  else
  {
    fprintf(stderr,"Expected ; or expr got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
    return nullptr;
  }
  auto Result = std::make_unique<ReturnAST>(CurTok,std::move(Expr),CurTok);
  return Result;
}

static std::unique_ptr<ASTnode> ParseStatement() {
  fprintf(stderr,"Parsing statement. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
  std::unique_ptr<ASTnode> Stmt;
  switch(CurTok.type)
  {
        case IF://Checks which type of statement to parse
        {
          Stmt = ParseIf();
          if(!Stmt)
          {
            fprintf(stderr,"Invalid if got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
            return nullptr;
          }
          return Stmt;
        }
        case WHILE:
        {
          auto Stmt = ParseWhile();
          if(!Stmt)
          {
            fprintf(stderr,"Invalid while got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
            return nullptr;
          }
          return Stmt;
        }
        case RETURN:
        {
          Stmt = ParseReturn();
          if(!Stmt)
          {
            fprintf(stderr,"Invalid return got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
            return nullptr;
          }
          return Stmt;
        }
        case int('{'):
        {
          auto Stmt = ParseBlock();
          if(!Stmt)
          {
            fprintf(stderr,"Invalid block got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
            return nullptr;
          }
          return Stmt;
        }
        case int('('):
        case int('-'):
        case int('!'):
        case -1:
        case INT_LIT:
        case FLOAT_LIT:
        case BOOL_LIT:
        {
          auto Stmt = ParseExpr();
          if(!Stmt)
          {
            fprintf(stderr,"Invalid expr got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
            return nullptr;
          }
          if(CurTok.type != int(';'))
          {
            fprintf(stderr,"Expected semicolon got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
            return nullptr;
          }
          getNextToken();
          return Stmt;
        }
        case int(';'):
        {
          auto Stmt = std::make_unique<EmptyAST>(CurTok);
          return Stmt;
        }
        default:
          break;
    }
    return nullptr;
}


static std::unique_ptr<ASTnode> ParseBlock() {
  fprintf(stderr,"Parsing block. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
  if(CurTok.type != int('{'))
  {
    fprintf(stderr,"Expected { got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
    return nullptr;
  }
  getNextToken();
  std::list<std::unique_ptr<VarDeclAST>> Decls;
  while(CurTok.type == INT_TOK || CurTok.type == BOOL_TOK || CurTok.type == FLOAT_TOK)
  {
    auto Var = ParseVarDecl();
    if(!Var)
    {
      fprintf(stderr,"Invalid Var got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    Decls.push_back(std::move(Var));
  }
  std::list<std::unique_ptr<ASTnode>> Stmts;//Continues so long as a valid char is read
  while(CurTok.type == IF || CurTok.type == WHILE || CurTok.type == RETURN || CurTok.type == int('{') ||
   CurTok.type == int('-') || CurTok.type == int('!') ||  CurTok.type == INT_LIT || 
   CurTok.type == FLOAT_LIT || CurTok.type == BOOL_LIT || CurTok.type == int('(')|| CurTok.type == -1)
  {
    auto Stmt = ParseStatement();
    if(!Stmt)
    {
      fprintf(stderr,"Invalid Stmt got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    Stmts.push_back(std::move(Stmt));
  }
  if(CurTok.type != int('}'))
  {
    fprintf(stderr,"Expected } got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
    return nullptr;
  }
  getNextToken();
  auto Result = std::make_unique<BlockAST>(std::move(Decls),std::move(Stmts),CurTok);
  return Result;
}

static std::unique_ptr<VarDeclAST> ParseVarDecl(){//Gets a type and an ident
    fprintf(stderr,"Parsing var decl. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
    if(CurTok.type != BOOL_TOK && CurTok.type != INT_TOK && CurTok.type != FLOAT_TOK)
    {
      fprintf(stderr,"Invalid var type got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    std::string Type = CurTok.lexeme.c_str();
    getNextToken();
    if(CurTok.type != -1)
    {
      fprintf(stderr,"Invalid Dec got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    std::string Ident = CurTok.lexeme.c_str();
    getNextToken();
    if(CurTok.type != int(';'))
    {
      fprintf(stderr,"Expected ; got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    getNextToken();
    auto Result = std::make_unique<VarDeclAST>(Type,Ident,CurTok);
    return Result;
}

static std::unique_ptr<ASTnode> ParseGlobalVarDecl(){//Same as var decl but returns a global pointer
    fprintf(stderr,"Parsing global var decl. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
    if(CurTok.type != BOOL_TOK && CurTok.type != INT_TOK && CurTok.type != FLOAT_TOK)
    {
      fprintf(stderr,"Invalid var type got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    std::string Type = CurTok.lexeme.c_str();
    getNextToken();
    if(CurTok.type != -1)
    {
      fprintf(stderr,"Invalid Dec got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    std::string Ident = CurTok.lexeme.c_str();
    getNextToken();
    if(CurTok.type != int(';'))
    {
      fprintf(stderr,"Expected ; got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    getNextToken();
    auto Result = std::make_unique<GlobalVarDeclAST>(Type,Ident,CurTok);
    return Result;
}

static std::unique_ptr<FuncHeadAST> ParseFuncHead(){//Parses function prototype
    fprintf(stderr,"Parsing Func head. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
    if(CurTok.type < -5 || CurTok.type > -2)
    {
      fprintf(stderr,"Invalid type got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    std::string Type = CurTok.lexeme.c_str();
    getNextToken();
    if(CurTok.type != -1)
    {
      fprintf(stderr,"Expected Ident got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    TOKEN Temp = CurTok;
    getNextToken();
    if(CurTok.type != int('('))
    {
      fprintf(stderr,"Expected ( got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    getNextToken();
    std::vector<std::unique_ptr<VarDeclAST>> Params;
    if(CurTok.type == VOID_TOK)
    {
        std::string Type = CurTok.lexeme.c_str();
        getNextToken();
    }
    else if(CurTok.type >= -5 && CurTok.type <= -2)
    {
      while(CurTok.type >= -5 && CurTok.type <= -2)
      {
          std::string Type = CurTok.lexeme.c_str();
          getNextToken();
          if(CurTok.type != -1)
          {
            return nullptr;
          }
          std::string Id = CurTok.lexeme.c_str();
          getNextToken();
          std::unique_ptr<VarDeclAST> Param = std::make_unique<VarDeclAST>(Type,Id,CurTok);
          Params.push_back(std::move(Param));
          if(CurTok.type != int(','))
          {
            break;
          }
          getNextToken();
      }
    }
    if(CurTok.type != int(')'))
    {
      fprintf(stderr,"Expected ) got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    getNextToken();
    auto Result = std::make_unique<FuncHeadAST>(std::move(Type),Temp.lexeme.c_str(),std::move(Params),CurTok);
    return Result;
}

static std::unique_ptr<ASTnode> ParseFuncDecl(){ //Combines the function head with its body
    fprintf(stderr,"Parsing Func. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
    auto Head = ParseFuncHead();
    if(!Head)
    {
      fprintf(stderr,"Invalid head got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    auto Block = ParseBlock();
    if(!Block)
    {
      fprintf(stderr,"Invalid block got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
      return nullptr;
    }
    auto Result = std::make_unique<FunDeclAST>(std::move(Head),std::move(Block),CurTok);
    return Result;
}


static std::unique_ptr<ASTnode> ParseProgram(){//Gets all the externs and decls together
  fprintf(stderr,"Parsing program. Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
    std::list<std::unique_ptr<FuncHeadAST>> Externs;
    while(CurTok.type == EXTERN)
    {
        fprintf(stderr,"Read expr Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
        getNextToken();
        auto Ex = ParseFuncHead();
        if(!Ex || CurTok.type != int(';'))
        {
          fprintf(stderr,"Invalid Ex or Semicolon expected got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
          return nullptr;
        }
        getNextToken();
        Externs.push_back(std::move(Ex));
    }
    std::list<std::unique_ptr<ASTnode>> Decls;
    while(CurTok.type <= -2 && CurTok.type >= -5)
    {
      fprintf(stderr,"Read Decl Token:%d %s\n",CurTok.type,CurTok.lexeme.c_str());
      if(CurTok.type == VOID_TOK)
      {
          auto Dec = ParseFuncDecl(); 
          if(!Dec)
          {
            fprintf(stderr,"Invalid Dec got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
            return nullptr;
          }
          Decls.push_back(std::move(Dec));
      }
      else
      {
        TOKEN Temp = CurTok;
        getNextToken();
        TOKEN Temp2 = CurTok;
        getNextToken();
        if(CurTok.type == int(';'))
        {
            putBackToken(CurTok);
            putBackToken(Temp2);
            CurTok = Temp;
            auto Dec = ParseGlobalVarDecl();
            if(!Dec)
            {
              fprintf(stderr,"Invalid Dec got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
              return nullptr;
            }
            Decls.push_back(std::move(Dec));
        }
        else if(CurTok.type == int('('))
        {
            putBackToken(CurTok);
            putBackToken(Temp2);
            CurTok = Temp;
            fprintf(stderr,"TEMP1 %s\n",Temp.lexeme.c_str());
            fprintf(stderr,"TEMP2 %s\n",Temp2.lexeme.c_str());
            fprintf(stderr,"Cur %s\n",CurTok.lexeme.c_str());
            auto Dec = ParseFuncDecl(); 
            if(!Dec)
            {
              fprintf(stderr,"Invalid Dec got %d %s\n",CurTok.type,CurTok.lexeme.c_str());
              return nullptr;
            }
            Decls.push_back(std::move(Dec));
        }
        else
        {
          return nullptr;
        }
      }
    }
    if(CurTok.type != 0)
    {
      fprintf(stderr,"EOF expected");
      return nullptr;
    }
    auto Result = std::make_unique<ProgramAST>(std::move(Externs),std::move(Decls),CurTok);
    return Result;
}
 


static void parser() {
  auto Program = ParseProgram();
  depth = 0;
  if(!Program)
  {
    return;
  }
  fprintf(stderr,"Printing parse tree: \n %s \n",Program->to_string().c_str());
  fprintf(stderr,"Parsing Finished\n");
  depth = 0;
  std::map<std::string, AllocaInst*> temp;
  NamedValues.push_back(temp);
  Program->codegen();
}



//===----------------------------------------------------------------------===//
// Code Generation
//===----------------------------------------------------------------------===//



//===----------------------------------------------------------------------===//
// AST Printer
//===----------------------------------------------------------------------===//

inline llvm::raw_ostream &operator<<(llvm::raw_ostream &os,
                                     const ASTnode &ast) {
  os << ast.to_string();
  return os;
}

//===----------------------------------------------------------------------===//
// Main driver code.
//===----------------------------------------------------------------------===//

int main(int argc, char **argv) {
  if (argc == 2) {
    pFile = fopen(argv[1], "r");
    if (pFile == NULL)
      perror("Error opening file");
  } else {
    std::cout << "Usage: ./code InputFile\n";
    return 1;
  }

  // initialize line number and column numbers to zero
  lineNo = 1;
  columnNo = 1;

  // get the first token
  getNextToken();
  //while (CurTok.type != EOF_TOK) {
  //  fprintf(stderr, "Token: %s with type %d\n", CurTok.lexeme.c_str(),
  //          CurTok.type);
  //  getNextToken();
  //}
  //fprintf(stderr, "Lexer Finished\n");

  // Make the module, which holds all the code.
  TheModule = std::make_unique<Module>("mini-c", TheContext);

  // Run the parser now.
  fprintf(stderr, "Parsing Start\n");
  parser();
  fprintf(stderr, "Parsing Finished\n");
  //********************* Start printing final IR **************************
  // Print out all of the generated code into a file called output.ll
  auto Filename = "output.ll";
  std::error_code EC;
  raw_fd_ostream dest(Filename, EC, sys::fs::OF_None);

  if (EC) {
    errs() << "Could not open file: " << EC.message();
    return 1;
  }
  // TheModule->print(errs(), nullptr); // print IR to terminal
  TheModule->print(dest, nullptr);
  //********************* End printing final IR ****************************

  fclose(pFile); // close the file that contains the code that was parsed
  return 0;
}

